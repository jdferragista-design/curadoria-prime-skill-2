# QCY T13 (3523) — o que o primeiro uso real revelou

> Atualizado: 6 defeitos. Os bugs 5 e 6 saíram do recorte de tela que você
> mandou depois — o campo "como está" cortado no meio da palavra e uma recusa
> silenciosa que eu não teria achado sem o dump.

Validação de campo da v1.2.0 no post 3523. O painel funcionou como leitura, mas
**a tela de edição estava quebrada de duas formas independentes**. Ambas
corrigidas na v1.2.1.

---

## Bug 1 — o contexto exibido era de outro parágrafo

`preg_match_all` com `PREG_OFFSET_CAPTURE` devolve offset em **bytes**.
`mb_substr` conta **caracteres**. O código misturava os dois.

Cada acento ou emoji antes da ocorrência soma bytes que não são caracteres, e a
janela desliza progressivamente. No texto visível do 3523:

```
33.362 bytes / 32.046 caracteres  →  deriva de 1.316 posições no fim do artigo
```

Resultado medido: **34 das 38 ocorrências tinham contexto que não continha o
próprio trecho.** Por isso o painel mostrava `Testamos` e ao lado um texto que
começava em "ia, home office e sessões longas…" — outro trecho do artigo.

O detector estava certo o tempo todo; só a janela mostrada estava errada.
Como a mesma string ia no prompt, **a IA recebia trecho e contexto que não
combinavam** — e ainda assim devolvia sugestão, sem como saber disso.

Correção: `b2c()` converte offset de byte para caractere antes de recortar.

## Bug 2 — a unidade de edição era o token, não a frase

O detector casa `Testamos`, `R$ 169`, `Unboxing`. Esses tokens viravam
diretamente o campo editável. Dois problemas:

1. **Gravação impossível.** `CPC_Editor` recusa trecho ambíguo, e com razão.
   Mas `Testamos` aparece **9 vezes** no post, `R$ 169` **9 vezes**, `R$ 200`
   **7 vezes**. Teste contra o HTML publicado:

   | | v1.2.0 | v1.2.1 |
   |---|---|---|
   | campos que gravam | **7 de 26** | **24 de 24** |

   Ou seja: o editor podia escrever a correção perfeita em 19 campos e todos
   seriam recusados no save. A trava de segurança estava certa; a unidade que
   entregamos a ela é que estava errada.

2. **Prompt sem material.** Pedir para a IA reescrever a palavra "Testamos"
   isolada não tem resposta possível. Ela precisa da frase.

Correção: `sentenca()` expande a ocorrência até os limites da frase, com
guardas — não corta dentro de `R$ 1.973,50`, e frase acima de 600 caracteres
(tabela sem pontuação) cai para uma janela fixa.

### Efeitos colaterais tratados

- **Duas detecções na mesma frase viram um campo só** (`dedup()`). "Nós
  testamos o produto e medimos o brilho" era 2 campos com texto idêntico: o
  primeiro gravaria e o segundo seria recusado por "não encontrei". Os tokens
  ficam realçados dentro da frase, em `<mark>`.
- **26 ocorrências → 24 campos** no 3523. Não sumiu detecção: duas eram pares
  na mesma frase.

## Bug 3 — a âncora tolerante reprovava em HTML real

`localizar_flexivel()` aceitava tags de no máximo 120 caracteres entre as
palavras. O artigo tem `<a style="color: #667eea; font-weight: 600;" href="…">`,
bem acima disso. Também não tolerava entidades (`&#8220;` no lugar de `"`).

Agora casa caractere a caractere, aceitando tag de qualquer tamanho e a forma
entidificada de cada caractere.

## Bug 4 — description de schema

A mesma string vive em `<meta name="description">`, `og:description` e no
JSON-LD. Trocar uma cópia só deixa o snippet do Google divergindo da página.
`substituir()` ganhou o parâmetro `$todas`, ligado apenas para `alegacao_schema`.

---

## Bug 5 — o contexto cortava palavra ao meio

O recorte de contexto contava caracteres às cegas e parava onde desse. O
primeiro campo do 3523 abria assim:

```
-benefício em ANC. O único fone...
```

Isso parece bug de renderização e faz o editor duvidar da ferramenta. Agora
`contexto()` recua até o espaço anterior e avança até o próximo, nunca partindo
palavra, e marca com `…` quando há texto antes ou depois:

```
… custo-benefício em ANC. O único fone com ANC mais forte da lista é o
Edifier W820NB (38dB, over-ear, R$ 399) …
```

---

## Bug 6 — duas regras brigando pela mesma frase

O mais grave dos dois, porque era invisível. Esta frase do 3523:

> O ANC do T13 supera qualquer earbud na mesma faixa de preço que testamos — e
> a maioria dos que custam até R$ 280.

dispara **duas** regras: `alegacao_teste` (por "testamos") e `preco_sem_data`
(por "R$ 280"). Viravam **dois campos editáveis com o mesmo texto original**. O
editor corrigia nos dois, o primeiro gravava — e o segundo era recusado com:

> Não encontrei este trecho exato no conteúdo do post

A recusa estava tecnicamente certa (o primeiro save acabara de reescrever a
frase) e a mensagem, completamente enganosa: sugere conteúdo corrompido ou
detector quebrado, quando o trabalho tinha dado certo. Medido antes da correção:
**23 aplicadas / 1 recusada** em 24 campos.

Correção: `fundir_entre_regras()` dá a frase ao achado **mais grave**, que passa
a mostrar os tokens das duas regras e o aviso "esta frase também resolve:
preço sem data". Uma correção, os dois problemas resolvidos.

### O que essa correção quase quebrou

A primeira versão simplesmente removia a frase da regra perdedora — e removia a
regra inteira do relatório quando ela ficava sem ocorrências. A suíte `cpc-test`
reprovou na hora: `preco_sem_data` sumia de um artigo que tem preço sem data. A
contagem alimenta o CSV, o painel e o histórico dos 53 artigos; uma regra não
pode desaparecer da estatística porque outra ficou com a caixa de texto.

Versão final: `['n']` continua contando as duas detecções, o card da regra
continua no relatório, e os trechos cedidos aparecem em `['movidas']` com o
aviso "→ editar em Alegação de teste". Muda **onde se edita**, não **o que foi
encontrado**.

---

## Custo real, medido com os trechos maiores

Os campos ficaram maiores (frase + contexto de 220), então o custo subiu — e
ainda assim é irrisório:

```
24 campos · 9.360 tokens entrada · 1.264 saída · média 390 in/campo
```

| modelo | artigo inteiro | por campo |
|---|---|---|
| gemini-3.1-flash-lite | **R$ 0,023** | R$ 0,0010 |
| gpt-5-mini | R$ 0,027 | R$ 0,0011 |
| deepseek-v4-flash | R$ 0,004 | R$ 0,0002 |

Corrigir os 53 artigos com IA em todos os campos manuais: **menos de R$ 1,00.**

---

## Testes

Novo: `/home/user/.smoke/cpc-offset-test.php` — **20 asserções**, cobrindo os
quatro bugs acima mais os casos de guarda (preço com separador, frase gigante,
frase repetida em posições diferentes).

Suítes existentes após a mudança:

```
cpc-test         ✅ 35   (2 asserções reescritas: contavam ocorrências,
                          agora conferem tokens — nenhuma detecção se perdeu)
cpc-log-test     ✅ 25
cpc-editor-test  ✅ 21
cpc-offset-test  ✅ 33  (13 asserções novas: contexto por palavra, colisão
                        entre regras, estatística preservada, 3523 sem recusa)
cpc-colisao      ✅ 0 colisões · 23 campos · 23 gravam · 0 recusas
cpc-boot         ✅ 7 classes
cpc-reais        ✅ 4 artigos, trava passa, idempotente
```

Placar final no 3523: **23 campos editáveis, 23 gravam, 0 recusas** (era 7/26 no
primeiro uso, 23/24 depois dos bugs 1–4).

Pacote: `/home/user/curadoria-conformidade.zip` — **v1.2.2**, 16 arquivos, 46.021 B.

---

## O que ainda é do artigo, não do plugin

O 3523 tem `img_lazy = 11` no HTML publicado, mas `img_lazy = 0` no CSV do
painel. Isso é o esperado e já foi estabelecido: o plugin lê `post_content` do
banco, e o placeholder base64 é injetado pelo cache na renderização. Os 11 são
artefato do meu `curl`, não conteúdo gravado.

As 8 alegações de teste do 3523 **são reais** e precisam de reescrita: "Testamos
por 30 dias", "Testamos lado a lado", "usamos o fone por". Inclusive na
`description` do schema, que é o texto que vai para o snippet.
