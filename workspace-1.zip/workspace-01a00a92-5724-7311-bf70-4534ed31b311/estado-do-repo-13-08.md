# Estado do repo Ai-skill — verificado em 13/08/2026

Clone completo + API do GitHub, agora há pouco.

---

## Resumo

**O merge está certo. Faltam duas coisas, e apareceu um problema novo que vale mais que as duas.**

| Item | Estado |
|---|---|
| Merge da branch → `main` | ✅ feito (PR #1, `fd49835`) |
| Renomear os 2 arquivos sem extensão | ✅ feito (`c4a1aa4`, `60da00d`) |
| `main` completa | ✅ 28 arquivos |
| Conflito ou perda no merge | ✅ nenhum |
| Subir `tools/` e `audit/` | ⬜ pendente |
| Proteger a `main` | ⬜ pendente |
| **Defeito nos 2 modelos renomeados** | 🔴 **novo** |

---

## O que ficou certo

O histórico está limpo e legível:

```
* 60da00d Rename modelo-2-Power-Bank-no-Avião to ....html
* c4a1aa4 Rename modelo-layout-da-Apple-TV-4K. to ....html
*   fd49835 Merge pull request #1 from arena/019ff772-ai-skill
|\
| * 3cb70b3 Add a first-party price ledger to the marketplace skill.
| * ...
```

Você usou **merge commit**, não squash — os 34 commits foram preservados. Era a
recomendação e é o que mantém legível a evolução do raciocínio editorial.

`main` vs branch: **4 commits à frente, 0 atrás.** A inversão que a gente queria.
A branch virou histórico; a `main` é a verdade.

Rodei as ferramentas contra o clone para confirmar que nada se perdeu:

- `ledger.py validar` → 30 capturas, **0 erros**, 4 alertas conhecidos
- `checar_conformidade.py articles/*.html` → **0 erros** em 3 de 4 (o 4º é o
  `preview-tablets.html`, sem assinatura — correto, é preview)

Conteúdo íntegro.

---

## 🔴 O que o rename revelou

Este é o achado que importa. Ao ganharem a extensão `.html`, os dois modelos
passaram a ser vistos pelo checker pela primeira vez. Os dois reprovam:

### `modelo-layout-da-Apple-TV-4K.html` — 3 erros

```
❌ [teste-fisico] 1 alegação de experiência física direta
❌ [schema] 'aggregateRating' no JSON-LD — §2.4
❌ [schema] 'ratingCount' no JSON-LD — §2.4
```

O arquivo contém, **no mesmo documento**, as duas frases:

> "…dados agregados de compradores verificados — **não testamos esta unidade
> fisicamente**…"

> "Apple TV 4K vale a pena em 2026? **Testamos a fundo** a 3ª geração…"

E no schema:

```json
"aggregateRating": { "@type": "AggregateRating", "ratingValue": "4.7",
                     "bestRating": "5", "ratingCount": "384" }
```

### `modelo-2-Power-Bank-no-Avião.html` — 2 erros

```json
"aggregateRating": { "ratingValue": "4.5", "reviewCount": "1602" }
"aggregateRating": { "ratingValue": "4.7", "reviewCount": "11493" }
```

### Por que isto é pior do que parece

Esses arquivos são **modelos de layout**. Quem os copia herda os defeitos.

E não é hipotético — já aconteceu. Consultei o post **4537** (`/apple-tv-4k`) no ar
agora: ele tem exatamente as mesmas duas coisas, `"Testamos a fundo"` e
`aggregateRating`. É o caso que a auditoria já tinha marcado como contradição
crítica. O modelo é a origem, o artigo publicado é a cópia.

O post **4541** (`presentes-dia-dos-pais-2026-tech-premium`) repete o padrão, com
2 alegações.

O `aggregateRating` merece atenção especial: `ratingCount: 384` são as avaliações
da **Amazon**, publicadas no nosso schema como se fossem nossa avaliação agregada.
É precisamente o que §2.4 proíbe, e é o tipo de marcação que o Google trata como
structured data enganoso.

### O que fazer

Corrija os **modelos** antes dos artigos. Consertar só os artigos e deixar o
molde defeituoso garante que o problema volte no próximo texto.

1. Em `modelo-layout-da-Apple-TV-4K.html`: apague `"Testamos a fundo"`.
   **Mantenha a ressalva** "não testamos esta unidade fisicamente" — é fácil
   remover a errada por distração, e isso seria o pior resultado.
2. Remova os blocos `aggregateRating` inteiros dos dois modelos.
3. Depois aplique o mesmo aos posts 4537 e 4541.

Sugestão: mova os dois para `skills/curadoria-review/references/` depois de
corrigidos. Modelo de layout na raiz do repo se parece com entregável; dentro de
`references/` fica claro que é material de consulta da skill.

---

## Os dois itens pendentes

### `tools/` e `audit/` — pendente

`git ls-files` não encontra nenhum dos dois. Estão prontos em
`/home/user/ai-skill-merge/`; instruções em `COMO-SUBIR-PARA-O-GITHUB.md`.

Agora que a `main` está completa, suba direto nela.

Vale notar: foi o `checar_conformidade.py` que encontrou o defeito dos modelos.
Enquanto ele não estiver no repo, esse tipo de erro só aparece quando alguém
lembra de rodar a ferramenta manualmente, de fora.

### Proteção da `main` — pendente

`protected: false`. A `main` deixou de ser um esqueleto de 2 arquivos e virou a
fonte canônica das regras editoriais.

**Settings → Branches → Add rule** → `main` → *Require a pull request before merging*.

### A branch `arena/` continua lá

Certo por ora. Deixe uma semana; o histórico já está na `main` de qualquer forma.

---

## Ordem sugerida

1. **Corrigir os 2 modelos** (`Testamos a fundo` + `aggregateRating`) — mais urgente,
   porque contamina tudo que for copiado deles
2. Subir `tools/` e `audit/` na `main`
3. Proteger a `main`
4. Aplicar as mesmas correções aos posts 4537 e 4541
5. Atacar a fila P0 da auditoria (12 artigos de maior risco)
