# Post 4537 — as duas correções entraram ✅ (mas o WordPress mexeu no layout)

Puxei pela API e também baixei a página no ar. Modificado
**13/08/2026 19:27**.

## As correções: confirmadas

| | valor |
|---|---|
| `"Testamos a fundo"` | **0** ocorrências ✅ |
| `"Analisamos a fundo"` | **1** ✅ |
| `aggregateRating` | **0** ✅ |
| `ratingCount` | **0** ✅ |

Checker no HTML publicado:

```
Total: 0 erro(s) em 1 arquivo(s)
 ✅ [teste-fisico] Nenhuma alegação falsa de teste físico
 ✅ [schema] JSON-LD válido e completo
 ✅ [rel-sponsored] Todos os 6 links têm rel="sponsored"
```

JSON-LD revalidado no que está no ar: 1 bloco, `Article` + `Review` +
`FAQPage` + `BreadcrumbList`, todos íntegros. **O objetivo foi atingido.**

---

## Mas: o editor injetou 21 `<br />` que não existiam

Comparei byte a byte o que eu preparei com o que ficou publicado. Além das
minhas 3 linhas, apareceram **21 tags `<br />` novas** e **10 `<p>` extras**.

Isso é o `wpautop` — a função do WordPress que converte quebras de linha em
parágrafos. Ela roda quando o conteúdo é salvo pelo editor clássico ou pelo
Editor de código. Não foi você: é comportamento automático.

### Onde isso quebra o visual

**1. O índice de 12 itens** — era um `grid` de 2–3 colunas. Cada `<span>` era uma
célula:

```
antes:  <span>1️⃣ Resposta rápida</span>
        <span>2️⃣ Onde comprar</span>

agora:  <span>1️⃣ Resposta rápida</span><br />
        <span>2️⃣ Onde comprar</span><br />
```

O `<br />` também é filho do grid, então **ocupa uma célula**. O índice tem hoje
23 células em vez de 12: uma coluna inteira de células vazias entre os itens.

**2. As 4 badges do cabeçalho** (⭐ 4,7/5 · ⭐ 4,9/5 · 💰 preço · 🕒 atualizado) —
era `display:flex; flex-wrap:wrap`, os selos ficavam lado a lado e quebravam
sozinhos. Com 3 `<br />` no meio, cada um força uma linha nova. Empilharam.

**3. Quatro imagens** ganharam um `</p>` sem `<p>` correspondente. O HTML ficou
com 81 `<p>` para 80 `</p>` — desbalanceado. O navegador corrige sozinho, mas
pode gerar espaçamento estranho.

> Abra `curadoriaprime.com/apple-tv-4k/` e olhe o índice logo abaixo do
> cabeçalho preto, e a fileira de selos dentro dele. Se estiverem esticados ou
> empilhados, é isto.

---

## Conserto: `4537-apple-tv-CORRIGIDO-v2.html`

Gerei uma versão **imune ao `wpautop`**. A técnica é simples: o `wpautop` só
insere `<br />` e `<p>` onde encontra quebra de linha. Removi todas as quebras
de linha entre tags — o HTML vira uma linha só. Sem newline, não há o que
converter.

```
newlines:            0
<br>:                9   (só os legítimos, dentro dos cards de prova social)
grid do índice:      12 spans · 0 <br>     ✅
Testamos a fundo:    0                     ✅
aggregateRating:     0                     ✅
JSON-LD:             válido                ✅
checker:             0 erros               ✅
```

### Como aplicar

1. Abra `4537-apple-tv-CORRIGIDO-v2.html` aqui no workspace
2. Selecione tudo (`Ctrl+A`) e copie
3. WordPress → post 4537 → **⋮** → **Editor de código**
4. `Ctrl+A` no campo de conteúdo, cole por cima
5. **Atualizar**

Vai parecer uma parede de texto sem formatação no editor — é proposital e é
exatamente o que impede o WordPress de mexer. O HTML renderizado é idêntico ao
que você desenhou.

### Depois de salvar, confirme

Recarregue a página com `Ctrl+F5` e verifique:

- O índice voltou a 2–3 colunas, sem buracos entre os itens
- Os 4 selos do cabeçalho estão lado a lado, não empilhados

Me avise que eu re-puxo pela API e conto os `<br />` de novo.

---

## Isso vale para os próximos

O 4541 tem o mesmo risco, e é bem maior (78 KB, 5 produtos, grids em todos os
cards). Quando formos corrigi-lo, já entrego o HTML sem quebras de linha desde o
início — melhor que descobrir depois.

Vale também um teste rápido: se **outros artigos do site** foram editados pelo
Editor de código em algum momento, provavelmente carregam `<br />` fantasmas
pelos grids. Posso varrer os 48 e listar quais têm o sintoma, se quiser.

---

## Situação do 4537

| item | status |
|---|---|
| Alegação de teste físico | ✅ removida |
| `aggregateRating` no schema | ✅ removido |
| Checker | ✅ 0 erros |
| Layout do índice e das badges | ⚠️ aguardando o v2 |
| `[fontes]` com 0 links | 🔸 pendente — §3.4 pede fontes com link |
| `[honestidade]` | 🔸 falso positivo do checker, não do artigo |
