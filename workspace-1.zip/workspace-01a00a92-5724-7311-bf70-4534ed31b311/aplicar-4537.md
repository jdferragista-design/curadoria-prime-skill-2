# Post 4537 — Apple TV 4K · correção pronta

Baixei o HTML publicado pela WP REST API, apliquei as duas correções e validei.
O resultado está em **`4537-apple-tv-CORRIGIDO.html`**.

## Antes e depois, pelo checker

```
ANTES  →  3 erros · 2 alertas   🚫 NÃO PUBLICAR
   ❌ [teste-fisico] 1 alegação de experiência física direta
   ❌ [schema] 'aggregateRating' no JSON-LD — §2.4
   ❌ [schema] 'ratingCount' no JSON-LD — §2.4

DEPOIS →  0 erros · 2 alertas   ✅
   ✅ [teste-fisico] Nenhuma alegação falsa de teste físico
   ✅ [schema] JSON-LD válido e completo
```

O diff tem **3 linhas**. Nada de layout, links, preços ou imagens mudou.
JSON-LD revalidado: 1 bloco, `@graph` com `Article`, `Review`, `FAQPage`,
`BreadcrumbList` — todos íntegros.

---

## Como aplicar — 2 edições manuais (recomendado)

Mais seguro que colar 60 KB de uma vez. Leva uns 3 minutos.

WordPress → post 4537 → menu **⋮** (canto superior direito) → **Editor de código**.

### Edição 1 — o parágrafo de abertura

Busque com `Ctrl+F` por `Testamos a fundo`.

**Trocar:**
```
em 2026? Testamos a fundo a 3ª geração (chip A15 Bionic, 4K Dolby Vision + HDR10+, Dolby Atmos): analisamos <strong>
```

**Por:**
```
em 2026? Analisamos a fundo a 3ª geração (chip A15 Bionic, 4K Dolby Vision + HDR10+, Dolby Atmos): cruzamos <strong>
```

Duas palavras. `Testamos`→`Analisamos`, e o `analisamos` seguinte vira `cruzamos`
para não repetir o verbo na mesma frase.

### Edição 2 — o bloco de nota no JSON-LD

Busque por `aggregateRating`. Vai aparecer uma vez só.

**Apagar a linha inteira:**
```
        "aggregateRating": { "@type": "AggregateRating", "ratingValue": "4.7", "bestRating": "5", "ratingCount": "384" },
```

Ela fica entre `"description": "Streaming box 4K da Apple..."` e `"offers": [`.
Apague a linha completa, incluindo a vírgula no final. O JSON continua válido —
já conferi.

**Atualizar.**

---

## Alternativa: substituir o conteúdo inteiro

Se preferir, abra `4537-apple-tv-CORRIGIDO.html`, selecione tudo, e cole por cima
de todo o conteúdo no Editor de código.

⚠️ Isso sobrescreve qualquer edição feita no post depois de agora
(`modified: 2026-08-11T17:30`). Se ninguém mexeu, é seguro.

---

## Conferir depois de publicar

1. Abra `curadoriaprime.com/apple-tv-4k/` e dê `Ctrl+U`
2. `Ctrl+F` por `Testamos a fundo` → deve dar **0 resultados**
3. `Ctrl+F` por `aggregateRating` → deve dar **0 resultados**
4. Cole a URL em **validator.schema.org** → `Review` e `FAQPage` devem validar

Me avise que eu re-puxo pela API e confirmo.

---

## Os 2 alertas que sobram — nenhum é bloqueio

**`[honestidade] Não declara ausência de teste físico`** — **falso positivo.**
O artigo declara sim, no box amarelo do topo: *"não testamos esta unidade
fisicamente"*. O checker procura pelas frases `"não realizamos testes físicos"`
ou `"não recebemos unidades"`, e a sua redação é outra. É o checker que precisa
aprender essa variante, não o artigo que precisa mudar. Anotei para a próxima
rodada de melhorias no `checar_conformidade.py`.

**`[keyword-stuffing] 'apple' aparece 89× (4.0% do texto)`** — vale um olhar, mas
sem pressa. É um review de um produto Apple onde "Apple TV" é o nome do produto,
"Apple Store" é a loja e "Apple" é a marca. A densidade tem explicação natural.
Se quiser baixar, dá para trocar algumas ocorrências de "Apple TV 4K" por "o
aparelho" ou "o streaming box" nas seções do meio. Não é urgente e não bloqueia.

---

## Nota sobre o outro alerta silencioso

`[fontes] Seção de fontes presente (~0 itens)` — a seção existe, mas o checker
contou **zero links** dentro dela. Ou os itens não estão em `<li><a>`, ou a seção
está sem links. Vale conferir na hora que estiver com o post aberto: a §3.4 do
repositório pede fontes consultadas com link. Não é erro, mas está vazio de
substância.

---

**Arquivos gerados:**
- `4537-apple-tv-CORRIGIDO.html` — conteúdo pronto (61.342 chars)
- `4537-diff.txt` — o diff exato das 3 linhas, para auditoria
