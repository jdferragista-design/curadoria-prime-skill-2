#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
corrigir_artigos.py — remediação em lote dos 48 artigos já publicados.

Corrige automaticamente o que é MECÂNICO e seguro:
  1. rel="sponsored" ausente em links de afiliado  → adiciona rel completo
  2. divulgação de afiliado ausente                → insere o bloco padrão no topo

NÃO corrige automaticamente (exige reescrita humana — muda o significado do texto):
  3. alegações falsas de teste físico ("testamos", "testei", "unboxing")
     → apenas lista os trechos para você reescrever.

Uso:
    export WP_USER="seu_usuario"
    export WP_APP_PASSWORD="xxxx xxxx xxxx xxxx"

    python3 corrigir_artigos.py --dry-run              # simula em todos (padrão)
    python3 corrigir_artigos.py --dry-run --id 3153    # simula em um artigo
    python3 corrigir_artigos.py --aplicar --id 3153    # aplica em um artigo
    python3 corrigir_artigos.py --aplicar              # aplica em todos
    python3 corrigir_artigos.py --relatorio-alegacoes  # só lista o que é manual

SEMPRE rode --dry-run primeiro e confira o diff.
"""

import argparse
import base64
import json
import os
import re
import ssl
import sys
import urllib.error
import urllib.request
from html import unescape

SITE = "https://curadoriaprime.com"
API = f"{SITE}/wp-json/wp/v2"

DOMINIOS_AFILIADO = [
    "amazon.com.br", "amzn.to", "link.amazon", "mercadolivre.com",
    "meli.la", "mercadolivre.com.br",
]

REL_CORRETO = "sponsored noopener noreferrer nofollow"

BLOCO_DIVULGACAO = (
    '<div style="background:#f8f8ff;border:1px solid #e2e2f0;border-radius:12px;'
    'padding:16px 20px;margin:24px 0;font-size:.92em;color:#7c7c9a;line-height:1.6">'
    '🔍 <strong>Transparência:</strong> este artigo contém links de afiliado. '
    'Se você comprar por eles, podemos receber uma comissão <strong>sem custo adicional '
    'para você</strong>. Isso não influencia nossa análise — nossa nota é baseada em '
    'pesquisa técnica e dados de compradores verificados. '
    '<a href="' + SITE + '/transparencia-curadoria-prime/">Entenda nossa metodologia</a>.'
    '</div>'
)

PADROES_TESTE = [
    r"\btestamos\b", r"\btestei\b", r"\bem nossos testes\b", r"\bnos nossos testes\b",
    r"\busei (?:o|a|por)\b", r"\busamos (?:o|a|por) \w+ (?:durante|por)\b",
    r"\bdepois de (?:usar|testar)\b", r"\bnossa unidade\b", r"\bunboxing\b",
    r"\bsentimos na m[ãa]o\b", r"\bna nossa bancada\b", r"\bmedimos\b",
]

NEGACOES = re.compile(r"\b(n[ãa]o|sem|nunca|jamais)\b[\s\w,]{0,25}$", re.I)
INDICE = re.compile(r"(índice|sumário|neste (?:review|guia|artigo))", re.I)


# ─────────────────────────── utilidades ───────────────────────────

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def _auth():
    u, p = os.environ.get("WP_USER"), os.environ.get("WP_APP_PASSWORD")
    if not u or not p:
        sys.exit("❌ Defina WP_USER e WP_APP_PASSWORD no ambiente.")
    return base64.b64encode(f"{u}:{p}".encode()).decode()


def texto_visivel(html):
    h = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    h = re.sub(r"<style.*?</style>", " ", h, flags=re.S | re.I)
    h = re.sub(r"<[^>]+>", " ", h)
    h = unescape(h).replace("\xa0", " ")
    return re.sub(r"\s+", " ", h).strip()


def e_afiliado(tag):
    m = re.search(r'href="([^"]*)"', tag, re.I)
    if not m:
        return False
    return any(d in m.group(1) for d in DOMINIOS_AFILIADO)


def buscar_posts(post_id=None):
    if post_id:
        urls = [f"{API}/posts/{post_id}?_fields=id,slug,link,title,content,date"]
    else:
        urls = [f"{API}/posts?per_page=50&_fields=id,slug,link,title,content,date"]
    out = []
    for u in urls:
        req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
        d = json.loads(urllib.request.urlopen(req, timeout=90, context=_ctx()).read())
        out += d if isinstance(d, list) else [d]
    return out


# ─────────────────────────── correções ───────────────────────────

def corrigir_sponsored(html):
    """Adiciona rel completo em links de afiliado que não têm rel=sponsored."""
    n = [0]

    def repl(m):
        tag = m.group(0)
        if not e_afiliado(tag):
            return tag
        if "sponsored" in tag.lower():
            return tag
        n[0] += 1
        if re.search(r'\brel\s*=\s*"[^"]*"', tag, re.I):
            return re.sub(r'\brel\s*=\s*"[^"]*"', f'rel="{REL_CORRETO}"', tag, flags=re.I)
        return tag[:-1].rstrip() + f' rel="{REL_CORRETO}">'

    novo = re.sub(r"<a\b[^>]*>", repl, html, flags=re.I)
    return novo, n[0]


def corrigir_divulgacao(html):
    """Insere o bloco de divulgação se ausente, antes do primeiro link de afiliado."""
    txt = texto_visivel(html).lower()
    if any(k in txt for k in ["link de afiliado", "links de afiliado", "comissão"]):
        return html, 0
    # insere antes do primeiro link de afiliado, senão no topo
    for m in re.finditer(r"<a\b[^>]*>", html, re.I):
        if e_afiliado(m.group(0)):
            # sobe até o início do bloco/parágrafo que contém o link
            corte = html.rfind("<", 0, m.start())
            corte = html.rfind(">", 0, corte) + 1 if corte > 0 else m.start()
            return html[:corte] + BLOCO_DIVULGACAO + html[corte:], 1
    return BLOCO_DIVULGACAO + html, 1


def listar_alegacoes(html):
    """Lista alegações de teste físico que precisam de reescrita humana."""
    txt = texto_visivel(html)
    achados = []
    for pad in PADROES_TESTE:
        for m in re.finditer(pad, txt, re.I):
            antes = txt[max(0, m.start() - 40):m.start()]
            if NEGACOES.search(antes):
                continue
            jan = txt[max(0, m.start() - 120):m.start()]
            if jan.count("“") > jan.count("”"):
                continue
            if "unboxing" in m.group(0).lower() and INDICE.search(txt[max(0, m.start() - 160):m.start()]):
                continue
            achados.append((m.group(0), txt[max(0, m.start() - 80):m.end() + 80].strip()))
    return achados


SUGESTOES = {
    "testamos": "analisamos as especificações e cruzamos com relatos de compradores verificados",
    "testei": "analisei os dados técnicos e as avaliações de compradores",
    "em nossos testes": "segundo os dados técnicos do fabricante e relatos de compradores",
    "nos nossos testes": "segundo os dados técnicos e relatos de compradores",
    "depois de usar": "segundo relatos de quem usa",
    "nossa unidade": "as unidades relatadas por compradores",
    "unboxing": "o que vem na caixa",
    "medimos": "os dados oficiais indicam",
    "sentimos na mão": "compradores relatam",
}


def atualizar_post(post_id, html, auth):
    req = urllib.request.Request(
        f"{API}/posts/{post_id}",
        data=json.dumps({"content": html}).encode(),
        headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json",
                 "User-Agent": "Mozilla/5.0"},
        method="POST",
    )
    try:
        r = urllib.request.urlopen(req, timeout=90, context=_ctx())
        return r.status in (200, 201)
    except urllib.error.HTTPError as e:
        print(f"   ❌ HTTP {e.code}: {e.read()[:200].decode(errors='replace')}")
        return False


# ─────────────────────────── main ───────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Remediação em lote dos artigos publicados.")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true", help="simula (padrão)")
    g.add_argument("--aplicar", action="store_true", help="grava as alterações no WordPress")
    ap.add_argument("--id", type=int, help="corrigir apenas um post")
    ap.add_argument("--relatorio-alegacoes", action="store_true",
                    help="só lista alegações de teste físico para reescrita manual")
    a = ap.parse_args()

    aplicar = a.aplicar
    auth = _auth() if aplicar else None

    posts = buscar_posts(a.id)
    print(f"📥 {len(posts)} artigo(s) carregado(s).\n")

    if a.relatorio_alegacoes:
        total = 0
        for p in posts:
            ach = listar_alegacoes(p["content"]["rendered"])
            if not ach:
                continue
            total += len(ach)
            print(f"\n{'='*72}\nID {p['id']} · /{p['slug']}\n{p['link']}")
            for termo, trecho in ach:
                sug = SUGESTOES.get(termo.lower(), "reescreva sem alegar experiência física")
                print(f"\n  ❌ \"{termo}\"\n     …{trecho}…\n     ✏️  trocar por: {sug}")
        print(f"\n{'='*72}\nTotal: {total} trecho(s) para reescrita manual.")
        return

    tot_sp = tot_div = tot_posts = 0
    pendentes = []

    for p in posts:
        html = p["content"]["rendered"]
        novo, n_sp = corrigir_sponsored(html)
        novo, n_div = corrigir_divulgacao(novo)
        ach = listar_alegacoes(novo)
        if ach:
            pendentes.append((p["id"], p["slug"], len(ach)))
        if not (n_sp or n_div):
            continue
        tot_posts += 1
        tot_sp += n_sp
        tot_div += n_div
        print(f"ID {p['id']} · /{p['slug']}")
        if n_sp:
            print(f"   🔧 {n_sp} link(s) ganharam rel=\"sponsored\"")
        if n_div:
            print(f"   🔧 bloco de divulgação inserido")
        if aplicar:
            ok = atualizar_post(p["id"], novo, auth)
            print(f"   {'✅ gravado' if ok else '❌ falhou'}")
        else:
            print(f"   (dry-run — nada gravado)")

    print(f"\n{'='*72}")
    modo = "APLICADO" if aplicar else "SIMULAÇÃO (use --aplicar para gravar)"
    print(f"{modo}: {tot_posts} artigo(s) · {tot_sp} links corrigidos · {tot_div} divulgações inseridas")
    if pendentes:
        print(f"\n⚠️  {len(pendentes)} artigo(s) ainda com alegação de teste físico (reescrita MANUAL):")
        for i, s, n in sorted(pendentes, key=lambda x: -x[2]):
            print(f"     ID {i:>5} · {n} trecho(s) · /{s}")
        print("\n   Rode: python3 corrigir_artigos.py --relatorio-alegacoes")


if __name__ == "__main__":
    main()
