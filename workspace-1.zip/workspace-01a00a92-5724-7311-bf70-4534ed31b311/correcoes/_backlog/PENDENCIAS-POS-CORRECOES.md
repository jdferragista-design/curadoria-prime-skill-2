# Backlog — tratar SÓ depois que as correções dos artigos terminarem

## 1. Banner de cookies (WPConsent) em mobile
- **Onde:** site inteiro (visto no 3523 em viewport 390px).
- **Problema:** o banner ocupa ~1/3 da tela no celular e só desaparece após interação.
  Atrapalha a leitura da dobra inicial e provavelmente piora o CLS / Core Web Vitals.
- **Não é defeito de post** — é configuração do plugin.
- **Encaminhamento sugerido:** reduzir para barra fina no rodapé, ou compactar os 3 botões
  numa linha só. Verificar impacto em LCP/CLS no PageSpeed antes e depois.
- **Status:** adiado por decisão do usuário (15/08/2026). Não mexer agora.
