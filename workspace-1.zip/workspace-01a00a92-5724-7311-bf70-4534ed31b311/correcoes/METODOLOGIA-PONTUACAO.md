# Metodologia de Pontuação — Curadoria Prime

Proposta para discussão. Nada aqui está publicado ainda.

---

## O problema a resolver

O 3523 exibe "Nota: 8.5/10" em dois lugares e um selo "⭐ Recomendado" no bloco de compra.
Nenhum dos três explica de onde o número vem. Isso cria três riscos concretos:

1. **Contradição interna.** O artigo agora declara "análise documental comparativa — não
   tivemos o produto em mãos". Uma nota decimal sugere medição. Um leitor atento percebe
   que 8,5 e "não testamos" não combinam.
2. **Inconsistência entre artigos.** Sem régua, o 8,5 de um fone e o 8,5 de uma smart TV
   não significam a mesma coisa. Com 53 artigos, ninguém consegue manter coerência de cabeça.
3. **Exposição regulatória.** Nota numérica ao lado de link de afiliado, sem critério
   declarado, é exatamente o padrão que o Google associa a *thin affiliate* — e o que o
   CDC art. 37 trata como publicidade capaz de induzir a erro.

A página `/transparencia-curadoria-prime/` já tem uma metodologia de análise em 5 etapas e
já declara que não há teste físico. Ela é boa e é a base certa. **O que falta é a régua da
nota** — a palavra "nota" não aparece nenhuma vez lá.

---

## Princípio que resolve tudo

> **A nota mede a qualidade da proposta do produto para um perfil de comprador,
> a partir de evidência documental. Ela não mede desempenho aferido.**

Toda a metodologia decorre disso. Se um critério não pode ser avaliado sem o produto no
ouvido, ele **não entra na nota** — vira texto qualitativo. É isso que separa uma nota
honesta de uma nota inventada.

---

## Os 5 critérios

Cada um recebe 0 a 10. A nota final é a média ponderada, arredondada para 0,5.

| # | Critério | Peso | O que avalia | Fonte da evidência |
|---|---|---|---|---|
| 1 | **Custo-benefício** | 30% | O que o produto entrega por real, contra os rivais diretos na mesma faixa | Preço apurado + ficha técnica dos concorrentes |
| 2 | **Ficha técnica** | 25% | Especificações contra o padrão da categoria e da faixa de preço | Site oficial do fabricante, manuais |
| 3 | **Satisfação verificada** | 25% | Média e volume de avaliações, e o teor das críticas negativas | Amazon + Mercado Livre, com nº de avaliações e data |
| 4 | **Consenso técnico** | 10% | Convergência entre reviews especializados independentes | Canais e sites técnicos, citados nominalmente |
| 5 | **Confiança e suporte** | 10% | Garantia, assistência no Brasil, histórico da marca, atualizações de app | Política oficial + relatos de pós-venda |

**Por que esses pesos.** Custo-benefício pesa mais porque é o eixo editorial do site e é o
que dá para avaliar com rigor sem posse física. Satisfação verificada pesa alto porque é a
evidência empírica mais forte disponível — milhares de usuários reais valem mais que uma
opinião única. Consenso técnico pesa pouco porque é opinião de terceiro. Confiança pesa
pouco porque varia menos entre produtos da mesma faixa.

### O que NUNCA entra na nota

Conforto após horas de uso · encaixe na orelha · qualidade sonora subjetiva ·
temperatura em uso prolongado · durabilidade real · desempenho de microfone em campo.

Esses itens continuam no texto, sempre atribuídos a relatos de compradores. **Nunca viram
número.** É a linha que impede a nota de mentir.

---

## Escala — o que cada faixa significa

| Faixa | Selo | Significado |
|---|---|---|
| 9,0–10 | 🏆 Melhor da categoria | Referência na faixa; difícil de superar pelo preço |
| 8,0–8,9 | ⭐ Recomendado | Escolha sólida; entrega o que promete sem ressalva grave |
| 7,0–7,9 | 👍 Bom com ressalvas | Vale a pena para um perfil específico, descrito no texto |
| 6,0–6,9 | ⚖️ Alternativas melhores | Funciona, mas existe opção melhor pelo mesmo dinheiro |
| < 6,0 | ⚠️ Não recomendado | Problemas relevantes ou proposta ruim para o preço |

Uma casa decimal, no máximo, e sempre múltiplo de 0,5. **Notas como 8,7 são falsa
precisão** — sugerem uma resolução de medida que a metodologia não tem.

---

## Aplicando ao QCY T13 ANC (3523)

| Critério | Nota | Justificativa (evidência real do artigo) |
|---|---|---|
| Custo-benefício | 9,5 | ANC declarado de 28dB, driver de 10mm, BT 5.3 e app com EQ por R$ 169–186; rivais com proposta parecida custam de R$ 229 a o dobro |
| Ficha técnica | 8,0 | Forte para a faixa; perde em codecs (só SBC/AAC, sem aptX/LDAC) e não tem carregamento sem fio |
| Satisfação verificada | 9,0 | 4,8/5 em 6.546 opiniões no ML e 4,6/5 em 751 na Amazon — volume alto e média consistente entre as duas plataformas |
| Consenso técnico | 8,0 | Reviews especializados convergem em "melhor ANC barato"; ressalvas recorrentes sobre agudos e vento no microfone |
| Confiança e suporte | 6,5 | QCY tem presença consolidada e app ativo, mas assistência no Brasil é limitada e a garantia depende do lojista |

**Cálculo:** (9,5×0,30) + (8,0×0,25) + (9,0×0,25) + (8,0×0,10) + (6,5×0,10)
= 2,85 + 2,00 + 2,25 + 0,80 + 0,65 = **8,55 → 8,5**

**A nota atual sobrevive à metodologia.** Isso é o melhor cenário possível: você não precisa
mudar o número nem o selo — precisa mostrar a conta. O 8,5 deixa de ser opinião e vira
resultado auditável, e o selo "⭐ Recomendado" passa a ser consequência da faixa 8,0–8,9,
não um adesivo solto.

---

## O que fazer, na ordem

**1. Criar a página `/como-avaliamos/`.** Conteúdo: o princípio, a tabela de critérios com
pesos, a escala com os selos, a lista do que nunca entra na nota, e um exemplo de cálculo.
Linkar a partir da página de transparência e vice-versa.

**2. Em cada artigo com nota, colocar o bloco de cálculo** — a tabela dos 5 critérios com a
justificativa de cada um, como a do 3523 acima, e a nota final logo abaixo. Some ao lado de
cada menção à nota um link para `/como-avaliamos/`.

**3. Padronizar a grafia.** O 3523 escreve "8.5/10" em um lugar e "8,5/10" em outro. Em
português é vírgula. Detalhe pequeno que denuncia falta de processo.

**4. Não colocar `aggregateRating` no schema.** Nota editorial própria não é avaliação
agregada de usuários. Marcar como `aggregateRating` é violação de política de dados
estruturados do Google e pode gerar ação manual. O 3523 hoje não tem — e deve continuar sem.
Se quiser expor a nota no schema, o campo correto é `Review` com `reviewRating`, declarando
o autor como o site.

---

## Consequência para os outros 52 artigos

Toda nota já publicada precisa passar pela régua. Onde a conta não fechar, mexe-se na nota
ou na justificativa — nunca se inventa a justificativa para defender a nota. Isso pode ser
feito aos poucos, junto com a correção de conformidade de cada post, sem virar frente nova.
