# Post 4541 — Dia dos Pais 2026 Premium — COMO APLICAR

**URL:** https://curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/
**Estratégia:** artigo sazonal → **guia perene** (vale o ano todo).
**Verificado em 15/08/2026:** o site ainda está com a versão ANTIGA. Nada foi aplicado ainda.

---

## Arquivo a colar

`CORPO-para-colar.html` — **66.058 bytes · 4.912 palavras · 12 h2 · 7 imagens · 3 vídeos**

Só o `post_content`. **Não** contém `<html>`, `<head>`, nem o `<h1>` (o título fica no campo do WP).
Começa em `<div style="background:#f0f9ff...">📌 Guia permanente` e termina em `...links nas caixas de compra de cada produto.</p></div>`.

---

## Passo a passo

### 1. Backup
No editor, copie todo o conteúdo atual e salve num arquivo antes de mexer.

### 2. Colar o corpo — ⚠️ O PASSO QUE JÁ DEU ERRADO NO 3523
No post 3523, colar sem esvaziar **duplicou o artigo inteiro** (o WP concatenou).

1. Editor → menu ⋮ (canto superior direito) → **Editor de código** (`Ctrl+Shift+Alt+M`)
2. Clique dentro do campo → **`Ctrl+A`** → **`Delete`**
3. **CONFIRME QUE O CAMPO ESTÁ VAZIO ANTES DE COLAR.**
   Se o `Ctrl+A` não pegar tudo: `Ctrl+Home` → `Ctrl+Shift+End` → `Delete`.
4. Cole o conteúdo de `CORPO-para-colar.html`
5. Volte para o editor visual e **Atualizar**

### 3. Trocar o bloco de schema
Substitua o JSON-LD manual pelo conteúdo de `SCHEMA-para-colar.html`
(5× `Offer` → `AggregateOffer` com `lowPrice`/`highPrice`, `priceValidUntil` removido, autor completo).

### 4. ⚠️ FUSO HORÁRIO DO SITE — afeta os 48 artigos
**Configurações → Geral → Fuso horário → `São Paulo`** (hoje o site emite `+03:00`, que é Moscou).
Depois disso, reabra o post e clique **Atualizar** para o Rank Math regravar as datas.

### 5. Validar
- **Rich Results Test** na URL → conferir `AggregateOffer` sem erro
- **Search Console** → Inspecionar URL → Solicitar indexação
- Abrir no celular e conferir o comparativo (deve deslizar na horizontal)

---

## Verificação pós-colagem (obrigatória)

Não confie em "o texto novo apareceu". Confirme também que o **antigo sumiu**:

| Deve aparecer | Deve ter sumido |
|---|---|
| `Guia permanente` | `09/08` e `06/08` |
| `Faixa usual` (4×) | `Menor preço de hoje` |
| `AggregateOffer` (5×, no schema) | `priceValidUntil` |
| `Cristiano Martins` | `Dois integrantes` |
| **12 h2** (nem 24) | `1.379,08`, `379,05`, `227,05` |

---

## O que foi corrigido — 36 edições

### Prazo e urgência (11)
Sai "09/08", "ainda dá tempo", "chega antes do Dia dos Pais".
Entra: aviso de guia permanente, entrega Full (ML) / Prime (Amazon), FAQ "Quanto tempo antes eu preciso comprar?".

### Preço exato → faixa (17)
Zero preços com centavos no texto. `Menor preço de hoje: R$ X` → `Faixa usual: R$ X a R$ Y`.

| Produto | Faixa |
|---|---|
| Apple Pencil Pro | R$ 1.250 – 1.400 (tabela R$ 1.499) |
| Galaxy Watch7 44mm | R$ 1.350 – 1.500 |
| Anker 737 (140W) | R$ 600 – 700 |
| Soundcore Liberty 4 NC | R$ 370 – 430 |
| JBL Wave Buds 2 | R$ 220 – 260 |
| Anker A1695 | R$ 700 – 800 |

Os 4 botões da Amazon viraram "Ver preço na Amazon" (sem número).

### Schema (4)
5× `Offer`→`AggregateOffer`, 5× `priceValidUntil` removido, `+03:00`→`-03:00`, `dateModified 2026-08-15T18:00:00-03:00`.

### Autoria e metodologia (4)
Autor completo em 6 lugares. Bloco do autor = `_BLOCO-AUTOR-CANONICO.html` (conferido, idêntico).
Metodologia corrigida: era "Dois integrantes", agora declara **três produtos testados na bancada**
(Watch7, Liberty 4 NC, JBL Wave Buds 2); Pencil Pro e Anker 737 aparecem como **análise documental**.

---

## ⚠️ 4 defeitos encontrados HOJE no pacote (não estavam no relatório de 15/08)

O pacote tinha sido gerado a partir da página pública e carregava lixo do LiteSpeed.
Tudo já corrigido no arquivo — registrado aqui porque **vai se repetir nos próximos posts**.

1. **Link interno quebrado, 3×** — `curadoriaprime.com/slug-presentes-dia-dos-pais-tech-ate-300/`
   com a palavra `slug-` colada na URL. Respondia 301 (o WP adivinhava o destino),
   mas é redirect desnecessário e frágil. Corrigido para `/presentes-dia-dos-pais-tech-ate-300/` (200, postid 4397).
2. **Frase quebrada** — "Fora das capitais, some 2 a 3 dias. **deixamos apenas anúncios de lojas de
   confiança logística rápida**." (minúscula no início, sem sujeito, sem sentido).
   Vira: "Neste guia priorizamos anúncios de lojas com logística rápida."
3. **1.755 bytes de markup do TEMA** no meio do corpo — `</header>`, `<div class="single-featured-image">`,
   o `<picture>` da imagem destacada e `<div class="post-content">`.
   Colar isso **quebraria o layout** (div sem fechamento, imagem destacada duplicada). Removido.
4. **3 vídeos do YouTube com `src="about:blank"`** — o LiteSpeed guarda o endereço real em
   `data-litespeed-src`. Colados assim, os 3 vídeos apareceriam **em branco**. Restaurados.
   Mesma coisa nas 7 imagens (`data-src` + placeholder base64 + `title` numerado). Normalizadas.

---

## Mobile

Rodado `fix-mobile.py` + `add-hint.py` e medido com Playwright na largura real:

```
[OK] @360px  scrollW=360  clientW=360  elementos fora=0
[OK] @390px  scrollW=390  clientW=390  elementos fora=0
```

Este artigo **não** tem o bug de layout do 3523 — os blocos usam
`grid-template-columns: repeat(auto-fit, minmax(...))`, que já quebra sozinho no celular.
A única tabela (comparativo) recebeu o aviso **"↔ deslize para ver a tabela completa"**.

**Não foi inserido** o bloco "🧮 Como chegamos ao…": este post é um guia de comparação,
não uma review com nota fechada — não há nota a justificar.

---

## Links de afiliado — todos funcionando

Auditoria completa em `LINKS-QUEBRADOS-pais2026.md`. **Nenhum link quebrado.**

- **4 do Mercado Livre** via `mercadolivre.com.br/social/6620250626180940` (sua etiqueta de rastreamento —
  formato normal e correto): Watch7, Anker 737, Liberty 4 NC, JBL Wave Buds 2.
- **6 da Amazon** com tag `martins73-20`.
- Pencil Pro não tem link do ML — o artigo explica o porquê (não há anúncio nacional confiável).

**Sugestão de robustez (opcional):** 4 links da Amazon usam `link.amazon`, que redireciona por
`amzlinks.in` (encurtador de terceiros). Se ele cair, o link morre.
Alternativa direta: `https://www.amazon.com.br/dp/<ASIN>?tag=martins73-20`.

---

## Falsos positivos do plugin (pode ignorar)

Ao reprocessar o arquivo corrigido, o detector ainda acusa:

- `alegacao_teste` — a frase é "não foram testados por nós". **O detector não enxerga a negação.**
- `urgencia_falsa` — aspas curvas num nome de seção.
- `img_lazy` (10) — injetado pelo tema no output, não está no seu conteúdo.
