# Post 4541 — Título e Imagem Destacada

## O que encontrei no ar

| Item | Valor atual |
|---|---|
| SEO title | Dia dos Pais 2026: 5 Presentes Tech Premium (Guia Completo) — 59 chars |
| H1 | Dia dos Pais 2026: 5 Presentes Tech Premium que Ele Vai Usar Todo Dia — 69 chars |
| Imagem destacada / og:image | `hero-dia-dos-pais-2026-premium.jpg` (1376×768) |
| Imagem no **schema** | `destaque-dia-dos-pais-2026-guia-1.jpg` (1200×630) — **arte diferente** |

### ⚠️ Dois problemas

**1. og:image ≠ imagem do schema.** São duas artes distintas. Ao compartilhar, o Facebook/WhatsApp
mostra uma; o Google lê outra. Devem ser a mesma.

**2. A imagem destacada ilustra produtos que o artigo NÃO recomenda.**
A arte atual traz um estojo branco tipo AirPods, tablet e relógio genéricos. O guia recomenda
Galaxy Watch7 **verde**, Anker 737, iPad + Pencil Pro, JBL Wave Buds 2 e Soundcore Liberty 4 NC.
Capa que mostra produto errado é ruído de E-E-A-T — o Google avalia coerência entre imagem e conteúdo.
(A arte do *schema* já mostrava os produtos certos; a destacada é que ficou para trás.)

---

## Imagens novas geradas

Mesma direção de arte da original — fundo escuro com gradiente radial vinho, estouro de luz dourada
no canto superior direito, partículas e faíscas, caixas de presente pretas com laços salpicados de
dourado, terço esquerdo livre para o texto, dois terços à direita com a composição flutuante.
Serifada dourada no título + sans-serif branca no subtítulo, com fio dourado.

**O que mudou:** os produtos agora são os do artigo — smartwatch de **pulseira verde** com anel de
atividade, power bank preto com visor **84%** e cabos, tablet escuro com **stylus branca**, e **dois
estojos pretos** (um aberto com os fones à vista, um fechado) no lugar do estojo branco genérico.

| Arquivo | Dimensão | Uso |
|---|---|---|
| `destacada-nova-perene.jpg` | 1376×768 | **Imagem destacada — e só ela.** og:image, twitter:image e schema todos apontam para este mesmo arquivo. |

Sem "2026" na arte. (Uma variante com o ano e uma versão 1200×630 foram geradas e descartadas
para `_descartado/` — ver "Por que um arquivo só" abaixo.)

---

## Onde entra a imagem — e por que é UM arquivo só

**O Rank Math já gera o `og:image` e o `twitter:image` sozinho, a partir da imagem destacada.**
Confirmei no HTML ao vivo: ele emite `og:image`, `og:image:secure_url`, `width`, `height`,
`alt` e `twitter:image` automaticamente. **Você não precisa preencher nada na aba Social.**

Então o caminho é:

```
Imagem destacada do post
        │
        ├──> og:image + twitter:image   (Rank Math faz sozinho)
        └──> campo "image" do JSON-LD   (você aponta para a mesma URL)
```

### ⚠️ O descompasso que existe hoje

A página tem **DOIS blocos JSON-LD** e eles discordam:

| Bloco | Imagem |
|---|---|
| Rank Math (automático) — `Organization`, `WebSite`, `WebPage`, `BlogPosting` | `hero-dia-dos-pais-2026-premium.jpg` |
| Seu bloco manual — `Article`, `ItemList`, `FAQPage` | `destaque-dia-dos-pais-2026-guia-1.jpg` |

Duas artes diferentes descrevendo o mesmo artigo. Ao trocar a destacada e apontar o schema
manual para a mesma URL, os dois passam a concordar.

### Por que um arquivo só (descartei a 1200×630)

Gerei uma 1200×630 porque 1.91:1 é a proporção que o Facebook recomenda. Mas o site
**já publica 1376×768 (1.792) hoje e o card funciona** — está muito acima do mínimo
(600×315) e a diferença é imperceptível. Manter dois arquivos só cria a chance de
divergirem de novo, que é exatamente o problema atual. **Um arquivo, três destinos.**

As versões 1200×630 foram recortadas do centro (só 46px de altura), sem cortar texto nem produto.

---

## Decisão aplicada: sai o ANO, fica o TERMO

Isso já estava decidido em `correcoes/pais2026-PERENE.md` ("manter a página viva o ano todo",
"nenhuma frase do artigo pode envelhecer sozinha"). **O Dia dos Pais de 2026 foi em 09/08 — passou.**
Qualquer "2026" no título nasce vencido.

Distinção que guiou a execução:

- **"2026" (o ano) SAI** — é o que envelhece.
- **"Dia dos Pais" (o termo) FICA** — é o que traz busca e volta todo ano. Sem ele o artigo perde
  a identidade e vira "mais um 5 presentes tech", sem âncora nenhuma. O bloco azul do topo já
  resolve o "passou": diz que o guia vale para o próximo Dia dos Pais, aniversário, Natal ou qualquer data.

### Aplicar

| Campo | Valor |
|---|---|
| **H1 (título do post)** | `Dia dos Pais: 5 Presentes Tech Premium que Ele Vai Usar Todo Dia` |
| **SEO title (Rank Math)** | `Dia dos Pais: 5 Presentes Tech Premium (Guia Completo)` |
| **Imagem destacada** | `destacada-nova-perene.jpg` (1376×768) — og:image e schema herdam desta |

**Slug: NÃO mexer.** Continua `presentes-dia-dos-pais-2026-tech-premium`. Trocar slug de página
indexada joga fora o histórico de URL e cria cadeia de redirect — o ganho não paga o risco.
O ano na URL não aparece na SERP como texto.

### O que já foi feito no corpo e no schema

13 ocorrências de "Dia dos Pais 2026" viraram "Dia dos Pais" / "de Dia dos Pais":
badge do topo, lead, legenda da imagem, intro, h2 do FAQ, pergunta do FAQ, resumo final
e os 6 textos alternativos das imagens. No schema: `headline`, `name`, `description`,
`name` do ItemList e a pergunta do FAQ.

**Ficou 1 ocorrência de propósito:** a citação do artigo irmão
*"Dia dos Pais 2026: 7 Presentes Tech até R$ 300"* (post 4397) — é o título real dele.
Se um dia despublicar o ano de lá também, ajuste aqui junto.

**Datas de verificação foram preservadas** (7× `15/08/2026`, 3× `04/08`) — são procedência,
provam quando o preço foi conferido. Não confundir com amarração sazonal.

---

## Como aplicar

1. **Renomeie o arquivo no seu computador** para
   `destacada-dia-dos-pais-tech-premium.jpg` **antes** de subir.
   É o nome que o `SCHEMA-para-colar.html` já espera. (Se subir com outro nome, tudo bem —
   só copie a URL final da Mídia e cole no campo `"image"` do schema.)
2. **Mídia → Adicionar nova** → suba o arquivo (1376×768).
3. No campo **Texto alternativo**, cole:
   `Banner do guia de presentes de Dia dos Pais com smartwatch de pulseira verde, power bank com visor digital, tablet com caneta stylus e fones sem fio em estojos, sobre fundo vinho e dourado`
   Evite repetir o título exato no alt — o alt atual é cópia literal do H1, o que não agrega.
4. **Post 4541 → Imagem destacada → Substituir** pela nova.
   **Só isso já resolve o og:image e o twitter:image** — o Rank Math os regera a partir dela.
   Não precisa mexer na aba Social.
5. Confira que a URL no campo `"image"` do `SCHEMA-para-colar.html` bate com a URL real
   da imagem na Mídia. JSON-LD já validado.
6. Ajuste o **H1** (título do post) e o **SEO title** no Rank Math conforme a tabela acima.
7. Depois de publicar, confira o resultado:
   - **Facebook Sharing Debugger** → *Scrape Again* (senão o WhatsApp serve a capa antiga do cache)
   - **Rich Results Test** → conferir que a imagem do schema é a mesma do card social

⚠️ Não delete a imagem antiga da Mídia enquanto não confirmar a nova no ar — se algum outro
post a usar, quebra lá também.
