# Post 4541 — STATUS FINAL ✅

**URL:** https://curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/
**Verificado no ar:** 15/08/2026, com `?LSCWP_CTRL=NOCACHE` + cache-buster. HTTP 200, 146.560 B.

---

## Placar — tudo verde

| Item | Status | Evidência |
|---|---|---|
| Corpo colado | ✅ | similaridade **0,99985** contra `CORPO-para-colar.html`; as 2 diferenças são espaço e o "Receba" do widget de newsletter, ambos do tema |
| Sem duplicação | ✅ | **12 `<h2>`** do artigo (os outros 2 são do banner de cookies) |
| H1 sem ano | ✅ | `Dia dos Pais: 5 Presentes Tech Premium que Ele Vai Usar Todo Dia` |
| SEO title sem ano | ✅ | `Dia dos Pais: 5 Presentes Tech Premium (Guia Completo)` |
| og:title | ✅ | idêntico ao SEO title |
| Ano removido do corpo | ✅ | de 15 ocorrências → **2**, ambas legítimas (ver abaixo) |
| Imagem destacada | ✅ | arte nova sem ano, servida como `.webp` |
| og:image / twitter:image | ✅ | apontam para a arte nova |
| Schema manual | ✅ | 1 diferença só contra o pacote, e é **a correta** (ver abaixo) |
| `AggregateOffer` | ✅ | **5**, nenhum `Offer` solto |
| `priceValidUntil` | ✅ | **0** ocorrências |
| Fuso horário | ✅ | **0** `+03:00` · 10 `-03:00` |
| JSON-LD válido | ✅ | ambos os blocos parseiam |
| Preços em faixa | ✅ | 4× "Faixa usual", 0× "Menor preço de hoje" |
| Urgência removida | ✅ | 0× "chegar a tempo" / "últimos dias" / "prazo de entrega" |
| Bloco do autor | ✅ | 2× "fundador e editor-chefe", 1× "Seguir no X" |
| Aviso perene | ✅ | 1× "📌 Guia permanente" |
| Mobile 360 px | ✅ | `scrollWidth=360` = `clientWidth` · fora=0 |
| Mobile 390 px | ✅ | `scrollWidth=390` = `clientWidth` · fora=0 |
| Palavras | ✅ | 4.974 |

---

## As 2 ocorrências de "Dia dos Pais 2026" que ficaram no corpo — corretas

Ambas são a **citação do título do post irmão 4397**, que é um nome próprio de artigo:

1. No corpo: *"Temos um guia irmão dedicado a isso: **"Dia dos Pais 2026: 7 Presentes Tech até R$ 300"** — com carregadores…"*
2. No FAQ do schema: mesma citação, dentro de `acceptedAnswer`.

Citar o título real de outro artigo é procedência, não sazonalidade. **Ficam.**

⚠️ Se um dia o 4397 também perder o ano do título, essas 2 citações precisam ser
ajustadas junto — está anotado na fila.

---

## A diferença do schema contra o pacote — e por que está certa assim

| | valor |
|---|---|
| No ar | `…/uploads/2026/08/hero-dia-dos-pais-2026-premium.webp` |
| No pacote | `…/uploads/2026/08/destacada-dia-dos-pais-tech-premium.jpg` |

O pacote apontava para um arquivo que **nunca foi criado** — o plano original previa
renomear a imagem antes de subir, e isso não aconteceu (nem precisava). O valor **no ar
é o correto**: aponta para a destacada real, que existe e retorna 200.

**Não mexer.** O pacote é que ficou desatualizado em relação à realidade.

---

## Pendências no `<head>` — 4 ocorrências do ano, todas de baixa prioridade

| Onde | Texto | Ação |
|---|---|---|
| `description` | "…para o Dia dos Pais 2026: Pencil Pro…" | opcional |
| `og:description` | idem (espelha a meta description) | automático |
| `twitter:description` | idem | automático |
| `keywords` do Rank Math | "presentes de Dia dos Pais 2026" | opcional |

Os três primeiros são **o mesmo campo**: basta editar a *Descrição* no Rank Math que
og e twitter acompanham. Sugestão de substituto, 154 caracteres:

```
5 presentes tech premium para o Dia dos Pais: Pencil Pro, Watch7, Anker 737, JBL e Liberty 4 NC — faixas de preço reais, prós, contras e alertas de compra.
```

O campo `keywords` não é usado pelo Google desde 2009 — mexer só por coerência interna.

**Nada disso bloqueia o post.** Meta description não aparece no H1 nem no card; é texto
de snippet. Se quiser deixar 100% perene, são 30 segundos no Rank Math.

---

## Resíduo no servidor — inofensivo

Existe um `hero-dia-dos-pais-2026-premium.jpg` (62.557 B, 07/08) com a arte **antiga**,
com "2026" escrito em dourado. A página **não o referencia** — 0 ocorrências do `.jpg`,
10 do `.webp`. É um arquivo órfão. Pode apagar, desde que confirme que nenhum outro
post o usa.

---

## Recomendado antes de encerrar

- [ ] **Facebook Sharing Debugger → Scrape Again** — o card antigo (com a arte de 2026)
      pode estar em cache no WhatsApp/Facebook. A origem já está certa; é só forçar a releitura.
- [ ] **Rich Results Test** — confirmar que o Google lê `Article`, `ItemList`, `FAQPage`
      e `BreadcrumbList` sem aviso.
- [ ] Opcional: ajustar a meta description (texto acima).

---

## 4541 encerrado

Corpo, título, schema, imagem, fuso e mobile: **todos conformes e verificados no ar**.

**Ganho colateral:** a correção do fuso horário para São Paulo vale para o site inteiro —
os 48 artigos deixam de emitir `+03:00` (Moscou) nos timestamps de schema.

**Próximo da fila:** post **3002** (7 ocorrências graves / 17 no total).
