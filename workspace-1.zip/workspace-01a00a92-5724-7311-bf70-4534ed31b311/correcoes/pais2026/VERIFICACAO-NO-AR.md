# Post 4541 — verificação no ar (15/08/2026)

> ## ⚠️ CORREÇÃO — o "Problema 2" deste documento estava ERRADO
>
> Eu afirmei que a imagem destacada não tinha sido trocada e que a arte no ar
> mostrava "Dia dos Pais 2026" escrito em dourado. **Isso está errado.**
>
> **A imagem destacada FOI trocada e está correta.** A arte no ar é a nova, sem ano.
> O "2026" existe **apenas no nome do arquivo** — `hero-dia-dos-pais-2026-premium.webp`.
> Nome de arquivo não é lido por humano nem pesa em ranking; é irrelevante para a
> decisão perene. **Nada a fazer aqui.**
>
> **Como eu errei:** eu tinha baixado a versão `.jpg` desse mesmo caminho e olhei ela.
> O `.jpg` (62.557 B, `last-modified` 07/08) é o arquivo **antigo, com o ano na arte**,
> que continuou no servidor. O `.webp` (54.460 B, `last-modified` **15/08 20:56**) é o
> que a página realmente serve — e é a arte nova. Assumi que `.jpg` e `.webp` do mesmo
> nome eram o mesmo conteúdo. Não eram: o WebP foi regravado, o JPG não.
>
> Comparei os pixels do WebP no ar contra `destacada-nova-perene.jpg`: diferença média
> de **1,29 por canal** — ou seja, a mesma arte, só a perda da recompressão WebP.
>
> **Consequência em cadeia:** o "Problema 3" também cai. O `"image"` do schema manual
> aponta para o `.webp`, que existe e retorna **200** — não é 404. O schema está
> correto. Veja o placar revisado abaixo.
>
> **Lição registrada:** nunca inferir o conteúdo de um arquivo a partir de outra
> extensão do mesmo nome. Baixar exatamente a URL que a página referencia.

---


URL: `https://curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/`
Coletado com `?LSCWP_CTRL=NOCACHE` → HTTP 200, 149.712 B.

---

## Placar

| Item | Status |
|---|---|
| H1 sem ano | ✅ `Dia dos Pais: 5 Presentes Tech Premium que Ele Vai Usar Todo Dia` |
| SEO title sem ano | ✅ `Dia dos Pais: 5 Presentes Tech Premium (Guia Completo)` |
| og:title | ✅ igual ao SEO title |
| Schema manual trocado | ✅ `AggregateOffer` ×5 · `priceValidUntil` removido · `-03:00` ×2 |
| Fuso horário São Paulo | ✅ **resolvido** — zero `+03:00` na página (Rank Math emite `-03:00`) |
| Post não duplicado | ✅ 12 `<h2>` do artigo (os outros 2 são do banner de cookies) |
| Mobile 360 px | ✅ `scrollWidth=360` · fora=0 |
| Mobile 390 px | ✅ `scrollWidth=390` · fora=0 |
| Imagem destacada | ✅ **trocada e correta** — arte nova, sem ano (o "2026" é só o nome do arquivo) |
| og:image / twitter:image | ✅ apontam para a arte nova |
| `"image"` do schema manual | ✅ aponta para o `.webp` no ar, HTTP 200 |
| Corpo colado | ❌ **versão anterior** — único item pendente, veja abaixo |

**Palavras no ar: 4.973 · 12 h2 · nada estourando a tela. A estrutura está certa.**

---

## ❌ Único pendente — o corpo colado é a versão de backup, não a final

O que está no ar é byte a byte o `.smoke/_bkp2-4541.html` (similaridade 0,99985), que é o
snapshot **anterior** à remoção do ano. O `CORPO-para-colar.html` tem 20 ocorrências de
"2026"; o que está no ar tem 27.

Resultado: **19 ocorrências de "Dia dos Pais 2026" no corpo**, quando deveria haver **1**
(só a citação do título do post irmão 4397, que é legítima).

Tudo o mais entrou: `Faixa usual` ×4, `Guia permanente`, `Full/Prime`, FAQ "Quanto tempo
antes eu preciso comprar", bloco do autor ×2, zero `Menor preço de hoje`, zero
`chegar a tempo`. Só o passe final de remoção do ano ficou de fora.

### Correção — 2 caminhos

**Caminho A (recomendado, 1 minuto):** apagar tudo no Editor de código
(`Ctrl+A` → `Delete`) e colar de novo o `CORPO-para-colar.html` inteiro.
É o arquivo certo, já validado. Depois confira: **12 h2, não 24**.

**Caminho B (busca e substitui, 11 trocas):** se preferir não recolar, use
`Ctrl+H` no Editor de código, uma linha por vez, na ordem:

| # | Procurar | Substituir por | Ocorr. |
|---|---|---|---|
| 1 | `Publicado para o Dia dos Pais` | `Publicado originalmente para o Dia dos Pais` | 1 |
| 2 | `continuam válidas para aniversário` | `continuam válidas para o próximo Dia dos Pais, aniversário` | 1 |
| 3 | `🎁 Guia de Presentes — Dia dos Pais 2026</div>` | `🎁 Guia de Presentes — Dia dos Pais</div>` | 1 |
| 4 | `presentes de Dia dos Pais 2026</strong> com cara de premium` | `presentes de Dia dos Pais</strong> com cara de premium` | 1 |
| 5 | `alt="Presentes tech premium para o Dia dos Pais 2026: Apple` | `alt="Presentes tech premium para o Dia dos Pais: Apple` | 1 |
| 6 | `selecionados para o Dia dos Pais 2026 — validados` | `selecionados para o Dia dos Pais — validados` | 1 |
| 7 | `<strong>presentes Dia dos Pais 2026</strong> na faixa premium` | `<strong>presentes Dia dos Pais</strong> na faixa premium` | 1 |
| 8 | `— presente Dia dos Pais 2026"` | `— presente de Dia dos Pais"` | **4** (alts) |
| 9 | `presentes Dia dos Pais 2026</h2>` | `presentes de Dia dos Pais</h2>` | 1 |
| 10 | `presente tech para o Dia dos Pais 2026?` | `presente tech para o Dia dos Pais?` | 1 |
| 11 | `entre os presentes Dia dos Pais 2026 premium` | `entre os presentes de Dia dos Pais premium` | 1 |

⚠️ A troca **8** ainda deixa o alt do Pencil como `presente de Dia dos Pais para pai
criativo` — está correto, é o texto final.

⚠️ **Não** faça um "substituir tudo" de `2026`. Precisam ficar: as datas de verificação
(`15/08/2026`, `04/08/2026`, `31/07/2026`, `30/07/2026`), as datas das avaliações de
compradores (`jan/2026`, `jun/2026`, `jul/2026`, `fev/2026`), os caminhos de imagem
(`/uploads/2026/08/…`), os slugs internos (`melhor-fone-bluetooth-ate-500-reais-2026`,
`jbl-wave-buds-2-review-2026-vale-a-pena`) e a citação do post irmão
(`"Dia dos Pais 2026: 7 Presentes Tech até R$ 300"`, 2 lugares: corpo e FAQ).

Ao terminar, o corpo deve ter **20** ocorrências de `2026` e **1** de `Dia dos Pais 2026`.

---

## ✅ O que já está impecável — não mexer

- **Fuso horário: resolvido.** Zero `+03:00` na página. `datePublished 2026-08-04T15:00:22-03:00`,
  `dateModified 2026-08-15T18:13:08-03:00`. Isso conserta os 48 artigos de uma vez.
- **Schema manual:** 5× `AggregateOffer`, nenhum `Offer` solto, `priceValidUntil` fora,
  ambos os timestamps em `-03:00`, JSON-LD válido.
- **Mobile:** zero estouro em 360 e 390 px.
- **Sem duplicação:** o `Ctrl+A`+`Delete` funcionou.
- **Preços em faixa:** 4× "Faixa usual", nenhum "Menor preço de hoje".
- **Urgência removida:** zero "chegar a tempo", "últimos dias", "prazo de entrega".

---

## Checklist para fechar o 4541

Só sobrou **um** item de verdade:

- [ ] **1. Corrigir o corpo** — Caminho A (recolar `CORPO-para-colar.html` após `Ctrl+A`+`Delete`)
      ou Caminho B (as 11 trocas da tabela acima)
- [ ] 2. Atualizar o post
- [ ] 3. Reconferir: **12 h2** (não 24) e **1** ocorrência de `Dia dos Pais 2026` no corpo

Opcional, cosmético:

- [ ] 4. Alt da imagem destacada — hoje copia o H1, o que não agrega. Sugestão:
      `Banner do guia de presentes de Dia dos Pais com smartwatch de pulseira verde, power bank com visor digital, tablet com caneta stylus e fones sem fio em estojos, sobre fundo vinho e dourado`

**Não é necessário:**

- ~~Subir imagem~~ — já está no ar e correta
- ~~Definir destacada~~ — já definida
- ~~Recolar o schema~~ — o bloco manual no ar está idêntico ao pacote, incluindo o `"image"`
- ~~Renomear arquivo~~ — o `2026` no nome do arquivo não tem efeito nenhum
- ~~Facebook Scrape Again~~ — só se o card do WhatsApp ainda mostrar a arte velha em cache;
  a origem já está certa

**Sobre o arquivo antigo:** existe um `hero-dia-dos-pais-2026-premium.jpg` (62.557 B,
07/08) no servidor com o ano na arte. A página **não o referencia** em lugar nenhum
(0 ocorrências) — só o `.webp` aparece, 10 vezes. É um resíduo inofensivo. Se quiser
limpar, dá para apagar, mas confirme antes que nenhum outro post o use.
