# Plano mestre — correção dos artigos da Curadoria Prime

**Elaborado:** 16/08/2026 · **Base:** `uploads/conformidade-2026-08-15.csv` (54 posts) + verificação no ar
**Método:** um post por vez, entrega de HTML completo pronto para colar.

---

## 1. Onde estamos

| Post | O quê | Estado |
|---|---|---|
| 4541 | Dia dos Pais 2026 | ✅ publicado |
| 3002 | LG 55AU801 | ✅ publicado |
| 4846 | Página `/como-avaliamos/` (régua v2.0) | ✅ publicado |
| 3181 | LG AU801 50" | ✅ **publicado — confirmado no ar hoje** |
| 3523 | QCY T13 ANC | ✅ publicado · ⏳ **1 recolagem pendente** |

**Correção de registro:** `correcoes/ESTADO-3181.md` diz "aguardando colagem". **Está desatualizado.** Verifiquei a URL no ar: `1.941`→0, `815`→0, `Massacra`→0, `aggregateRating`→0, e os novos valores presentes (`1.973`×6, `2.088`×5, `R$ 79`, "se Destaca da", "50 avaliações"). O post **foi colado**. Vou marcar o arquivo como concluído para não refazermos trabalho.

**Pendência imediata:** recolar `3523/CORPO-para-colar.html` (91.977 B) — vão do autor 32→16 px + prova social 2+2.

---

## 2. O que o CSV revela sobre os 49 restantes

572 ocorrências pendentes, mas **elas não são iguais**:

| Tipo | Ocorrências | Risco | Natureza |
|---|---|---|---|
| `preco_sem_data` | 444 (**78%**) | baixo | mecânico, repetitivo |
| `schema_agg` | 43 | **alto** | rating agregado inventado — risco de penalidade |
| `alegacao_teste` | 38 | **alto** | "testamos/usamos" sem ter o produto — E-E-A-T |
| demais (sponsored, divulgação, autor, schema) | 47 | médio | pontual |

**Leitura:** 78% do volume é o item de menor risco. Ordenar a fila por "total de ocorrências" — como o CSV sugere à primeira vista — é o erro clássico de confundir **volume com gravidade**. Ranqueei por risco ponderado.

### Os 49 pendentes se dividem em dois grupos

- **9 posts puramente mecânicos** (só preço/lazy, zero risco editorial): `4806, 4537, 4397, 3183, 3809, 3226, 2884, 2910, 3033`
- **40 posts com risco editorial real** — destes, **26 alegam teste** e **27 têm rating agregado falso**; **13 têm os dois**

---

## 3. Fila proposta (por risco, não por volume)

### Bloco A — os 13 com dupla infração (alegação de teste + schema agregado)
Maior exposição: afirmam experiência que não houve **e** publicam nota inventada em dados estruturados. São o alvo típico do sistema de reviews do Google e da política de *thin affiliate*.

**Ordem:** `4675` → `4474` → `4683` → `4251` → `4709` → `2982` → `3320` → `4185` → `3858` → `2954` → `3310` → `4657` → `3548`

> `4675` está em pausa por decisão sua. Se mantiver, começamos por **4474** (45 ocorrências, 6 schema_agg — o maior do bloco).

### Bloco B — risco editorial simples (27 posts)
Só uma das duas infrações. Mesma régua, menos urgência.

### Bloco C — os 9 mecânicos
**Não merecem uma sessão cada.** São data de preço e `loading="lazy"`. Proposta: tratar **em lote**, num único passe, depois que A e B estiverem limpos.

---

## 4. Três problemas que NÃO se resolvem post a post

Descobertos hoje na verificação. São de **painel**, não de conteúdo — e afetam o site inteiro:

### 4.1 Nome do autor truncado (site-wide)
`twitter:data1` = **"Cristiano"** e o JSON-LD do Rank Math traz `author.name: "Cristiano"` em 3523, 3002, 4474 e 3181 — enquanto o nosso JSON-LD manual traz "Cristiano Martins". **Os dois convivem na mesma página, em conflito.**

**Correção:** WP → Usuários → perfil → *Nome de exibição* = `Cristiano Martins`. **Um clique conserta o site inteiro.** Nenhuma recolagem resolve isso.

### 4.2 Aspa órfã no título do 3181
`<title>` está **`LG AU801 50 polegadas" Vale a Pena?`** — trocaram `50"` por `50 polegadas` mas **a aspa ficou**. Está no `<title>`, `og:title` e `twitter:title`.

**Correção:** Rank Math → Título SEO do 3181 → remover a aspa. Também de painel.

> Nota: em 3169 e 3153 a aspa aparece como `&quot;` — ali é uso legítimo de polegada, **não é o mesmo defeito**. Só o 3181 tem a duplicação.

### 4.3 Banner de cookies em mobile
Já registrado em `_backlog/PENDENCIAS-POS-CORRECOES.md`, adiado por você. Mantenho adiado.

---

## 5. Recomendação de sequência

1. **Recolar o 3523** (arquivo pronto).
2. **Fazer os 2 ajustes de painel** (§4.1 e §4.2) — 5 minutos, ganho em 50+ páginas. **Melhor relação custo/benefício de todo o plano.**
3. **Retomar a fila pelo Bloco A**, começando em **4474** (ou 4675, se despausar).
4. **Bloco C em lote**, ao final.

---

## 6. Ganho de eficiência sugerido

Os posts do Bloco A repetem os mesmos 4 defeitos. Hoje cada um consome uma sessão longa de diagnóstico. Proposta: manter a entrega manual (um por vez, como você pediu), mas **reaproveitar os blocos já validados** — prova social do 3002/3523, bloco do autor canônico, wrapper de tabela, JSON-LD sem rating. Isso encurta cada post sem abrir mão da revisão individual.

**Estimativa:** Bloco A ≈ 13 sessões · Bloco B ≈ 27 · Bloco C ≈ 1–2 em lote.

---

## 7. Lições que já viraram regra

- `wpautop` repõe `title=""` e insere `</p>` fantasma → **nunca depender de `gap` nem de contagem de filhos** em flex/grid; usar `margin` no próprio elemento.
- Verificação pós-publicação: comparar **texto visível normalizado**, nunca grep bruto.
- Preview `file://` não carrega imagem remota nem dispara `loading="lazy"` → confirmar ativo com `curl` e rolar até o elemento.
- Conferir identidade do arquivo antes de editar (`ls -la` + canários).
- **Confiar no ar, não no arquivo de estado** — o caso 3181 mostra que o registro local pode ficar defasado.
