# Post 3523 — QCY T13 ANC · como aplicar

**URL:** https://curadoriaprime.com/qcy-t13-anc-review-2026-vale-a-pena/
**Tipo:** POST (id 3523) → REST `posts/3523`
**Arquivo a colar:** `CORPO-para-colar.html` — **91.392 bytes**

---

## Passo a passo

1. WordPress → **Posts** → editar o 3523.
2. Alternar para o **Editor de Código** (`Ctrl+Shift+Alt+M` no editor de blocos, ou o botão ⋮ → *Editor de código*).
3. **Selecionar tudo** (`Ctrl+A`) e **apagar**.
4. Colar o conteúdo **inteiro** de `CORPO-para-colar.html`.
5. **Atualizar**.
6. **LiteSpeed Cache → Purge All.**
7. Conferir no ar com `?LSCWP_CTRL=NOCACHE` no fim da URL.

> Backup do que estava no ar: `_original-live.html` e `/home/user/.smoke/3523-bkp-antes-v2.html` (88.841 B).

---

## O que mudou (12 itens)

### A. Alegações falsas de teste físico — removidas
Decisão sua: **o fone nunca esteve em suas mãos**. Eliminadas as duas contradições:

| Onde | Antes | Depois |
|---|---|---|
| Caixa "Fontes consultadas" | "**Testes:** Review baseado em uso real de 2 semanas pelo autor — home office, transporte público, academia e chamadas" | "**Método:** análise documental comparativa… **Não recebemos unidade do fabricante nem adquirimos uma para teste.**" |
| Bloco do autor | "Testou o QCY T13 ANC por 2 semanas em uso real…" | bio canônica (motorista de app, 16 mil viagens) |
| Seção 2 (controles) | "funcionaram de forma consistente durante toda a avaliação" | "sistema de gestos declarado pela QCY, confirmado pelo manual oficial e pelos relatos" |
| Seção 2 (sensibilidade) | "foi bem calibrada — não houve ativações acidentais" | "os relatos de compradores são majoritariamente favoráveis… **Não verificamos isso por conta própria.**" |

Os 3 disclaimers que já estavam certos foram mantidos: "não tivemos o produto em mãos", "Como não abrimos uma unidade", "Não medimos a autonomia".

### B. Régua v1.0 → v2.0
- "cinco critérios" → "**seis critérios com pesos fixos** (régua v2.0, agosto de 2026)".
- Tabela reconstruída com **6 linhas** e a coluna nova "Por que essa nota".
- Soma: `2,850 + 2,250 + 1,600 + 0,850 + 0,800 + 0,325 = **8,675**` → **8,5 ⭐**.
- Nota de versionamento acrescentada abaixo da caixa amarela, com link para `/como-avaliamos/#versao` e a informação de que sob a v1.0 o resultado era 8,55 — e a nota publicada também era 8,5 (ou seja, **a nota não mudou**).

| Critério | Peso | Nota | Contribuição |
|---|---|---|---|
| Custo-benefício | 30% | 9,5 | 2,850 |
| Satisfação verificada | 25% | 9,0 | 2,250 |
| Ficha técnica | 20% ↓ | 8,0 | 1,600 |
| **Recursos e usabilidade** (novo) | **10%** | 8,5 | 0,850 |
| Consenso técnico | 10% | 8,0 | 0,800 |
| Confiança e suporte | 5% ↓ | 6,5 | 0,325 |
| **Total** | **100%** | | **8,675 → 8,5** |

### C. Tag de afiliado Amazon → `martins73-20`
Os dois `amzn.to` carregavam `curadoriaprim-20` embutido no encurtador — trocar a tag exige refazer o link. Como não havia link curto novo, usei o **formato direto**, que é oficial e rastreia igual:

| Produto | Antes | Depois |
|---|---|---|
| QCY T13 ANC | `https://amzn.to/4rYGmoy` | `https://www.amazon.com.br/dp/B0BWRBKMCK?tag=martins73-20` |
| Galaxy Buds Core | `https://amzn.to/4cDNSkc` | `https://www.amazon.com.br/dp/B0FP8KDP36?tag=martins73-20` |

Ambos os ASINs foram confirmados abrindo a página real (`productTitle`): "QCY T13 ANC Fone Bluetooth 5.3…" e "Samsung Galaxy Buds Core…".
**Se preferir links curtos**, gere dois `amzn.to` no SiteStripe com `martins73-20` e me mande — eu troco.

Os links do **Mercado Livre não foram tocados**: `/sec/223qhqp` e `/sec/1pdm5eK` resolvem para os produtos certos.

### D. Preço R$ 199 → faixa real
Três ocorrências corrigidas para **R$ 169–186** (apurado em 15/08/2026), alinhando com o resto do post: conclusão do ANC, caixa do USB-C e comparação com o T13 anterior.

### E. Bloco do autor → canônico
Substituído pela **Variante A** de `_BLOCO-AUTOR-CANONICO.html`, byte a byte. Corrige de uma vez: bio inventada, `alt` errado, falta de `loading="lazy"`, `title=""` e o `rel="noopener nofollow"` no link do X (o canônico é só `noopener`).

### F. JSON-LD
- `dateModified`: `2026-08-02` → **`2026-08-15T21:00:00-03:00`**.
- `author`: agora Person completo — `jobTitle`, `description`, `image`, `url` (`/sobre-a-curadoria-prime/`), `sameAs` (X) e `worksFor`.
- `publisher.logo`: `cropped-image-270x270.jpg` → **logo canônica** `.webp` (HTTP 200 verificado).
- `offers`: virou **AggregateOffer** com as duas lojas (R$ 169 ML / R$ 186,10 Amazon), `lowPrice`/`highPrice`.
- **Sem `aggregateRating` e sem `reviewRating`** — como manda a régua.

### G. Erro factual encontrado na leitura
O texto afirmava que o QCY leva vantagem em "autonomia (30h vs 35h)" — mas **35 h é maior que 30 h**. Reescrito: a autonomia agora consta corretamente como vantagem do Galaxy Buds Core.

### H. Bugs de HTML pré-existentes (não eram meus)
- `</strong>` faltando na célula "35h (ANC off) ✅" da tabela comparativa.
- `</p>` órfão logo após o `<img>` do autor (resíduo de `wpautop`).
- 2 `</div>` órfãos e um `<p>` sem fechamento em volta do JSON-LD, no rodapé.
- 7 atributos `title=""` vazios removidos.
- `loading="lazy"` adicionado em 6 imagens (a primeira ficou `eager`, é o LCP).

---

## Checagens rodadas antes de entregar

| Teste | Resultado |
|---|---|
| `HTMLParser` balanceado | ✅ 0 erros, pilha vazia |
| Comentários HTML | ✅ 0 |
| `<p></p>` vazios | ✅ 0 |
| Linhas em branco | ✅ 0 (proteção contra o bug do `wpautop` nos grids) |
| Playwright `scrollWidth` @800px | ✅ 800 — sem estouro |
| Playwright `scrollWidth` @390px | ✅ 390 — sem estouro |
| Colunas uniformes nas 6 tabelas | ✅ `[3×7, 3×5, 4×5, 3×12, 4×7, 2×16]` |
| `JSON.parse` do JSON-LD | ✅ válido |
| `amzn.to` / `curadoriaprim-20` | ✅ 0 ocorrências |
| `martins73-20` | ✅ 3 (2 links + 1 no schema) |
| `R$ 199` | ✅ 0 |
| `aggregateRating` / `reviewRating` | ✅ 0 |
| Imagens sem `alt` | ✅ 0 |
| `rel="sponsored noopener noreferrer nofollow"` | ✅ 6 links de afiliado |

---

## Depois de publicar

Me avise e eu verifico via REST (`posts/3523?context=view`) comparando **byte a byte** contra o arquivo local — foi assim que fechamos o 3002 e a 4846.
