# Post 3523 — QCY T13 ANC — STATUS FINAL

**URL:** https://curadoriaprime.com/qcy-t13-anc-review-2026-vale-a-pena/
**Publicado:** 15/08/2026 22:13 · **Correção do bloco do autor:** pendente de recolagem
**Entregável:** `CORPO-para-colar.html` — **91.977 bytes**

---

## 1. O que foi corrigido no post (12 grupos)

| # | Problema | Correção |
|---|---|---|
| 1 | Tag de afiliado `curadoriaprim-20` | → **`martins73-20`** (3 ocorrências, 0 restantes da antiga) |
| 2 | Links curtos `amzn.to` não confirmados | → URL direta com ASIN `B0BWRBKMCK` + `?tag=martins73-20` |
| 3 | **"uso real de 2 semanas"** (falso) | Removido de *Fontes consultadas* e do bloco do autor |
| 4 | `aggregateRating` no JSON-LD | Removido (a régua não publica rating agregado) |
| 5 | Erro factual de autonomia | "30h vs 35h" invertido → **"35 h contra 30 h"** a favor do Galaxy |
| 6 | Preço desatualizado `R$ 199` | → faixa real **R$ 169–186,10** (15/08/2026) |
| 7 | Régua v1.0 (5 critérios) | → **v2.0, seis critérios**, nota **8,675 → 8,5** |
| 8 | `</strong>` faltando em `35h (ANC off)` | Fechado |
| 9 | 2 `</div>` órfãos no rodapé herdado | Fechados |
| 10 | Links de afiliado sem atributo | **6× `rel="sponsored"`** |
| 11 | Tabelas estourando no celular | 6 tabelas em wrapper `overflow-x:auto` + aviso "↔ deslize" |
| 12 | JSON-LD incompleto | `@graph` com Article, Product, FAQPage, BreadcrumbList; `author` completo; `AggregateOffer` 169,00–186,10 |

## 2. Verificação pós-publicação (REST `context=view`)

Texto visível comparado byte a byte com o local após remoção de tags/scripts: **idêntico, 32.923 caracteres**. Os 31 marcadores de conteúdo conferem. As 4 "divergências" iniciais eram erro de contagem do script, não do post.

## 3. 🔴 Regressão do `wpautop` — diagnóstico e solução definitiva

Ao salvar, o editor do WordPress reintroduziu duas coisas no bloco do autor:

1. **8× `title=""`** nas `<img>` — cosmético, sem impacto. O WP repõe sempre; não insistir.
2. **`</p>` órfão** logo após a `<img>` da foto, criando um **3º filho** no container flex.

**Causa:** o `wpautop` insere quebra de parágrafo antes de toda tag de bloco. Como a `<img>` ficava "solta" entre o `<div>` flex e o `<div>` de texto, ela virava parágrafo; a tag de abertura era engolida pela regra de blocos e o `</p>` sobrava.

**Por que importava:** o container usava `gap: 16px`. Com **3 filhos em vez de 2**, o `gap` era aplicado **duas vezes** — vão medido de **32 px** em vez de 16 px entre foto e texto.

**Solução aplicada (imune ao `wpautop`):** removido o `gap` do container; o espaçamento passou para **`margin-right: 16px` na própria `<img>`**. O `<p>` fantasma tem dimensão **0×0**, então com `margin` — que pertence à imagem, não ao container — ele deixa de produzir qualquer espaço.

**Comprovação (Playwright, com o `</p>` órfão injetado de propósito):**

```
vão img→texto NO AR (gap + <p> fantasma) : 32 px
vão img→texto CORRIGIDO                  : 16 px   ← alvo
filhos do flex: 3 (o <p> continua lá, mas agora é inofensivo)
foto: carrega, 512×512 nativo, renderizada 72×72
```

> **Regra geral:** em containers flex/grid dentro do editor do WP, **nunca dependa de `gap` nem de contagem de filhos** — o `wpautop` pode inserir nós fantasma. Prefira `margin` no próprio elemento.

## 3b. Bloco "O que dizem os compradores" — 2 + 2

**Problema relatado:** o bloco tinha **3 cards** (1 Amazon + 2 Mercado Livre). Com `repeat(auto-fit, minmax(280px,1fr))` o grid forma 2 colunas, então o 3º card ficava **sozinho na segunda linha** — e a proporção 1×2 dava a impressão de que faltava um card da Amazon.

**Correção:** buscada uma **segunda avaliação real** da Amazon (ASIN `B0BWRBKMCK`), extraída da página do produto com `data-hook="reviewTitle"` / `reviewRichContentContainer`. Ambas são **compra verificada**:

| Marketplace | Nota | Citação | Data |
|---|---|---|---|
| Amazon | 4,6/5 · 751 | "Minha melhor compra no aplicativo, bateria muito boa, som muito bom e os modos de supressão de ruídos são ótimos para o preço." | mai/2026 |
| Amazon | 4,6/5 · 751 | "Boa qualidade de som, inclusive bem alto. A bateria durou MUITO bem. O que me incomoda é a adaptação das olivas ao canal auricular." | fev/2024 |
| Mercado Livre | 4,8/5 · 6.546 | "Fone ótimo. Simples, mas excelente. O cancelamento de ruído é bom e a conexão não falha." | set/2024 |
| Mercado Livre | 4,8/5 · 6.546 | "Estou gostando bastante do fone! Gostei bastante do ANC. Resolvi o desconforto trocando as borrachinhas." | mai/2024 |

A citação anterior da Amazon ("Bom custo-benefício. O ANC funciona bem para o preço...") **não era verbatim** e foi substituída por texto real de comprador. A 2ª review traz uma **ressalva** (olivas), o que atende a diretriz do Google de discutir benefícios **e** desvantagens — e conversa com o card do ML que cita a mesma solução (trocar as borrachinhas).

**Bug de cor corrigido junto:** o card do ML de mai/2024 estava com a **borda laranja e o título em `#FF9900`** (estilo Amazon). Agora usa `#a9cdfa` / `#3485DB`, o padrão do Mercado Livre.

**Render (Playwright):** 800px → grid `326px 326px`, **2×2 alinhado**; 390px → coluna única, 4 cards empilhados, `scrollWidth` 390 sem estouro.

## 4. Validação do arquivo final

```
HTMLParser  -> 0 erros, pilha vazia
JSON-LD     -> @graph [Article, Product, FAQPage, BreadcrumbList] parseia
               dateModified 2026-08-15T21:00:00-03:00
               author: Cristiano Martins / Fundador e editor-chefe da Curadoria Prime
               AggregateOffer 169.00–186.10 BRL · sem rating agregado
comentários HTML: 0 · <p></p>: 0
martins73-20: 3 · curadoriaprim-20: 0 · rel="sponsored": 6
Playwright  -> 800px: scrollWidth 800, zero estouros
               390px: scrollWidth 390, 6/6 tabelas dentro de scroller
```

## 5. Falso negativo a não repetir

No preview `file://` a foto do autor aparecia ausente. **Não era bug:** (a) `loading="lazy"` só dispara quando o elemento entra na viewport — é preciso rolar até ele no Playwright; (b) a URL correta é **`/uploads/2026/08/`**, não `2025/07`. O ativo responde **200, 20.476 B, image/jpeg**.

## 6. Ação pendente

**Recolar `CORPO-para-colar.html`** (91.977 B). Duas mudanças em relação ao que está no ar:
1. vão do bloco do autor de 32 → 16 px (fix imune ao `wpautop`);
2. prova social passa de 3 para **4 cards (2 Amazon + 2 ML)**, com citações reais e a cor do card ML corrigida. Depois de salvar: **Purge All** no LiteSpeed e conferir com `?LSCWP_CTRL=NOCACHE`.

---

**Fila:** 4541 ✅ · 3002 ✅ · 4846 ✅ · **3523 ✅** → 4675 (em pausa) · **4474** (próximo) · 4683 · 4251 · 4709 · 2982 · 3545 · 2892 · 4414 · 4397.
