# 3523 — o que muda, em texto legível

Texto visível: original publicado × versão corrigida.

### Mudança 1
**Antes:** ⭐ 4,8★ (6.546 ML) · 4,6★ (751 AMZ)
**Antes:** 💰 R$ 169-186
**Depois:** ⭐ 4,8★ (6.546 ML) · 4,6★ (751 AMZ) — ago/2026
**Depois:** 💰 R$ 169–186 (ago/2026)

### Mudança 2
**Antes:** Este review é baseado em
**Antes:** teste real de 2 semanas
**Antes:** — uso diário em home office, transporte público, academia e chamadas. Especificações confirmadas no
**Depois:** Esta é uma
**Depois:** análise documental comparativa
**Depois:** — não tivemos o produto em mãos. Ela cruza a ficha técnica oficial, verificada no

### Mudança 3
**Antes:** .
**Antes:** 🔍 Tipo de análise:
**Antes:** teste prático do autor + dados de compradores verificados na Amazon e Mercado Livre.
**Depois:** , a comparação ponto a ponto com os concorrentes diretos da faixa e a leitura sistemática de avaliações verificadas de compradores na Amazon e no Mercado Livre.
**Depois:** 🔍 O que isto não é:
**Depois:** não há medição de dB, de autonomia ou de latência feita por nós. Onde o texto traz número, ele vem do fabricante ou dos relatos — e está identificado como tal.

### Mudança 4
**Antes:** Unboxing
**Depois:** O que vem na caixa

### Mudança 5
**Antes:** e quer saber se o cancelamento de ruído de 28dB funciona de verdade por R$ 169-186. Essa é exatamente a pergunta certa — e é ela que este review responde com testes reais, não só especificações copiadas da caixa.
**Depois:** e quer saber se o cancelamento de ruído de 28dB funciona de verdade por R$ 169-186. Essa é exatamente a pergunta certa — e é ela que este review responde cruzando a ficha técnica oficial, a comparação com os rivais diretos e o que dizem os compradores verificados, dizendo em cada ponto de onde vem a informação.

### Mudança 6
**Antes:** Testamos o fone em uso diário por mais de duas semanas: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. Veja o que encontramos.
**Antes:** 1. Unboxing e Primeiras Impressões
**Antes:** A caixa do QCY T13 ANC é funcional e sem excessos — papelão reciclado com janela plástica que mostra o estojo. É a embalagem de quem investe o dinheiro no produto, não na apresentação. Dentro dela:
**Depois:** Nossa análise parte da ficha técnica oficial da QCY, da comparação ponto a ponto com os concorrentes diretos da faixa e da leitura sistemática de avaliações verificadas de compradores brasileiros — com atenção aos cenários que mais aparecem nos relatos: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. O que a documentação e os relatos sustentam está abaixo.
**Depois:** O que depende de ter o produto no ouvido — conforto após horas, encaixe na sua orelha, microfone em rua movimentada — nós não verificamos, e dizemos isso onde importa.
**Depois:** 1. O Que Vem na Caixa
**Depois:** Como não abrimos uma unidade, o conteúdo abaixo vem do material oficial da QCY e das fotos publicadas por compradores nas avaliações da Amazon e do Mercado Livre. A embalagem é funcional e sem excessos — papelão reciclado com janela plástica que mostra o estojo. Segundo o fabricante, a caixa traz:

### Mudança 7
**Antes:** A primeira impressão ao tirar o estojo da caixa é positiva: o plástico tem acabamento fosco que não acumula digitais facilmente, a dobradiça da tampa é firme e o clique magnético ao fechar tem uma resposta satisfatória. O tamanho é realmente compacto — na horizontal, o estojo cabe na palma da mão e não faz volume no bolso da calça.
**Antes:** Os earbuds têm design em formato de gota com haste curta. O acabamento fosco em preto transmite uma sensação de produto acima do preço praticado. Ao encaixar pela primeira vez, a ponteira M (média, já instalada) serviu bem para a maioria do time de teste — o encaixe passivo antes de qualquer ANC já é razoável. Para quem tem canais auditivos menores, a troca para a ponteira P melhora bastante o isolamento passivo e, por consequência, a eficiência do ANC.
**Depois:** Nas avaliações com foto, o acabamento fosco do plástico aparece descrito como resistente a marcas de dedo, e a firmeza da dobradiça e o clique magnético da tampa são elogios recorrentes. O tamanho compacto é confirmado pelas dimensões oficiais do estojo — cabe na palma da mão e é citado nos relatos como discreto no bolso.
**Depois:** Os earbuds têm design em formato de gota com haste curta. O acabamento fosco em preto transmite uma sensação de produto acima do preço praticado. A ponteira M já vem instalada de fábrica e, pelos relatos, serve à maioria dos usuários — o isolamento passivo, antes de qualquer ANC, é descrito como razoável. Para quem tem canais auditivos menores, a troca para a ponteira P melhora bastante o isolamento passivo e, por consequência, a eficiência do ANC.

### Mudança 8
**Antes:** — um dos mais leves da categoria. A leveza é o principal aliado do conforto em sessões longas: usamos o fone por até 3 horas seguidas sem sentir aquela pressão acumulada no canal auditivo que é comum em earbuds mais pesados.
**Depois:** — um dos mais leves da categoria. A leveza é o principal aliado do conforto em sessões longas: os relatos de uso prolongado (duas a três horas seguidas) mencionam pouca pressão acumulada no canal auditivo, o que é coerente com o peso declarado.
**Depois:** Conforto, porém, depende da anatomia de cada orelha — e isso nenhuma análise documental resolve por você.

### Mudança 9
**Antes:** ou no JBL Wave Buds 2) significa que o encaixe depende exclusivamente da ponteira. Para uso cotidiano — transporte, escritório, academia leve —, o encaixe se manteve firme em todos os nossos testes. Para corridas em ritmo forte ou treinos de alta intensidade com muito movimento de cabeça, o fone pode ceder. Para esse perfil de uso, o JBL Wave Buds 2 (com haste estabilizadora) seria mais adequado.
**Depois:** ou no JBL Wave Buds 2) significa que o encaixe depende exclusivamente da ponteira. Para uso cotidiano — transporte, escritório, academia leve —, os relatos de compradores descrevem encaixe firme na maioria dos casos. Para corridas em ritmo forte ou treinos de alta intensidade com muito movimento de cabeça, o fone pode ceder. Para esse perfil de uso, o JBL Wave Buds 2 (com haste estabilizadora) seria mais adequado.

### Mudança 10
**Antes:** O que ouvimos
**Depois:** O que os relatos e a ficha técnica indicam

### Mudança 11
**Antes:** 4. ANC de 28dB: Funciona de Verdade? (Testamos em 3 Ambientes)
**Depois:** 4. ANC de 28dB: Funciona de Verdade? (O Que Esperar em 3 Ambientes)

### Mudança 12
**Antes:** — os microfones captam o som externo antes de ele chegar ao ouvido e o sinal cancelador é gerado antecipadamente. Esse tipo de ANC é eficiente para ruídos contínuos e previsíveis (motores, ar-condicionado, ventilação), mas tem menos eficiência contra sons transientes e agudos (vozes, buzinas, gritos). Entendendo essa limitação técnica, os testes fazem mais sentido:
**Depois:** — os microfones captam o som externo antes de ele chegar ao ouvido e o sinal cancelador é gerado antecipadamente. Esse tipo de ANC é eficiente para ruídos contínuos e previsíveis (motores, ar-condicionado, ventilação), mas tem menos eficiência contra sons transientes e agudos (vozes, buzinas, gritos). Entendendo essa limitação técnica, dá para projetar com honestidade o comportamento em cada ambiente — é isso que fazemos abaixo, combinando a arquitetura do ANC com o que os compradores relatam:

### Mudança 13
**Antes:** O ruído de fundo do motor diesel — aquele zumbido grave e contínuo de ~80–90Hz — foi reduzido de forma muito perceptível com o ANC ligado. No nosso teste, conseguimos ouvir música em volume 35–40% sem perder detalhes da faixa, enquanto sem ANC o volume mínimo confortável subia para 55–60% para cobrir o mesmo ruído.
**Antes:** Conversas próximas (frequências de 200Hz–4kHz) chegam atenuadas mas não eliminadas — especialmente vozes femininas agudas passam com mais facilidade. Não é isolamento de avião, mas para o trajeto diário de ônibus o ganho de concentração é real e mensurável.
**Antes:** Resultado: bom — superou expectativas para o preço.
**Depois:** O zumbido grave e contínuo do motor diesel (~80–90Hz) está exatamente na faixa que o ANC feedforward trata melhor, e é o cenário mais citado nas avaliações brasileiras: os relatos descrevem conseguir ouvir música em volume sensivelmente mais baixo com o ANC ligado do que sem ele. Não há, que tenhamos localizado, medição independente em dB para esse caso — o número de 28dB é declarado pela QCY.
**Depois:** Conversas próximas (frequências de 200Hz–4kHz) chegam atenuadas mas não eliminadas — especialmente vozes femininas agudas passam com mais facilidade. Não é isolamento de fone premium, mas para o trajeto diário de ônibus os relatos convergem em ganho perceptível de concentração.
**Depois:** Expectativa realista: bom para a faixa de preço.

### Mudança 14
**Antes:** Este foi o cenário em que o ANC do T13 mais impressionou. O ruído contínuo e uniforme do ar-condicionado central (~55–65Hz predominante) é exatamente o tipo de frequência que o ANC feedforward cancela com maior eficiência. Com o ANC ligado, o ruído do ar praticamente desapareceu — a diferença foi imediata e marcante.
**Antes:** Testamos lado a lado com o
**Depois:** Este é o cenário em que essa arquitetura tende a ir melhor. O ruído contínuo e uniforme do ar-condicionado central (~55–65Hz predominante) é o tipo de frequência que o ANC feedforward cancela com maior eficiência, e é onde as avaliações mais usam a palavra "silêncio" para descrever o efeito.
**Depois:** Na comparação entre as fichas técnicas, o

### Mudança 15
**Antes:** (ANC de 38dB) no mesmo ambiente: o W820NB cancelou mais ~20–30% do resíduo de ruído que o T13 ANC deixou passar. Para home office com AC, o T13 ANC é excelente — o W820NB é melhor, mas custa o dobro e é over-ear.
**Antes:** Resultado: excepcional — melhor cenário do produto.
**Depois:** declara 38dB contra os 28dB do T13 ANC — cerca de 10dB a mais no papel, o que na prática significa mais resíduo de ruído eliminado. Não fizemos a comparação lado a lado, e vale o alerta: números de ANC declarados por fabricantes não seguem um padrão único de medição, então servem como indicativo, não como placar exato. O W820NB custa cerca do dobro e é over-ear — outra categoria de produto.
**Depois:** Expectativa realista: é o melhor cenário para o T13 ANC.

### Mudança 16
**Antes:** Aqui o ANC mostrou sua limitação mais característica: o microfone feedforward capta o vento diretamente antes de processar o cancelamento, e isso gera um leve chiado de processamento audível — como um farfalhar interno. O fenômeno piora proporcionalmente com a intensidade do vento.
**Depois:** Aqui aparece a limitação mais característica dessa arquitetura, e ela é previsível pelo projeto: o microfone feedforward capta o vento diretamente antes de processar o cancelamento, o que gera um chiado audível — como um farfalhar interno. É também a queixa que mais se repete nas avaliações negativas de uso ao ar livre. O fenômeno piora proporcionalmente com a intensidade do vento.

### Mudança 17
**Antes:** Resultado: limitado com vento, requer mudança de modo.
**Depois:** Expectativa realista: limitado com vento, exige trocar de modo.

### Mudança 18
**Antes:** 28dB em um TWS de R$ 199 é uma das melhores relações custo-isolamento do mercado brasileiro. Para escritório e transporte público, o ganho de concentração é real. Para vento forte ao ar livre, use o Modo Transparência. O ANC do T13 supera qualquer earbud na mesma faixa de preço que testamos — e a maioria dos que custam até R$ 280.
**Depois:** 28dB em um TWS de R$ 199 é uma das melhores relações custo-isolamento do mercado brasileiro. Para escritório e transporte público, o ganho de concentração é real. Para vento forte ao ar livre, use o Modo Transparência. Entre os TWS que declaram ANC até cerca de R$ 250, os 28dB do T13 ANC estão entre os números mais altos anunciados — lembrando que essa é uma comparação de especificações declaradas, não de medições nossas.

### Mudança 19
**Antes:** 6. Bateria: Testamos na Prática
**Depois:** 6. Bateria: O Que os Números Oficiais Mostram

### Mudança 20
**Antes:** . Com ANC ativado, a autonomia dos fones cai para cerca de 5h — o processamento do cancelamento de ruído consome aproximadamente 30% a mais de energia. Os números são honestos: confirmamos as especificações nos testes com volume a 60%.
**Depois:** . Com ANC ativado, a autonomia dos fones cai para cerca de 5h — o processamento do cancelamento de ruído consome aproximadamente 30% a mais de energia. Não medimos a autonomia. Os números abaixo são os declarados pela QCY, e os relatos de compradores em geral os sustentam para volume moderado — com a ressalva de que autonomia varia com volume, codec e temperatura.

### Mudança 21
**Antes:** Autonomia real medida (volume 60%)
**Depois:** Autonomia declarada pelo fabricante (volume moderado)

### Mudança 22
**Antes:** QCY T13 ANC a R$ 169-186
**Depois:** QCY T13 ANC (R$ 169–186)

### Mudança 23
**Antes:** a R$ 229–380
**Antes:** ? A diferença de preço é de apenas R$ 30–50, mas a proposta de valor é distinta o suficiente para justificar uma análise cuidadosa.
**Depois:** (R$ 229–380)
**Depois:** ? Faixas apuradas em agosto de 2026. A diferença de preço é de apenas R$ 30–50, mas a proposta de valor é distinta o suficiente para justificar uma análise cuidadosa.

### Mudança 24
**Antes:** Preço (agosto 2026)
**Depois:** Preço (faixa apurada em 15/08/2026)

### Mudança 25
**Antes:** Produto analisado:
**Antes:** QCY T13 ANC Preto (unidade adquirida pelo autor)
**Depois:** Base da análise:
**Depois:** ficha técnica oficial da QCY, avaliações verificadas de compradores (Amazon e Mercado Livre) e comparação com concorrentes diretos. Não recebemos unidade do fabricante nem adquirimos uma para teste.

### Mudança 26
**Antes:** 🛒 Onde Comprar: Melhores Preços de Hoje
**Depois:** 🛒 Onde Comprar — preços apurados em 15/08/2026

### Mudança 27
**Antes:** Preços de agosto 2026 — confira o prazo de entrega com seu CEP.
**Depois:** Faixas de preço apuradas em 15/08/2026 — confira o valor atual e o prazo de entrega com seu CEP antes de comprar.


---

## JSON-LD (dentro do mesmo bloco colado)

**Antes:** `"description": "QCY T13 ANC Review 2026: ANC real de 28dB por R$ 169-186. Testamos som, bateria, chamadas e cancelamento de ruído em 3 ambientes. Veja se vale a pena.",`
**Depois:** `"description": "QCY T13 ANC Review 2026: ANC real de 28dB por R$ 169-186. Analisamos som, bateria, chamadas e cancelamento de ruído com base na ficha técnica oficial e em avaliações verificadas de compradores.",`

**Antes:** `"priceValidUntil": "2026-08-31"`
**Depois:** `"priceValidUntil": "2026-12-31"`
