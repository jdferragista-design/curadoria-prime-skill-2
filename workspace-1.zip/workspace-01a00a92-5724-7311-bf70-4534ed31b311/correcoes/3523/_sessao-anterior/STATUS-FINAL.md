# 3523 — QCY T13 ANC · ✅ FECHADO

**URL:** https://curadoriaprime.com/qcy-t13-anc-review-2026-vale-a-pena/
**Verificado no ar** (com `?LSCWP_CTRL=NOCACHE`) após a recolagem.

---

## Duplicação: resolvida

A colagem anterior tinha deixado o artigo em dobro (30 h2, 242 KB).
Agora: **15 h2, nenhum repetido**, página 153.855 B. Cópia antiga eliminada.

---

## Conferência final

### Alegações de teste físico — todas eliminadas
| Trecho | No ar |
|---|---|
| "Realizamos chamadas…" | 0 ✅ |
| "ao longo de duas semanas" | 0 ✅ |
| "nos testes realizados" | 0 ✅ |
| "participantes" (aspas fabricadas) | 0 ✅ |
| "unânime" | 0 ✅ |

### Bloco de cálculo da nota — publicado
"🧮 Como chegamos ao 8,5" · link para `/como-avaliamos/` · 8,55 · "O que essa nota não mede" · a conta `2,85 + 2,00 + …` — todos presentes, 1x cada.

### Mobile
6 tabelas / 6 wrappers `overflow-x` / 6 `min-width` / 6 avisos de deslize.
Chromium sobre a **URL real**: 360 px → scrollWidth 360 = clientWidth 360; 390 px → 390 = 390. **Zero estouro.**

### Integridade
- Palavras no ar: **5.845** — idêntico ao arquivo entregue. Nenhuma seção ausente.
- 9 imagens no corpo, todas **HTTP 200**; `data-lazyloaded` = 0 (sem resíduo do LiteSpeed).
- `8.5` com ponto no corpo: **0** (os 16 da página são CSS/JS do tema).
- Meta description do Rank Math: atualizada.

### Schema
2 blocos JSON-LD, ambos parseiam:
- head (`rank-math-schema`): Organization, WebSite, ImageObject, BreadcrumbList, WebPage, Person, Article
- corpo: Article, Product, FAQPage, BreadcrumbList

`aggregateRating` = **0** ✅ · `priceValidUntil` = 2026-12-31 ✅ · autor "Cristiano Martins" ✅

---

## Sobre "o arquivo não está o artigo completo"

`CORPO-para-colar.html` **está completo** — a comparação confirma:

| | arquivo | original |
|---|---|---|
| h2 | 15 | 15 |
| h3 | 7 | 6 (+1 do bloco novo) |
| imagens | 8 | 8 |
| links | 41 | 40 (+1: `/como-avaliamos/`) |
| tabelas | 6 | 5 (+1 do bloco novo) |
| `<li>` | 47 | 47 |
| palavras | 5.492 | 4.862 (+630) |

O que causa a impressão de incompleto: o arquivo é **só o `post_content`**, como tem que ser. Ele começa direto num `<div>` (o hero roxo) e termina no `</script>` do JSON-LD — sem `<html>`, sem `<head>`, sem `<h1>`. O `<h1>` do post é gerado pelo tema a partir do título do WordPress; se estivesse no arquivo, a página teria dois H1.

Aberto no navegador fora do WordPress ele parece "solto" — mas colado no editor de Código renderiza o artigo inteiro, que é exatamente o que aconteceu.

---

## Pendência menor (opcional)

O banner de cookies (WPConsent) cobre cerca de 1/3 da tela no celular e só some após interação. Não é defeito do post, é configuração do plugin — mas atrapalha a leitura em mobile. Vale rever depois.

---

## Próximo

**4675** — 8 graves / 34 ocorrências.
