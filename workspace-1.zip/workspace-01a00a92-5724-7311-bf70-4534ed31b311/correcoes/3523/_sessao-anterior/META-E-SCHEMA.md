# 3523 — o que sobra fora do bloco colável

O `CORPO-para-colar.html` agora inclui **tudo que pertence ao post**, inclusive o JSON-LD
(`Article` / `Product` / `Offer`), que estava no fim do conteúdo — e não injetado pelo tema,
como cheguei a supor.

Restou **1 campo**, e ele não vive no post: fica no Rank Math.

---

## 1. Meta description (Rank Math) — ÚNICO passo manual

**Onde:** editor do post 3523 → caixa **Rank Math SEO** (abaixo do editor) → aba **Geral** →
campo **Descrição**. Clique em "Editar snippet" se os campos estiverem recolhidos.

**Valor atual (trocar):**

> QCY T13 ANC Review 2026: testamos ANC de 28dB, bateria de 30h e qualidade de chamadas. Veja se vale a pena por R$ 169-186.

**Valor novo (colar) — 152 caracteres:**

```
QCY T13 ANC vale a pena em 2026? Análise da ficha oficial, dos rivais diretos e de 7 mil avaliações: ANC de 28dB e 30h de bateria por menos de R$ 200.
```

Motivo: "testamos" na meta description é a alegação mais visível de todas — aparece no
resultado do Google. Precisa cair junto com as do corpo, senão a página se contradiz na SERP.

---

## 2. O que NÃO mexer

**O segundo JSON-LD, o do `<head>`.** É gerado pelo Rank Math (`class="rank-math-schema"`) e
contém `WebSite`, `BreadcrumbList` e `ImageObject`. Não há alegação de teste nele e ele não é
editável pelo editor de post. Ignore.

**`aggregateRating`.** Não existe no schema deste post — e é bom que não exista. Não adicione:
nota agregada sem avaliações reais de usuários no site é violação de política estruturada do
Google.

**Nome do autor no schema.** Já está "Cristiano Martins". Correto, sem mudança.

---

## 3. Checklist de aplicação

- [ ] Colar `CORPO-para-colar.html` no Editor de código (substitui o JSON-LD junto)
- [ ] Trocar a meta description no Rank Math
- [ ] Atualizar o post
- [ ] Rodar a URL no [Teste de Resultados Ricos](https://search.google.com/test/rich-results) —
      deve continuar validando `Article` e `Product` sem erro
