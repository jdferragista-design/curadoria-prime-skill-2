# 3523 — QCY T13 ANC · como aplicar (versão final)

**Arquivo a colar:** `correcoes/3523/CORPO-para-colar.html` — 86.635 B
**URL:** https://curadoriaprime.com/qcy-t13-anc-review-2026-vale-a-pena/

---

## Estado atual do post no ar (verificado hoje)

| Item | Situação |
|---|---|
| Meta description (Rank Math) | ✅ **já atualizada** — confere com a versão aprovada |
| Corpo do post | ❌ ainda o antigo — falta esta colagem |
| `/como-avaliamos/` | ✅ no ar, HTTP 200 |
| Link recíproco na transparência | ✅ ativo |

Ou seja: **resta uma única colagem** e o 3523 fica fechado.

---

## Passo a passo

1. WordPress → Posts → **QCY T13 ANC Review 2026** → editor de **Código** (não o visual).
2. Selecionar **todo** o conteúdo atual e apagar.
3. Colar o conteúdo integral de `CORPO-para-colar.html`.
4. **Atualizar**.
5. LiteSpeed Cache → **Purge All**.
6. Abrir a URL no celular e conferir a seção "🧮 Como chegamos ao 8,5".

> ⚠️ Não mexer no JSON-LD do `<head>` (`rank-math-schema`). O JSON-LD que está dentro do corpo já vem no arquivo — não apagar.

---

## O que mudou nesta versão

### 1. Alegações de teste físico removidas (o motivo original)
- Seção 5: "Realizamos chamadas… ao longo de duas semanas" e a tabela com aspas de "participantes" inexistentes → reescritas como leitura de ficha técnica e de avaliações públicas.
- Bloco iOS: "não encontramos nenhum problema **nos testes realizados**" → negação sem alegação embutida.
- Varredura morfológica ampla (`\b\w+[aei]mos\b`): restam apenas negações legítimas e os `recebemos` de disclosure de afiliado.

### 2. Layout mobile corrigido
- 6 tabelas, todas em `<div style="overflow-x:auto; -webkit-overflow-scrolling:touch; max-width:100%">` com `min-width` na `<table>`.
- Wrappers decorativos com `padding: clamp()` + `box-sizing: border-box; max-width: 100%`.
- Aviso "↔ deslize para ver a tabela completa" acima de cada tabela.
- Testado em Chromium a 360 px e 390 px: `scrollWidth == clientWidth`, **zero estouro**.

### 3. NOVO — bloco de cálculo da nota (seção 11, logo após o veredito)
- `<h3>` "🧮 Como chegamos ao 8,5" + link para `/como-avaliamos/`.
- Tabela com os 5 critérios, peso, nota, contribuição e justificativa por linha.
- Bloco roxo com a conta: 2,85 + 2,00 + 2,25 + 0,80 + 0,65 = **8,55 → 8,5/10 ⭐ Recomendado**.
- Callout âmbar "O que essa nota não mede" (conforto, encaixe, timbre, durabilidade).

### 4. Padronização
- `8.5` → `8,5` no callout do topo. Nenhum `8.5` com ponto restou no corpo.

---

## Integridade verificada contra `.smoke/3523-src.html`

| Verificação | Resultado |
|---|---|
| Imagens | 8 = 8 ✅ (todas `src="https"`, sem lazy-load do LiteSpeed) |
| Links | 41 vs 40 — **+1 esperado**: `/como-avaliamos/` ✅ |
| `<h2>` | 15 ✅ · `<h3>` 7 (era 6, +1 do bloco novo) |
| JSON-LD do corpo | parseia ✅ |
| Tags não-fechadas | idênticas ao original publicado (`div, div, table, tbody, tr, td, strong`) ✅ |
| Soma dos pesos | 1,0 ✅ · soma das contribuições 8,55 ✅ |

---

## Depois de colar

1. Rodar a varredura do plugin no 3523 para confirmar a queda dos 10 graves.
2. Rebaixar o post na fila de urgência.
3. Próximo: **4675** (8 graves / 34 ocorrências).
