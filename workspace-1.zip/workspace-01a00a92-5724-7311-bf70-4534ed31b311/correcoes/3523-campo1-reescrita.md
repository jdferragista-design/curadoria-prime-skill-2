# 3523 — campo 1 (`alegacao_teste`), reescrita pronta para colar

## Como está

> Testamos o fone em uso diário por mais de duas semanas: chamadas no Google
> Meet e WhatsApp, transporte público, academia, home office e sessões longas
> de música. Veja o que encontramos.

Problema: afirma teste físico prolongado que não houve. É a frase que abre a
seção inteira de análise, então ela define a expectativa de tudo que vem
depois — inclusive do "1. Unboxing e Primeiras Impressões", que promete uma
caixa aberta pela redação.

## Como deve ficar — opção A (recomendada)

> Nossa análise do T13 ANC parte da ficha técnica oficial da QCY, da comparação
> ponto a ponto com os concorrentes diretos da faixa e da leitura sistemática
> de avaliações verificadas de compradores brasileiros e de análises técnicas
> já publicadas — com atenção especial aos cenários que mais aparecem nos
> relatos: chamadas em Google Meet e WhatsApp, transporte público, academia,
> home office e sessões longas de música. O que a documentação e os relatos
> sustentam está abaixo; conforto após horas de uso, encaixe na sua orelha e
> desempenho do microfone em rua movimentada dependem de variáveis pessoais
> que nenhuma análise documental resolve — e nós não tivemos o aparelho em
> mãos para verificar.

Mantém os cinco cenários (que são o valor real da frase), troca a origem da
informação e diz o que não dá para concluir. Fica um pouco maior que o
original — inevitável, porque declarar metodologia custa palavras.

## Opção B (mais curta, se preferir enxuto)

> Analisamos o T13 ANC pela ficha técnica da QCY, pela comparação com os rivais
> diretos da faixa e por avaliações verificadas de compradores nos cenários que
> mais importam: chamadas, transporte público, academia, home office e música.
> Sem ter o aparelho em mãos, não opinamos sobre conforto prolongado nem sobre
> o microfone em ambiente de rua.

## Cuidado que a IA não pegaria sozinha

Corrigir só esta frase deixa a seção seguinte inconsistente: **"1. Unboxing e
Primeiras Impressões"** descreve a caixa por dentro ("papelão reciclado com
janela plástica que mostra o estojo... Dentro dela:"). Ou o título vira algo
como **"O que vem na caixa (segundo o fabricante e fotos de compradores)"**, ou
a correção desta frase cria uma contradição interna pior que o problema
original.

Isso é decisão editorial sua — o plugin marca a frase, não reescreve a
arquitetura da seção.
