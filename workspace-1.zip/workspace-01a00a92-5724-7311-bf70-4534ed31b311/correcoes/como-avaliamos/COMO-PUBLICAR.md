# Página "Como Avaliamos" — como publicar

## 1. Criar a página

WordPress → **Páginas → Adicionar nova**.

| Campo | Valor |
|---|---|
| **Título** | Como Avaliamos e Pontuamos Produtos |
| **Slug (permalink)** | `como-avaliamos` |
| **URL final** | `https://curadoriaprime.com/como-avaliamos/` |
| **Modelo** | o mesmo usado em `/transparencia-curadoria-prime/` |

Editor → menu **⋮** → **Editor de código** → colar o conteúdo de
`PAGINA-para-colar.html` → voltar ao editor visual → **Publicar**.

> O bloco roxo do topo começa com um parágrafo grande, não com um `<h2>`, para não
> competir com o `<h1>` que o tema gera a partir do título da página.

---

## 2. Rank Math (a página nova precisa dos dois campos)

**Título SEO:**

```
Como Avaliamos Produtos: Nossa Metodologia de Pontuação
```

**Meta description** (154 caracteres):

```
Como o Curadoria Prime calcula as notas: 5 critérios com pesos declarados, o que nunca entra na pontuação e um exemplo real de cálculo passo a passo.
```

---

## 3. Ligar as páginas entre si

A página nova já aponta para transparência e para o "Sobre". Falta o caminho inverso:

**Em `/transparencia-curadoria-prime/`**, na seção "🔍 Nossa Metodologia de Análise",
logo após a lista das 5 etapas, inserir:

```html
<p style="font-size: 15px; color: #555; line-height: 1.8;">🔗 As notas que publicamos seguem uma régua fixa, com critérios e pesos declarados: <a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/como-avaliamos/">veja como calculamos a pontuação</a>.</p>
```

**No menu do rodapé**, adicionar "Como Avaliamos" junto de "Transparência" e "Sobre Nós".

---

## 4. Depois de publicar

- [ ] Abrir a URL e conferir se as 3 tabelas ficaram legíveis no celular
- [ ] Limpar o cache do LiteSpeed
- [ ] Conferir se os 4 links internos da página abrem

---

## Nota sobre o conteúdo

A página declara os limites do método em uma seção própria ("Os limites deste método"):
dependência da ficha do fabricante, ruído em avaliações de marketplace, os pesos como
escolha editorial, e o fato de não substituir teste de laboratório.

Isso parece contraintuitivo, mas é o que dá credibilidade ao resto. Uma metodologia que se
apresenta como infalível levanta mais suspeita do que uma que sabe onde é frágil — e é
exatamente o tipo de sinal de experiência e confiabilidade que o Google descreve no
framework "Quem / Como / Por quê".
