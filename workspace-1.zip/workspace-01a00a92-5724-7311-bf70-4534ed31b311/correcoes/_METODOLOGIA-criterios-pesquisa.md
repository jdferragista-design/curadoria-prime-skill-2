# Critérios de avaliação — pesquisa de referências e proposta

Documento de apoio para decidir o 6º critério da régua `/como-avaliamos/`.
Data: 15/08/2026. Nada aqui foi publicado ainda.

---

## 1. O que as referências fazem

### RTINGS (internacional, laboratório próprio)

Não usa **uma** nota. Usa **notas por cenário de uso** — Filmes, Esportes, Videogame, Monitor PC — e cada cenário tem **pesos diferentes** sobre os mesmos atributos medidos. O overall "Mixed Usage" é uma soma ponderada declarada publicamente (ex.: filmes 21,9%, TV shows 18,8%, jogos 10,4%).

Três lições aproveitáveis:

- **Pesos por contexto, não por produto.** Um mesmo atributo pesa diferente conforme o uso pretendido.
- **Test benches versionados.** Toda mudança de metodologia e de peso entra num pacote com número de versão, aplicado a todos os produtos ao mesmo tempo, para as notas continuarem comparáveis.
- **Isolamento de critério irrelevante.** Eles evitam penalizar um fone aberto por isolamento ruim quando o eixo avaliado é qualidade sonora. Critério que não se aplica não deve derrubar nota.

### Consumer Reports (internacional, laboratório + survey)

Overall Score combina **quatro** componentes: testes de laboratório, **confiabilidade prevista**, **satisfação do proprietário** e, em conectados, **privacidade e segurança de dados**.

- Os pesos **variam por categoria**, conforme a importância que o consumidor dá àquele fator naquela categoria — declarado abertamente.
- Faixas de peso publicadas: confiabilidade até 20%, satisfação do proprietário até 5%, testes de laboratório até 100%, privacidade até 40%.
- **Regra de veto:** marca com confiabilidade 1 ou 2 não recebe recomendação, por melhor que seja no laboratório.
- Satisfação é medida por *"qual a probabilidade de você recomendar a um amigo?"* — comportamental, não "você gostou?".

### Adrenaline (nacional, games)

Escala 0–10 com selos por faixa. A nota final é **prerrogativa livre do redator**, sem interferência editorial. Declaram a **versão testada** (o review de PC não vale automaticamente para PS5).

### Analisa Tudo (nacional, análise documental — o caso mais próximo do nosso)

Site que também **não faz teste físico**. Declara as fontes (ficha do fabricante, dados públicos de marketplace, avaliações agregadas) e publica a lista do que o método **não alcança**: durabilidade a longo prazo, ruído real, conforto, sensações de uso.

Critério de ordenação nº 1 deles: **adequação ao uso pretendido** — separam perfis de uso em vez de eleger um vencedor único. Critério nº 2: **especificações relevantes da categoria**, não a ficha inteira.

### Google — sistema de avaliações (documentação oficial)

Da página *Escrever avaliações de alta qualidade*, os itens que são literalmente critérios de nota:

- **"Use medidas quantitativas para avaliar o desempenho de algo em várias categorias."** — endossa nota por critério.
- **"Foque nos fatores de decisão mais importantes"** — e o exemplo dado é justamente ponderação: num carro, economia e segurança são decisivos e a classificação segue esses critérios.
- **"Explique o diferencial em relação aos concorrentes."**
- **"Discuta os benefícios e as desvantagens."**
- **"Aborde o que é mais indicado para determinados usos ou circunstâncias."**
- **"Considere incluir links para vários vendedores."**
- **"Descreva as principais opções de projeto e o efeito nos usuários, além das informações do fabricante."**

O sistema roda **continuamente** (não há mais update datado) e vale para português.

### Literatura de scoring (si-labs, Product School)

- 5 a 8 critérios é a faixa recomendada; **critérios independentes** entre si.
- Pesos definidos **antes** de pontuar, e não alterados depois — Tversky & Kahneman: ver as notas primeiro e "ajustar" o peso depois é otimizar para o resultado desejado.
- **Análise de sensibilidade** obrigatória: mexer ±10pp no critério dominante e verificar se o resultado vira.

---

## 2. Convergência: o que aparece em quase todas as réguas

| Fator | RTINGS | Consumer Reports | Analisa Tudo | Google | Régua atual |
|---|---|---|---|---|---|
| Desempenho / ficha | ✅ | ✅ | ✅ | ✅ | ✅ Ficha técnica |
| Satisfação de quem tem | — | ✅ | ✅ | ✅ | ✅ Satisfação verificada |
| Preço / valor | ✅ (Good Value) | ✅ | ✅ | ✅ | ✅ Custo-benefício |
| Confiabilidade / suporte | — | ✅ (veto) | — | ✅ | ✅ Confiança e suporte |
| Opinião de terceiros | — | — | — | ✅ | ✅ Consenso técnico |
| **Adequação ao uso / recursos** | ✅ **(eixo central)** | ✅ (usabilidade) | ✅ **(critério nº 1)** | ✅ | ❌ **ausente** |

**A lacuna é real e é a mesma nas quatro referências.** O que falta na régua não é "conectividade": é o eixo *o produto serve para quê, e opera bem nisso*.

---

## 3. Proposta de 6º critério

**Recursos e usabilidade — 10%**

> O que o produto oferece de função e como isso se traduz no uso diário: sistema e aplicativo, recursos declarados, controles, portas e conexões, praticidade de operação e manutenção.

**Fronteira com Ficha técnica** (para os critérios ficarem independentes, como manda a literatura): substantivo × verbo.

| Ficha técnica (o que o produto **é**) | Recursos e usabilidade (o que ele **faz**) |
|---|---|
| Bluetooth 5.3, SBC/AAC | Conecta em dois aparelhos ao mesmo tempo |
| Painel LED 60 Hz, α7 AI Gen8 | webOS 25, modo jogo, AirPlay 2 |
| Aço inox, 710 ml | Tampa Quick Flip, boca larga, cabe no porta-copos |
| i3-1215U, 8 GB | Teclado numérico, 2 USB-C, peso de mochila |

### Teste de cobertura no catálogo real (48 posts)

TV/imagem 8 · Fones 7 · Smartphone 7 · Áudio-soundbar 4 · Notebook 4 · Wearable 4 · Streaming 3 · Câmera 3 · Tablet 2 · Periférico 1 · Eletrodoméstico 1 · **Garrafa térmica 1** · Listicles 2.

"Recursos e conectividade" **falharia** em garrafa térmica, purificador e kit teclado/mouse. **"Recursos e usabilidade" cobre os 48.**

### Teste de posse física

Passa: recurso declarado está na ficha e no manual; a parte de operação se apoia em relato de comprador, sempre atribuído. Continua valendo a proibição de pontuar conforto, timbre e imagem subjetiva.

---

## 4. Pesos propostos e verificação

| Critério | Peso | QCY | LG |
|---|---|---|---|
| Custo-benefício | 30% | 9,5 → 2,850 | 8,5 → 2,550 |
| Satisfação verificada | 25% | 9,0 → 2,250 | 9,0 → 2,250 |
| Ficha técnica | 20% | 8,0 → 1,600 | 8,0 → 1,600 |
| **Recursos e usabilidade** | **10%** | 8,5 → 0,850 | 9,5 → 0,950 |
| Consenso técnico | 10% | 8,0 → 0,800 | 8,0 → 0,800 |
| Confiança e suporte | 5% | 6,5 → 0,325 | 8,5 → 0,425 |
| **Total** | **100%** | **8,675 → 8,5** | **8,575 → 8,5** |

Os 10 pontos saem de Ficha técnica (25→20) e Confiança e suporte (10→5). Não se mexe em Custo-benefício nem Satisfação verificada, os dois com justificativa mais forte na página.

**Nenhuma nota publicada muda.**

### Análise de sensibilidade (±10pp no dominante)

| Cenário | QCY | LG |
|---|---|---|
| CB 20% / Sat 35% | 8,625 → **8,5** | 8,625 → **8,5** |
| CB 30% / Sat 25% (proposto) | 8,675 → **8,5** | 8,575 → **8,5** |
| CB 40% / Sat 15% | 8,725 → **8,5** | 8,525 → **8,5** |

Resultado estável: nenhuma variação de peso vira a nota. A régua não está no fio da navalha.

---

## 5. Duas regras a adotar junto (vindas das referências)

**a) Critério não aplicável (RTINGS).** Quando um critério não existe no produto — consenso técnico de uma garrafa térmica, por exemplo — ele é marcado **N/A** e o peso é redistribuído proporcionalmente entre os demais. Testado: Stanley sem consenso técnico dá 8,389 sobre 90% de pesos aplicáveis → publica **8,5**. Sem essa regra, a alternativa seria dar nota inventada a um critério que não existe.

**b) Versão da régua (RTINGS test bench).** A régua passa a ter **v2 (agosto/2026)**, com changelog na própria página. Cada review declara sob qual versão foi pontuado. É o que mantém as notas comparáveis quando a metodologia muda.

---

## 6. Custo de implementar

Só **2 páginas** usam a régua hoje: `/como-avaliamos/` (4846) e o post **3523** (QCY T13 ANC). O 3002 entra como terceiro. Os outros 45 posts não têm tabela de critérios, então não há nada a recalcular.

## 7. Aresta separada, ainda aberta

A régua diz que a nota **não** vai para dados estruturados como rating agregado. O post 3523 cumpre (zero `aggregateRating`). O 3002 tem `aggregateRating 4,9/6707` — que é a nota dos **compradores do ML**, não a nota editorial 8,5. Defensável, mas precisa de decisão explícita.
