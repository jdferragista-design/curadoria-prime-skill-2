# Dia dos Pais 2026 → guia perene com faixas de preço

**Artigo:** https://curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/
**Decisão:** manter a página viva o ano todo (opção A) + preços em faixa (opção C).
**Preparado em 15/08/2026.**

Objetivo: nenhuma frase do artigo pode envelhecer sozinha. Sai tudo que
depende de "hoje" — prazo de entrega, data de chegada, centavos.

> **Como usar:** cada item traz `PROCURAR` (texto atual) e `SUBSTITUIR POR`
> (texto novo). No editor do WordPress use o modo **Código** (⋮ → Editor de
> código) e o Ctrl+F do navegador. Faça na ordem — os itens 1 a 8 são no
> corpo, 9 a 12 no bloco JSON-LD do fim.

---

## PARTE 1 — Tirar o relógio (6 edições)

### 1. Selo do topo

**PROCURAR:** `🚚 A tempo para o dia 09/08`

**SUBSTITUIR POR:** `🚚 Full (ML) e Prime (Amazon)`

E o selo ao lado:

**PROCURAR:** `🕒 Atualizado: 04/08/2026`
**SUBSTITUIR POR:** `🕒 Atualizado: 15/08/2026`

---

### 2. Caixa laranja "Escolha rápida" (a mais visível)

**PROCURAR:** `🎁 Escolha rápida — ainda dá tempo de chegar antes do dia 09/08`

**SUBSTITUIR POR:** `🎁 Escolha rápida — o atalho por perfil de pai`

E o rodapé da mesma caixa:

**PROCURAR:** `Preços de 04/08/2026 — confira o prazo de entrega com o seu CEP na página da loja antes de finalizar`

**SUBSTITUIR POR:** `Faixas de preço verificadas em 15/08/2026 — confira o valor e o prazo com o seu CEP na página da loja antes de finalizar`

---

### 3. Alerta 4️⃣ (caixa vermelha)

**PROCURAR:**
`<strong>4️⃣ Presente precisa chegar até 08/08.</strong> Compre com <strong>entrega Full (ML) ou Prime (Amazon)</strong> e confira o prazo na página do produto com o seu CEP antes de pagar — 04/08 ainda dá margem, 06/08 já é risco.`

**SUBSTITUIR POR:**
`<strong>4️⃣ Presente com data marcada?</strong> Compre com <strong>entrega Full (ML) ou Prime (Amazon)</strong> e confira o prazo na página do produto com o seu CEP antes de pagar. Fora das capitais, some 2 a 3 dias úteis à estimativa e evite deixar para a última semana.`

---

### 4. Lista "Este guia é para você se…"

**PROCURAR:** `<li>precisa receber <strong>antes de domingo, 09/08</strong>.</li>`

**SUBSTITUIR POR:** `<li>quer um presente que <strong>ele use todo dia</strong>, não algo que fica na gaveta.</li>`

---

### 5. Lista "NÃO é para você se…"

**PROCURAR:** `<li>você vai comprar <strong>depois de 06/08</strong> e precisa de entrega física a tempo (considere retirada ou presente digital).</li>`

**SUBSTITUIR POR:** `<li>você precisa do presente <strong>em menos de 48 h</strong> e não tem Full/Prime na sua região (considere retirada em loja ou presente digital).</li>`

---

### 6. FAQ — pergunta de prazo (aparece 2×: no corpo E no JSON-LD)

**Pergunta:**
**PROCURAR:** `Comprando agora, chega antes do Dia dos Pais (09/08)?`
**SUBSTITUIR POR:** `Quanto tempo antes eu preciso comprar?`

**Resposta (corpo):**
**PROCURAR:** `Comprando até 04–05/08, sim na maioria das regiões — priorize anúncios com entrega Full (Mercado Livre) ou Prime (Amazon) e confira o prazo exato com o seu CEP na página do produto. Depois de 06/08 o risco de atraso aumenta; deixamos apenas anúncios de lojas`

**SUBSTITUIR POR:** `Para uma data marcada, garanta pelo menos 5 dias úteis de folga — priorize anúncios com entrega Full (Mercado Livre) ou Prime (Amazon) e confira o prazo exato com o seu CEP na página do produto. Fora das capitais, some 2 a 3 dias. Deixamos apenas anúncios de lojas`

⚠️ Faça a mesma troca **de novo** dentro do `<script type="application/ld+json">` — o texto está duplicado lá (versão curta, ver item 12).

---

### 7. Abertura do texto

**PROCURAR:** `O Dia dos Pais 2026 cai em 9 de agosto — e se você chegou até aqui, provavelmente quer fugir do kit meia-cinto-carteira`

**SUBSTITUIR POR:** `Se você chegou até aqui, provavelmente quer fugir do kit meia-cinto-carteira`

---

### 8. Aviso de guia perene (bloco NOVO — colar logo abaixo do H1)

```html
<div style="background:#f0f9ff;border-left:4px solid #0284c7;border-radius:8px;padding:14px 18px;margin:0 0 24px;font-size:14.5px;line-height:1.6;color:#0c4a6e;">
  <strong>📌 Guia permanente.</strong> Publicado para o Dia dos Pais de 2026 e mantido no ar o ano todo — as cinco escolhas continuam válidas para aniversário, Natal ou qualquer data. Trabalhamos com <strong>faixas de preço</strong> em vez de valores exatos, porque o varejo muda de um dia para o outro: confira o valor final na página da loja. Última revisão de preços: <strong>15/08/2026</strong>.
</div>
```

---

## PARTE 2 — Preços em faixa (5 produtos)

Faixas calculadas sobre o que o produto realmente praticou entre 04/08 e
15/08, com margem para oscilar sem mentir. Regra: **nunca prometer o piso.**

| Produto | Visto em 04/08 | Visto em 15/08 | Faixa a publicar |
|---|---|---|---|
| Apple Pencil Pro | 1.349,00 | 1.286,10 | **R$ 1.250 a R$ 1.400** |
| Galaxy Watch7 44mm | 1.379,08 | 1.399,00 | **R$ 1.350 a R$ 1.500** |
| Anker 737 (ML) | 649,00 | 628,93 | **R$ 600 a R$ 700** |
| Liberty 4 NC | 379,05 | 407,55 | **R$ 370 a R$ 430** |
| JBL Wave Buds 2 | 227,05 | 242,25 | **R$ 220 a R$ 260** |

### Substituições rápidas (mesmo texto se repete em várias caixas)

| PROCURAR | SUBSTITUIR POR | Ocorrências |
|---|---|---|
| `R$ 1.379,08 no Pix` | `R$ 1.350 a R$ 1.500` | 5 |
| `R$ 379,05 no Pix` | `R$ 370 a R$ 430` | 6 |
| `R$ 227,05 no Pix` | `R$ 220 a R$ 260` | 5 |
| `R$ 649 c/ cupom` | `R$ 600 a R$ 700` | 5 |
| `R$ 1.349` (isolado, nas caixas-resumo) | `R$ 1.250 a R$ 1.400` | 3 |

⚠️ **Não troque em massa sem olhar.** As frases "Menor preço de hoje" e os
botões precisam de texto próprio — itens abaixo.

### Botões de compra

| PROCURAR | SUBSTITUIR POR |
|---|---|
| `🛍️ Ver na Amazon — R$ 379,05 no Pix` | `🛍️ Ver preço na Amazon` |
| `🛍️ Ver na Amazon — R$ 227,05` | `🛍️ Ver preço na Amazon` |
| `🛍️ Ver na Amazon — R$ 1.399 (12×)` | `🛍️ Ver preço na Amazon` |

Botão sem preço nunca fica desatualizado. Mantenha os de ML como estão
("Ver no Mercado Livre").

### Frases "Menor preço de hoje" (uma por seção)

Essas prometem um número exato num dia específico. Reescrever assim:

**Apple Pencil Pro** — PROCURAR: `Tabela oficial: R$ 1.499. Menor preço verificado hoje: R$ 1.349,00 à vista na Amazon (Loja Apple, Anatel 02677-24-01993, 12× R$ 112,49 sem juros)`
→ `Tabela oficial: R$ 1.499. Na Loja Apple dentro da Amazon costuma sair entre <strong>R$ 1.250 e R$ 1.400</strong> à vista, parcelável em 12× sem juros (Anatel 02677-24-01993) — abaixo da tabela da própria Apple.`

**Galaxy Watch7** — PROCURAR: `Menor preço de hoje: R$ 1.379,08 no Pix no Mercado Livre (8% OFF sobre R$ 1.499; Loja oficial Samsung, +10 mil vendidos)`
→ `Faixa usual: <strong>R$ 1.350 a R$ 1.500</strong>, com o Mercado Livre (Loja oficial Samsung, +10 mil vendidos) em geral levando vantagem no Pix sobre a tabela de R$ 1.499.`

**Anker 737** — PROCURAR: `Menor preço de hoje: R$ 649 com cupom no Mercado Livre (53% OFF sobre R$ 1.408 · 10× R$ 64,90 sem juros · anúncio com`
→ `Faixa usual: <strong>R$ 600 a R$ 700</strong> com cupom no Mercado Livre — bem abaixo da referência de R$ 1.408, em 10× sem juros · anúncio com`

**Liberty 4 NC** — PROCURAR: `Menor preço de hoje: R$ 379,05 à vista no Pix na Amazon (5% OFF) · R$ 399 em 7× de R$ 57 sem juros nas duas lojas`
→ `Faixa usual: <strong>R$ 370 a R$ 430</strong> à vista no Pix na Amazon, ou por volta de R$ 399 em 7× sem juros nas duas lojas`

**JBL Wave Buds 2** — PROCURAR: `Menor preço de hoje: R$ 227,05 à vista no Pix na Amazon (5% OFF; +2 mil compras no mês passado) ou 6× de R$ 39,85 sem juros`
→ `Faixa usual: <strong>R$ 220 a R$ 260</strong> à vista no Pix na Amazon (+2 mil compras/mês) ou em 6× sem juros`

### Rodapés de preço

| PROCURAR | SUBSTITUIR POR |
|---|---|
| `Preços capturados nas lojas em 04/08/2026 (sujeitos a alteração)` | `Faixas verificadas em 15/08/2026 — o valor final varia por dia, cupom e forma de pagamento. Confirme na loja.` |
| `Preços verificados em 04/08/2026 e sujeitos a alteração a qualquer momento` | `Faixas verificadas em 15/08/2026. Preço de varejo muda sem aviso — o valor da loja é o que vale.` |
| Coluna da tabela: `Preço hoje (04/08)` | `Faixa de preço` |

---

## PARTE 3 — Schema (bloco `<script type="application/ld+json">`)

### 9. Preços do JSON-LD

`Offer.price` exige número exato — não aceita faixa. Duas saídas:

**Recomendado:** trocar `Offer` por `AggregateOffer`, que existe justamente
para faixa. Para cada um dos 5 produtos:

```json
"offers": {
  "@type": "AggregateOffer",
  "priceCurrency": "BRL",
  "lowPrice": "1250.00",
  "highPrice": "1400.00",
  "offerCount": 2,
  "availability": "https://schema.org/InStock",
  "url": "…mantenha a URL que já está lá…"
}
```

Valores por produto:

| Produto | lowPrice | highPrice |
|---|---|---|
| Apple Pencil Pro | 1250.00 | 1400.00 |
| Galaxy Watch7 | 1350.00 | 1500.00 |
| Anker 737 | 600.00 | 700.00 |
| Liberty 4 NC | 370.00 | 430.00 |
| JBL Wave Buds 2 | 220.00 | 260.00 |

Remova as 5 linhas `"priceValidUntil": "2026-08-31"` — data no passado
derruba o rich result.

### 10. Nome do autor

**PROCURAR:** `"name":"Cristiano"}`
**SUBSTITUIR POR:** `"name":"Cristiano Martins"}`

(no bloco do Rank Math; o segundo bloco já traz "Cristiano Martins")

### 11. Fuso horário — ⚠️ ajuste global, não do artigo

O Rank Math está emitindo `+03:00` (Moscou) em vez de `−03:00`:

`"datePublished":"2026-08-04T15:00:22+03:00"`

Isso vem de **Configurações → Geral → Fuso horário** no WordPress, que deve
estar em UTC+3 ou em uma cidade errada. Troque para **São Paulo** — corrige
os 48 artigos de uma vez. Não edite o artigo para isso.

### 12. Datas divergentes entre os dois blocos

Bloco Rank Math: `dateModified 2026-08-15T03:53:20`
Bloco manual: `dateModified 2026-08-04T15:00:00-03:00`

Depois destas edições, atualize o bloco manual para
`"dateModified": "2026-08-15T18:00:00-03:00"` (ou o horário real da
publicação da correção). Os dois precisam bater.

---

## PARTE 4 — A contradição do "testamos"

Reli o artigo inteiro e **isto não é bem um erro** — é ambiguidade de
redação. O disclaimer diz:

> "não testamos estas unidades fisicamente"

E em três produtos o texto diz "Já testamos o Watch7 na bancada", "Já
testamos — leia nossa review do Liberty 4 NC", "Também testado por nós —
JBL Wave Buds 2".

Não é mentira: **você testou os modelos**, em reviews próprias linkadas; o
que não testou foram *estas unidades específicas* compradas para o guia. Só
que o leitor rápido lê "não testamos" logo acima de "já testamos" e sente
contradição. Basta desfazer o nó:

**PROCURAR:** `🔍 Tipo de análise: pesquisa técnica + dados agregados de compradores verificados — não testamos estas unidades fisicamente ; quando um artigo tiver teste próprio, ele trará o selo “Testado por nós”.`

**SUBSTITUIR POR:** `🔍 Tipo de análise: pesquisa técnica + dados agregados de compradores verificados. Três dos cinco produtos deste guia — Galaxy Watch7, Liberty 4 NC e JBL Wave Buds 2 — passaram pela nossa bancada e têm review própria publicada (link em cada seção). Apple Pencil Pro e Anker 737 <strong>não</strong> foram testados por nós: a análise deles é documental, a partir de fonte oficial do fabricante.`

Isso é mais forte que o texto atual: em vez de um disclaimer defensivo, você
declara exatamente onde há experiência de primeira mão — que é o critério
que o Google passou a pesar em 2026.

---

## Checklist

```
Prazo/urgência
[ ] 1. selo "A tempo para o dia 09/08"      [ ] selo data → 15/08
[ ] 2. caixa laranja + rodapé
[ ] 3. alerta 4️⃣
[ ] 4. lista "é para você"
[ ] 5. lista "NÃO é para você"
[ ] 6. FAQ prazo — corpo E schema
[ ] 7. abertura "cai em 9 de agosto"
[ ] 8. bloco novo de guia permanente

Preços em faixa
[ ] Watch7 (5×)   [ ] Liberty (6×)   [ ] JBL (5×)
[ ] Anker (5×)    [ ] Pencil (3×)
[ ] 3 botões sem preço
[ ] 5 frases "Menor preço de hoje"
[ ] 3 rodapés + coluna da tabela

Schema
[ ]  9. AggregateOffer nos 5 + remover priceValidUntil
[ ] 10. "Cristiano" → "Cristiano Martins"
[ ] 11. fuso São Paulo (Configurações → Geral) ← global
[ ] 12. dateModified igual nos 2 blocos

Metodologia
[ ] Parte 4 — quem foi testado e quem não foi

Depois
[ ] Rich Results Test na URL
[ ] Search Console → Inspecionar URL → Solicitar indexação
```

---

## O que isso resolve

Depois destas edições nada no artigo depende de data: sem prazo de entrega,
sem "hoje", sem centavos. A revisão vira trimestral e só para conferir se as
faixas ainda batem — não mais mensal.

**A faixa não te livra de uma coisa:** se um produto sair de linha ou dobrar
de preço, a faixa fica errada igual. Vale um lembrete no calendário para
novembro/2026 (Black Friday mexe em tudo) e outro em julho/2027, quando este
guia volta a ser sazonal e você pode reaproveitar a mesma URL com a
autoridade toda acumulada.
