# Post 3002 — LG 55AU801 · ENCERRADO ✅

**Publicado e verificado em 15/08/2026** (`modified` 21:26:12 · 53.642 B renderizados).

## Verificação final na página publicada (via REST API)

| Item | Resultado |
|---|---|
| Comentários HTML | **0** |
| `<p></p>` vazios | **0** |
| Containers grid | **5**, nenhum com parágrafo fantasma |
| Widget da régua v2 | presente |
| 6º critério "Recursos e usabilidade" | presente |
| `aggregateRating` no schema | **ausente** (correto) |
| Widget antigo "Notas por categoria" | **ausente** (correto) |
| Nota `8,5` com vírgula | 6 ocorrências |

## O que foi corrigido nesta rodada

- **A.** 9 alegações de teste físico removidas (análise documental declarada).
- **B.** Schema: autor Cristiano Martins, logo `.webp` 200, `reviewRating` 8.5/10, datas ISO, `mainEntityOfPage`/`offerCount`/`worstRating`/`reviewBody`. `aggregateRating` **removido** por decisão do usuário (alinha com a régua e com o 3523).
- **C.** Transparência: bloco do autor canônico, origem da nota, aviso de preços datado 15/08/2026.
- **D.** Prova social reconstruída com dados reais (ML 4,9/6.707 · Amazon 4,3/66); números falsos zerados (`784`, `88%`, `4,6`, `+800`, `julho de 2026`).
- **E.** CTAs Amazon `link.amazon/B02n197Bw` em 2 pontos.
- **F.** 3 links para `/como-avaliamos/`.
- **G.** Widget convertido para os 6 critérios da régua v2 (média ponderada, 8,575 → 8,5). Som e Design saíram da pontuação; conteúdo permanece em texto.
- **H.** Separador decimal: vírgula no texto, ponto no JSON-LD.
- **I.** **Defeito de layout:** 26 comentários HTML removidos. O `wpautop` os convertia em `<p></p>`, que viravam filhos diretos dos containers `display:grid` e consumiam célula, desalinhando os cards em "Prós e Contras", "Para Quem é Indicada" e nos cards de compra finais.

## Backups
- `.smoke/3002-bkp-antes-prova-social.html` (49.346 B)
- `.smoke/3002-bkp-antes-comoavaliamos.html` (50.353 B)
- `.smoke/3002-bkp-antes-regua-v2.html` (50.723 B)
- `.smoke/3002-bkp-antes-fix-grid.html` (54.638 B)

## ⚠️ Pendência aberta por este post

O widget do 3002 aponta para `/como-avaliamos/`, **que ainda tem 5 critérios**. Quem clicar em "Como calculamos esta nota" vê régua desatualizada.

Ordem para resolver:
1. **Post 4846 `/como-avaliamos/`** — subir a régua v2: 6º critério, novos pesos (CB 30 / Sat 25 / Ficha 20 / Recursos 10 / Consenso 10 / Confiança 5), regra de critério N/A com peso redistribuído, changelog de versão.
2. **Post 3523 (QCY T13 ANC)** — acrescentar "Recursos e usabilidade" 8,5; Ficha 25→20%, Confiança 10→5%. Nota publicada continua 8,5 (8,675).

Rascunho da fundamentação: `/home/user/correcoes/_METODOLOGIA-criterios-pesquisa.md`.

## Fora de escopo (segue pendente)
- `uploads/logo.png` 404 em outros 52 artigos
- Título / H1 / slug — usuário decidiu não mexer
- Itens C (preços sem data em outros trechos) e E (`~180W`/`150W`, `300-350 nits`)

## Fila
**3523 ✅ · 4541 ✅ · 3002 ✅** · 4675 (pausa) · 4474 · 4683 · 4251 · 4709 · 2982 · 3545 · 2892 · 4414 · 4397

Posts **4155** (TCL C6K) e **3126** (Samsung U8100F) citam o LG 55AU801 e só oferecem ML — aplicar `link.amazon/B02n197Bw` nos dois.

## ⚠️ Lição para os próximos posts
**Nunca deixar comentários HTML dentro de containers `display:grid` ou `display:flex`.** O `wpautop` os transforma em parágrafos que ocupam célula do grid. O mesmo vale para linhas em branco entre filhos diretos desses containers. Vale rodar a checagem de filhos diretos antes de entregar qualquer post com grid.

**Publicação:** o site usa **LiteSpeed Cache**. Depois de atualizar, fazer *Purge All* — senão a versão antiga continua sendo servida.
