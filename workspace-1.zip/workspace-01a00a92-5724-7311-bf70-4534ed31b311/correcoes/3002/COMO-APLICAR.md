# Post 3002 — LG 55AU801 · Como aplicar

**Arquivo a colar:** `CORPO-para-colar.html` (54.638 B · ~2.900 palavras)
**Data da apuração:** 15/08/2026

---

## Como aplicar (2 minutos)

1. WordPress → **Posts → 3002** (LG 55AU801) → abrir no editor.
2. Alternar para o **Editor de código** (⋮ no canto superior direito → *Editor de código*, ou `Ctrl+Shift+Alt+M`).
3. **Selecionar tudo** (`Ctrl+A`) e **apagar**.
4. Abrir `CORPO-para-colar.html`, copiar **todo** o conteúdo e colar.
5. **Atualizar**.
6. Voltar ao Editor visual só para conferir — não é necessário salvar de novo.

> O arquivo é o corpo **completo** do post, já com o JSON-LD no final. Não é patch, não precisa mesclar nada.

### Meta description (Yoast/RankMath — campo separado)

```
Vale a pena a LG 55AU801 em 2026? Análise documental da ficha técnica oficial, do consenso de reviews técnicos e de 6.707 avaliações reais de compradores. Preços de 15/08/2026.
```

---

## O que mudou nesta rodada

### 1. Prova social reconstruída com dados reais (o item central)

O bloco antigo — `🏆 Aprovado por +784 Compradores`, `88% dos compradores aprovam`, nota `4,6` — foi **removido inteiro** e substituído por um bloco com quatro cards e números conferidos na fonte, nos dois marketplaces:

| | Amazon | Mercado Livre |
|---|---|---|
| Nota oficial | **4,3/5** | **4,9/5** |
| Avaliações | **66** | **6.707** (3.368 com texto) |
| Identificador | ASIN `B0FVFZDYG7` | item `MLB4615627273` |

Os cards trazem **duas citações positivas e duas críticas** (Amazon 1★ do Eliseu; ML 3★ da traseira solta), todas verbatim de compradores verificados, e um parágrafo explicando **por que as duas médias divergem** — o ML agrega o catálogo do modelo, a Amazon mede um anúncio específico.

### 2. Todos os números falsos eliminados do texto

| Antes | Depois | Onde |
|---|---|---|
| `784` (15 ocorrências) | `6.707` / "milhares" | lead, metodologia, cards, veredito, fontes, schema, FAQ |
| `4,6` e `4.6` (6 ocorrências) | `4,9` (ML) + `4,3` (Amazon) | corpo e `aggregateRating` |
| `88% dos compradores aprovam` | `84,7% de notas 4 e 5 estrelas` | bloco de prova social |
| `+800 avaliações` | `6.707 avaliações` | meta description |
| `consultadas em julho de 2026` | `consultadas em 15 de agosto de 2026` | metodologia e fontes |

O `84,7%` não é estimativa: veio da varredura estrela a estrela dos 503 comentários com texto do Mercado Livre (5★ 320 · 4★ 106 · 3★ 29 · 2★ 6 · 1★ 42).

### 3. Schema JSON-LD

O `aggregateRating` foi **removido**. A régua diz que a nota editorial não vai para dados estruturados como rating agregado, e o post 3523 já cumpre isso (zero `aggregateRating`). O 4,9/6707 que estava ali era a nota dos **compradores do Mercado Livre**, não a nota editorial 8,5 — publicar as duas juntas confunde a origem e arrisca marcação enganosa.

Permanece o `reviewRating` 8.5/10 dentro do objeto `Review`, que é a nota editorial e tem autoria declarada (Cristiano Martins). JSON validado com `json.loads` — sem erro de sintaxe.

**Efeito prático:** a página deixa de concorrer à estrelinha de produto no resultado de busca. É perda real, e foi escolha consciente — a alternativa era manter no schema um número que a própria régua diz não publicar.

### 4. Botões da Amazon nos dois cards de compra

Adicionado `https://link.amazon/B02n197Bw` (afiliado, `tag=martins73-20`) ao lado do botão do Mercado Livre, em **dois** pontos: o card **"Onde Comprar"** e o card final **"Pronto para Comprar"**. Ambos com `rel="sponsored noopener noreferrer nofollow"`.

O card "Onde Comprar" passou a exibir **R$ 2.297 na Amazon** no lugar do genérico `~R$ 2.400`.

**Confirme este ponto:** deixei a caixa de prova social **sem** botão de compra — ela agora é informativa, e empilhar CTA ali enfraquece a leitura dos dados. Se preferir um terceiro botão lá, é só pedir.

---

## Sobre o link da Amazon

O ASIN que você me passou (`B0F5X39JQ1`) é **outro produto** — LG 55UA85 / `A8550PSA`. Os dois compartilham processador α7 AI Gen8 e webOS 25, o que torna a confusão fácil, mas são modelos distintos.

Seu link `https://link.amazon/B02n197Bw` resolve para `/dp/B0FVFZDYG7` → **LG 55" LED 4K UHD Smart Pro 55AU801C0SA**, que é o produto do artigo. É esse que está no HTML.

---

## Verificações executadas

- `784`, `88%`, `4,6`, `4.6`, `+800`, `julho de 2026` → **0 ocorrências**
- JSON-LD → **válido** (`json.loads` sem erro) · `aggregateRating` → **0 ocorrências**
- Tags balanceadas: `a` 23/23 · parser HTML completo sem tag aberta e sem fechamento fora de ordem
- Render em **800px e 390px** → sem estouro horizontal (`scrollWidth == viewport`)
- Nota e contagem do ML reconferidas ao vivo antes de escrever: `4.9` / `6707` / `3.368 comentários`
- Nota e distribuição da Amazon reconferidas ao vivo: `4,3` · 5★ 80% · 4★ 3% · 3★ 0% · 2★ 2% · 1★ 15%


### 6. Widget de notas convertido para a régua v2 (mudança estrutural)

Esta é a maior alteração da rodada. As seis caixinhas antigas — Processamento 9.5 · Tela 8.0 · webOS 9.5 · Som 6.5 · Design 9.0 · Custo-benefício 8.5, em **média simples** — foram substituídas pela tabela dos **seis critérios da régua**, em média ponderada:

| Critério | Peso | Nota | Contribuição |
|---|---|---|---|
| Custo-benefício | 30% | 8,5 | 2,550 |
| Satisfação verificada | 25% | 9,0 | 2,250 |
| Ficha técnica | 20% | 8,0 | 1,600 |
| **Recursos e usabilidade** *(novo)* | 10% | 9,5 | 0,950 |
| Consenso técnico | 10% | 8,0 | 0,800 |
| Confiança e suporte | 5% | 8,5 | 0,425 |
| **Total** | **100%** | | **8,575 → 8,5** |

**A nota publicada continua 8,5.** Nada que o leitor viu antes mudou de valor.

Por que converter e não só renomear: as caixas antigas mediam **dimensões do produto** (som, design), e a régua proíbe pontuar exatamente essas duas sem posse física. Renomear manteria a contradição. O conteúdo sobre som e design **permanece no texto** — sai só a nota numérica, e há um parágrafo no rodapé do widget explicando essa ausência.

O layout segue o mesmo padrão do post 3523, que já usa a régua: tabela com coluna "Por que essa nota", scroll horizontal no mobile e aviso "↔ deslize".

**Depende de duas mudanças na página `/como-avaliamos/`** — o 6º critério e o changelog da v2. Elas ainda não foram feitas. Se este post for publicado antes, o leitor que clicar em "Como calculamos esta nota" vai ver cinco critérios, não seis.

---

## Fora de escopo (permanece pendente)

- `uploads/logo.png` com 404 em outros 52 artigos
- Título / H1 / slug — você decidiu não mexer
- Itens **C** (preços sem data em outros trechos) e **E** (`~180W`/`150W`, `300-350 nits`) — não tratados

## Ordem de publicação (importante)

1. **`/como-avaliamos/` (post 4846)** — subir a régua v2: 6º critério, novos pesos, regra de critério N/A e changelog. **Antes** do 3002.
2. **Post 3523 (QCY T13 ANC)** — acrescentar a linha "Recursos e usabilidade" 8,5 e ajustar Ficha técnica de 25% para 20% e Confiança de 10% para 5%. A nota publicada continua 8,5 (8,675). É o único outro post com a régua aplicada.
3. **Post 3002** — este arquivo.

Se preferir publicar o 3002 já, tudo bem: o texto está correto sozinho. Só o link da régua fica temporariamente desatualizado.

## Depois disso

Posts **4155** (TCL C6K) e **3126** (Samsung U8100F) citam o LG 55AU801 e oferecem só o Mercado Livre. O mesmo `link.amazon/B02n197Bw` se aplica aos dois — mas só depois que o 3002 estiver publicado.
