# Página 4846 — /como-avaliamos/ · régua v2.0

**Atenção:** 4846 é uma **PÁGINA**, não um post. No WP: **Páginas → Como Avaliamos e Pontuamos Produtos**.

## Passo a passo
1. Abrir a página 4846 no editor.
2. Menu ⋮ (canto superior direito) → **Editor de Código**.
3. `Ctrl+A` → `Delete` → colar todo o conteúdo de `CORPO-para-colar.html`.
4. **Atualizar**.
5. LiteSpeed Cache → **Purge All**.
6. Abrir `https://curadoriaprime.com/como-avaliamos/` em aba anônima e conferir.

## O que mudou (v1.0 → v2.0)
- H2 "Os **5** critérios" → "Os **6** critérios".
- Tabela de critérios: novo **Recursos e usabilidade 10%** (com selo NOVO); Ficha técnica 25%→**20%**; Confiança e suporte 10%→**5%**. Soma = 100% (verificado por assert).
- Nova caixa **"Quando um critério não se aplica"**: N/A com redistribuição proporcional + exemplo numérico.
- "Por que esses pesos" reescrito com os 6 critérios e a fronteira ficha (o que o hardware **é**) × recursos (o que o produto **faz**).
- "O que nunca entra na nota": parágrafo novo delimitando o que Recursos e usabilidade **não** avalia (fluidez, resposta ao toque).
- Exemplo QCY: tabela com 6 linhas, Recursos 8,5; a conta passa a **8,675 → 8,5**; parágrafo novo explicando por que não vira 8,7.
- "Os limites deste método": teste de **sensibilidade ±10pp** (CB 20/40) documentado — nota permanece 8,5.
- **Seção nova "Versão da régua e histórico de mudanças"**: selo da versão vigente + tabela de changelog v2.0/v1.0 + regra de que mudança de versão não recalcula o catálogo automaticamente.
- Selo "Régua v2.0 · agosto de 2026 · 6 critérios" no hero roxo.
- "Quando revisamos uma nota": novo item "A régua muda de versão".

## Checagens executadas
- 0 comentários HTML · 0 `<p></p>` · 0 linhas em branco (imune ao bug do `wpautop`).
- Aninhamento de tags: 0 erros, 0 tags abertas.
- 4 tabelas, todas com contagem de colunas uniforme por linha.
- Playwright: `scrollWidth` == viewport em 800px e 390px (sem estouro horizontal).
- `wc -c` na hora: **28.857 B**.

## Backups
- `_original-live.html` (20.122 B) — versão que estava no ar.
- `/home/user/.smoke/4846-bkp-antes-regua-v2.html` — mesma cópia.
