# Página 4846 — /como-avaliamos/ · ENCERRADA ✅

**Publicada e verificada em 2026-08-15.**

## Verificação na página publicada (REST `pages/4846?context=view`)
- `modified`: **2026-08-15T21:42:18**
- Bytes renderizados: **28.857 B** — **idêntico byte a byte** ao `CORPO-para-colar.html` entregue.
- 0 comentários HTML · 0 `<p></p>` · 4 tabelas com colunas uniformes (7×4, 6×3, 7×3, 3×3).
- Pesos lidos da tabela publicada: 30 · 25 · 20 · 10 · 10 · 5 = **100%**.
- Marcadores v2 presentes: "Os 6 critérios" · "Recursos e usabilidade" (6×) · "Régua v2.0" · "8,675" (3×) · "Versão da régua e histórico" · "Quando um critério não se aplica" · teste de ±10pp.
- Marcadores v1 ausentes: "Os 5 critérios" · "8,55". ✅

## Itens aplicados
- A — H2 "Os 5 critérios" → "Os 6 critérios".
- B — Tabela de critérios com Recursos e usabilidade 10% (selo NOVO); Ficha 25→20%; Confiança 10→5%.
- C — Caixa "Quando um critério não se aplica": N/A com redistribuição proporcional + exemplo numérico.
- D — "Por que esses pesos" reescrito para 6 critérios, com a fronteira ficha (o hardware **é**) × recursos (o produto **faz**).
- E — "O que nunca entra na nota": delimitação do que Recursos e usabilidade não avalia.
- F — Exemplo QCY com 6 linhas; conta **8,675 → 8,5**; parágrafo sobre por que não vira 8,7.
- G — "Os limites deste método": teste de sensibilidade ±10pp documentado (CB 20/40 → sempre 8,5).
- H — Seção nova "Versão da régua e histórico de mudanças" com selo da versão vigente e changelog v2.0/v1.0.
- I — Selo "Régua v2.0 · agosto de 2026 · 6 critérios" no hero.
- J — "Quando revisamos uma nota": novo item "A régua muda de versão".

## Backups
- `_original-live.html` (20.122 B) — versão v1.0 que estava no ar.
- `/home/user/.smoke/4846-bkp-antes-regua-v2.html` — mesma cópia.

## Lições de processo
- **4846 é PÁGINA, não post.** `wp-json/wp/v2/posts/4846` → `rest_post_invalid_id`. Usar `pages/4846`.
- Checagem anti-`wpautop` (0 comentários, 0 `<p></p>`, 0 linhas em branco) rodada **antes** da entrega — sem retrabalho desta vez.
- Comparar bytes do REST contra o arquivo local é o teste definitivo de "colou certo".

## Aberto
- Os artigos publicados ainda declaram a régua antiga quando citam pesos. Próximo: **3523**.
