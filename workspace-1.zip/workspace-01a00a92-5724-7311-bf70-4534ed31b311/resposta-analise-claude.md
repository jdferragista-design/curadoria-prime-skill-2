# Resposta à análise do Ai-skill como implementação de Google Review Quality Standards

Obrigado pela análise — a estrutura de notas por eixo é útil e três das cinco lacunas
que você aponta são reais. Antes de aceitar o pacote inteiro, porém, reli o repositório
linha a linha, e duas das lacunas descrevem algo que o repo não faz. Vou separar o que
aceito do que contesto, sempre citando o arquivo.

---

## 1. "Não aborda original research" — contesto

A análise avaliou `regras_editoriais_ia_curadoria_prime.md` e os `articles/`, mas não
parece ter aberto `skills/curadoria-mercado/`. É onde está o ativo.

O repositório mantém `skills/curadoria-mercado/assets/historico-precos/LEDGER.csv`:
30 capturas de preço, 8 SKUs, chave composta `data+sku_id+loja+variante`, com colunas
separadas para preço à vista, parcelado, preço "de", tipo de vendedor e URL da captura.
`tools/ledger.py` recusa data futura, captura sem preço, duplicata idêntica e URL de
catálogo `/p/MLB…` — esta última porque catálogo do Mercado Livre não é anúncio e o
preço exibido pode ser de outro vendedor. A ferramenta ainda gera a frase conforme o
número de capturas do SKU: uma vira "nesta data", duas viram "subiu/caiu", três ou mais
viram "faixa observada".

Isso é original research. É dado primário, datado, coletado por método declarado,
verificável pela URL, e que **nenhum concorrente brasileiro publica** — ninguém rastreia
preço de tablet por variante e por loja no Brasil de forma sistemática.

A crítica correta não é "falta original research". É **"o original research existe e
está subutilizado"**: 8 SKUs no LEDGER para 48 artigos no ar. O gargalo é cobertura e
exposição editorial do dado, não ausência de política. E a §5.1 já exige três elementos
próprios por artigo, listando treze opções concretas — custo total com acessórios
obrigatórios, divergências entre fichas de lojas, versão nacional vs. importada,
homologação e assistência no país.

---

## 2. "Byline oculta o uso de IA" — contesto o diagnóstico

A §2.6 diz, textualmente:

> A assinatura pertence à pessoa que verificou e aprovou o conteúdo. A IA não deve
> atribuir automaticamente um artigo a Cristiano Martins ou a qualquer outra pessoa.

E a §1:

> A IA **não publica autonomamente**. Todo artigo deve ser conferido e aprovado por um
> editor humano, que assume a responsabilidade pelo conteúdo e pela assinatura.

Isso não é ocultação. É **atribuição de responsabilidade editorial** — a assinatura
identifica quem responde pelo conteúdo, que é precisamente o que o Google pede. A
orientação oficial do Google sobre conteúdo gerado por IA diz que dar byline à IA
"provavelmente não é a melhor abordagem" e recomenda creditar autores, editores ou
revisores humanos reais. Disclosure de IA é descrito como útil "quando o leitor
razoavelmente se perguntaria como isto foi criado" — recomendação condicional, não
requisito. Não existe política do Google que penalize a ausência de disclosure de IA.

Há ainda um risco na sua recomendação que a análise não pesa: um selo "escrito com
auxílio de IA" aplicado de forma indiscriminada, num site cujo problema real é ter
publicado alegações de teste que não ocorreram, não aumenta confiança — ele apenas
convida o leitor a descontar o conteúdo, enquanto o problema de fundo (a alegação falsa)
continua lá. A sequência correta é remover a alegação falsa primeiro. O repositório já
está fazendo isso.

**O que aceito desta lacuna, numa versão bem mais estreita:** o site tem uma página
`/transparencia-curadoria-prime/` que descreve a metodologia, mas os artigos não linkam
para ela de forma sistemática. Isso é um item da §9.3 (links internos para "metodologia
e transparência" já está listado lá, sem obrigatoriedade). Vale tornar obrigatório. É
uma linha de regra, não uma reforma de política de autoria.

---

## 3. "Falta calendário de re-teste" — aceito, e é a lacuna mais grave

Aqui você está certo, e eu diria que é a única lacuna com risco composto.

A §9.4 proíbe alterar `dateModified` sem mudança real. A §12 descreve com precisão
**como** atualizar um artigo, em doze passos ordenados. A §16 manda priorizar
"atualização de páginas que já recebem impressões". Nenhuma das três diz **quando**.
Não há gatilho, não há prazo, não há dono, não há registro.

O dado torna isso concreto. Cruzando `audit/auditoria-48-artigos.csv` com a data de
hoje, dos 27 artigos auditados: 8 têm até 30 dias, **6 estão entre 91 e 180 dias, e 13
passam de 180**. Ou seja, 19 dos 27 estão acima de 90 dias sem revisão. Enquanto isso,
`tools/ledger.py` define `DIAS_FRESCOR = 30` e imprime "acima de 30 dias o preço não
sustenta mais o bloco de compra". A ferramenta já sabe que o preço morreu; a política
editorial nunca é informada.

Escrevi a §17 fechando isso: estados VERDE/AMARELO/VERMELHO derivados do LEDGER,
gatilhos de nível 1 e 2 fora do calendário, prazos por classe de artigo (guia
comparativo envelhece mais rápido que review, porque multiplica os preços em risco),
três níveis de profundidade de revisão, e registro obrigatório em `audit/revisoes.csv`.

---

## 4. "Sem topic clusters" — aceito parcialmente

A §16 pede "criação de clusters coerentes no mesmo domínio" e a §9.3 lista onde os
links internos devem apontar (categoria, comparativo, concorrente mencionado, guia
complementar, metodologia). Portanto a intenção está escrita. O que não existe é
mecanismo: nenhum mapa de cluster, nenhuma obrigação de link recíproco entre pilar e
satélite, nenhuma detecção de página órfã.

Contudo, priorizaria isso abaixo da §17. Com 48 artigos, cluster é otimização de
colheita; com 19 artigos desatualizados e 36 alegações falsas ainda no ar, o passivo é
maior que o ganho marginal de arquitetura. E a §9.2 já cobre o caso mais urgente de
arquitetura, que é canibalização — inclusive com um par identificado na fila
(`/tablets-para-volta-as-aulas-2026/` e o `-2`).

---

## 5. "Sem integração com Search Console" — aceito, com correção de escopo

Aceito, e acrescento que o problema é pior do que você descreve. Não é apenas que falta
integração: a §16 **já emite uma ordem que depende desse dado** ("priorizar atualização
de páginas que já recebem impressões") sem que o sistema colete impressões em lugar
nenhum. É uma regra órfã — impossível de cumprir e impossível de auditar.

A correção não precisa de API. Um export CSV mensal do relatório de Desempenho,
versionado em `audit/gsc/AAAA-MM.csv`, já permite ordenar a fila por impressões × idade
da revisão e detectar quedas. Está especificado na §17.5.

---

## Sobre a nota "diferenciação competitiva 4/10"

Contesto a régua, não o número.

Wirecutter e RTings compram unidades e mantêm laboratório. O curadoriaprime.com não tem
unidades — e a §2.2 existe exatamente para impedir que ele finja que tem, exigindo oito
evidências (responsável, data e duração, origem da unidade, variante exata, protocolo,
medições registradas, fotografias originais, limitações) antes que a expressão "testado
por nós" possa aparecer.

Medir o site contra o RTings é medi-lo contra uma estratégia indisponível. Pior: é
exatamente a fantasia que produziu o passivo que estamos limpando agora — 36 alegações
de teste falsas em 18 artigos, que é o padrão que o Google penalizou com perdas de 40 a
70% em sites de review afiliado no update de março.

O eixo de diferenciação realista é outro: **curadoria de mercado com série histórica de
preço brasileiro, por variante e por loja, com armadilhas de marketplace documentadas.**
O repo já tem `armadilhas-marketplace.md` catalogando coisas que nenhum review
internacional cobre — catálogo `/p/MLB…` não é anúncio, "Redmi Pad 7" vendido como
"Xiaomi Pad 7", produto internacional anunciado com preço nacional. Nesse eixo o site
não está em 4/10; está à frente de qualquer afiliado brasileiro que eu conheça. O que
falta é escala do LEDGER, não conceito.

---

## Sobre a §14 proposta ("schema com cautela")

Cuidado com a direção do conselho. A §2.4 proíbe `AggregateRating` externo, e está
certa. Rating de terceiro republicado como se fosse do site é o caminho clássico para
uma ação manual de *spammy structured markup*, que suprime os rich results até
reconsideração aprovada. A regra do Google é que o markup precisa corresponder a
conteúdo visível e legítimo da própria página. Não afrouxar isso — inclusive porque o
site tinha 5 blocos de `aggregateRating` indevidos num único guia, já mapeados para
remoção.

---

## Placar

| # | Alegação | Veredito |
| --- | --- | --- |
| 1 | Não aborda original research | **Improcedente** — existe em `curadoria-mercado` + LEDGER; a crítica válida é subutilização (8 SKUs / 48 artigos) |
| 2 | Byline oculta uso de IA | **Improcedente** — §2.6 atribui responsabilidade humana, alinhada à orientação do Google; aceito apenas o link sistemático para a página de transparência |
| 3 | Falta calendário de re-teste | **Procedente — prioridade 1.** 19 de 27 artigos acima de 90 dias; `DIAS_FRESCOR=30` já existe no código sem contraparte editorial |
| 4 | Sem topic clusters | **Parcial** — intenção está na §16/§9.3, falta mecanismo; prioridade baixa no momento |
| 5 | Sem integração com GSC | **Procedente — prioridade 2.** Pior que o descrito: a §16 já depende do dado que ninguém coleta |

---

## Sobre as duas opções oferecidas ao fim da análise

Nenhuma das duas, ainda.

Um addendum de diferenciação vs. Wirecutter/RTings adiciona doutrina a um sistema que já
tem 736 linhas de regra, 16 seções e um checklist de bloqueio com 24 itens — enquanto
36 alegações falsas continuam publicadas em 18 artigos e 48 links de afiliado seguem sem
`rel="sponsored"` em 12 artigos.

*(Correção de um erro meu numa versão anterior deste texto: os 48 artigos **foram**
auditados. O `auditoria-48-artigos.csv` lista apenas os 27 com defeito; os outros 21
passaram limpos. Não há backlog de auditoria — há backlog de correção.)*

O gargalo do curadoriaprime.com hoje não é a política. É a execução da política que já
existe. A ordem que defendo:

1. Terminar a limpeza dos artigos no ar (4541, depois a fila P0).
2. Instalar a §17 — a única lacuna com risco composto.
3. Ligar o export mensal do Search Console e reordenar a fila por impressões × idade.
4. Expandir o LEDGER de 8 para cerca de 25 SKUs. É isso que converte o ativo
   proprietário em diferencial visível no texto — e responde à sua lacuna 1 melhor do
   que qualquer seção nova responderia.
