# Stack de Agentes para o Curadoria Prime
### Diagnóstico do site + arquitetura recomendada — Agosto/2026

---

## 1. O que eu encontrei no seu site (diagnóstico técnico)

Consegui acessar a REST API do WordPress e mapear tudo. Dados reais:

| Métrica | Valor |
|---|---|
| Posts publicados | **48** |
| Páginas | 10 |
| Categoria líder | TV e Home Theater (12), Smartphones (11), Áudio (10) |
| Tag líder | Review (39), Samsung (17), soundbar (17) |
| Tamanho médio do artigo | ~3.000 palavras / ~70 KB de HTML |
| Afiliados ativos | Amazon (`link.amazon`) + Mercado Livre (`meli.la`) |
| Stack | WordPress + LiteSpeed Cache + Yoast/RankMath + Gutenberg com HTML inline |
| **REST API** | **Aberta e funcional** ← isto é o mais importante |

### Cadência de publicação (o problema mais visível)

```
2026-01  ███████████████████ 19
2026-02  ████ 4
2026-03  █████ 5
2026-04  ██ 2
2026-05  (nada)          ← hiato de 3 meses
2026-06  (nada)          ←
2026-07  ████████████ 12
2026-08  ██████ 6
```

**Leitura:** você produz em rajadas e para. Para afiliado, isso é o pior padrão possível — o
Google interpreta abandono e o site perde autoridade justamente na janela que antecede Black
Friday. É exatamente o problema que um agente resolve bem.

### Problemas concretos que achei

1. 🔴 **Conteúdo duplicado:** "Tablets para Volta às Aulas 2026" está publicado **duas vezes**
   (03/08 e 31/07). Confirmado rodando `python3 publicar_wp.py --checar-duplicados`:
   **ID 4474** → `/tablets-para-volta-as-aulas-2026-2` e **ID 4476** →
   `/tablets-para-volta-as-aulas-2026`. Canibalização de SEO — mantenha o 4476 (slug limpo)
   e faça 301 do 4474 para ele.
2. 🟡 **Poucas *money pages*.** Você tem 39 reviews individuais e pouquíssimas listas
   "Melhores X de 2026". Listas convertem 3–5× mais que review unitário e rankeiam para termos
   comerciais mais amplos.
3. 🟡 **Soundbar é sua 3ª tag mais forte (17 posts) mas está parada desde fevereiro.** Você já
   tem autoridade tópica ali — é o cluster mais barato de expandir.
4. 🟡 **Sem atualização programada de preço.** Seus artigos citam preços fixos ("~R$ 3.430").
   Preço desatualizado mata conversão e confiança.
5. 🟢 **Ponto forte:** seu template de artigo é excelente — bloco de transparência, prós/contras,
   tabela comparativa, FAQ, veredito com nota, fontes consultadas. Isso é E-E-A-T bem feito e é
   perfeitamente replicável por um agente.

---

## 2. Por que o Arena (sozinho) não resolve o seu caso

O Arena é ótimo para **pesquisar e redigir**, mas seu fluxo tem 4 etapas e ele só cobre bem duas:

| Etapa | Arena resolve? | Observação |
|---|---|---|
| 1. Pesquisar produto/preço/reviews | ✅ Sim | Web search funciona bem |
| 2. Escrever o HTML no seu padrão | ✅ Sim | Mas você tem que recolar o template todo prompt |
| 3. **Publicar no WordPress** | ❌ Não | Sem acesso à sua API/credenciais |
| 4. **Rodar sozinho toda semana** | ❌ Não | Sem agendamento — exige você iniciar a sessão |

**As etapas 3 e 4 são as que realmente te fariam sair do padrão "rajada e hiato".**

---

## 3. Arquitetura recomendada (3 camadas)

Não existe uma ferramenta única boa nisso. A montagem que eu faria:

```
┌─────────────────────────────────────────────────────────┐
│ CAMADA 1 — PAUTA (1× por mês, 1 hora)                   │
│ Arena Agent Mode ou ChatGPT Agent                       │
│ → pesquisa lançamentos, sazonalidade, gaps              │
│ → devolve calendário de 30 dias em CSV                  │
├─────────────────────────────────────────────────────────┤
│ CAMADA 2 — PRODUÇÃO (por artigo, ~15 min)               │
│ Claude Projects / ChatGPT Projects com template fixo    │
│ → pesquisa o produto + gera HTML pronto no seu padrão   │
├─────────────────────────────────────────────────────────┤
│ CAMADA 3 — PUBLICAÇÃO + MANUTENÇÃO (automático)         │
│ n8n (self-hosted, grátis) + WordPress REST API          │
│ → publica como rascunho, agenda, revalida preços        │
└─────────────────────────────────────────────────────────┘
```

### Camada 1 — Pauta mensal
**Ferramenta: Arena Agent Mode ($20) ou ChatGPT Agent ($20)**
Uma sessão por mês. Você pede: "pesquise lançamentos de TV/soundbar/smartphone no Brasil nos
próximos 60 dias, cruze com minhas 48 pautas já publicadas, devolva 12 pautas novas sem
sobreposição, priorizadas por volume de busca e comissão".
Isso o Arena faz muito bem — é exatamente o tipo de tarefa multi-etapa dele.

### Camada 2 — Produção do artigo
**Ferramenta: Claude Projects ($20/mês) — minha recomendação forte aqui**

Por quê Claude e não o Arena para esta etapa:
- **Projects guarda o template permanentemente.** Você sobe seu HTML padrão uma vez como
  *project knowledge* e nunca mais recola. No Arena você recola o template a cada sessão.
- **Claude é mais fiel a formato longo.** 3.000 palavras + HTML inline complexo sem quebrar
  estilo é onde ele se destaca.
- **Custo previsível.** $20 flat, sem crédito queimando.

Alternativa se quiser tudo num lugar só: **Manus** ($20) faz pesquisa + escrita + entrega o
arquivo, mas queima crédito rápido em artigo de 3.000 palavras e não guarda template.

### Camada 3 — Publicação e manutenção
**Ferramenta: n8n self-hosted (grátis) — é aqui que está o ganho real**

Sua REST API está aberta. Com um Application Password do WordPress, o n8n:
- Publica o HTML como **rascunho** (você revisa antes de ir ao ar) ou agendado
- Define categoria, tags, slug, meta description, imagem destacada
- **Revalida preços semanalmente** e te avisa quando um produto mudou de preço >10%
- **Detecta link de afiliado quebrado / produto fora de estoque**
- Republica com data atualizada (`modified`) — sinal forte de frescor para o Google

Custo: R$ 0 se rodar em VPS que você já tenha, ou ~€20/mês na nuvem deles.

---

## 4. Comparativo direto para o SEU caso

| Ferramenta | $/mês | Pesquisa | Artigo 3k palavras | Publica no WP | Agenda sozinho | Veredito |
|---|---|---|---|---|---|---|
| **Arena Agent Mode** | 20 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ❌ | ❌ | **Use para pauta** |
| **Claude Projects** | 20 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ❌ | ❌ | **Use para escrever** |
| **ChatGPT Agent** | 20 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⚠️ via Zapier | ⚠️ Tasks | Alternativa ao Arena |
| **Manus** | 20+ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⚠️ browser | ⚠️ agendado | Bom, mas caro por artigo |
| **n8n** | 0–20 | ❌ | ❌ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | **Indispensável** |
| **Perplexity Pro** | 20 | ⭐⭐⭐⭐⭐ | ⭐⭐ | ❌ | ❌ | Só se quiser fontes citadas |
| Genspark | 25 | ⭐⭐⭐⭐ | ⭐⭐⭐ | ❌ | ❌ | Dispensável aqui |
| Jasper/Copy.ai | 49+ | ⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | Caro e genérico — evite |

### Setup mínimo recomendado: **$40/mês**
`Arena ou ChatGPT ($20)` + `Claude Projects ($20)` + `n8n self-hosted (R$ 0)`

Se quiser cortar para **$20/mês**: use só Claude Projects para pauta *e* escrita, e n8n para
publicar. Perde um pouco na pesquisa de tendências, mas funciona.

---

## 5. O que eu já construí para você neste workspace

| Arquivo | O que é |
|---|---|
| `gerar_artigo.py` | Script Python que gera o HTML **exatamente no seu padrão** a partir de um JSON simples. Elimina 80% do trabalho de formatação |
| `exemplo-produto.json` | Modelo de entrada — preencha e rode |
| `artigo-exemplo.html` | Saída gerada, pronta para colar no WordPress |
| `publicar_wp.py` | Publica direto na sua REST API como rascunho (só precisa do Application Password) |
| `pauta-90-dias.csv` | 36 pautas priorizadas, baseadas nas lacunas reais do seu site |
| `prompt-mestre.md` | O prompt para colar no Claude Projects / Arena que gera o JSON de entrada |
| `checar_conformidade.py` | **A trava.** 13 checagens automáticas contra as políticas do Google e do CDC. Sai com erro se o artigo não puder ser publicado |
| `corrigir_artigos.py` | Remediação em lote dos **48 artigos já publicados** (ver seção 6) |
| `auditoria-48-artigos.csv` | O resultado da auditoria do conteúdo atual, ordenado por risco |

**Fluxo final:** prompt-mestre → agente devolve JSON → `gerar_artigo.py` → `publicar_wp.py`
(que **roda a trava antes de qualquer coisa e aborta se houver erro**) → rascunho no
WordPress → checklist humano → publish. De pauta a rascunho em ~15 minutos por artigo.

### A trava de conformidade

Este é o item que muda o jogo. Compliance escrito em documento é intenção; compliance em
código é garantia. O `checar_conformidade.py` verifica 13 coisas em cada artigo:

`rel="sponsored"` em todos os links de afiliado · divulgação presente **e antes** do primeiro
link · assinatura de autoria · metodologia declarada · declaração honesta de que não há teste
físico · seção de fontes · data de verificação · **ausência de alegação falsa de teste
físico** · sinais de valor agregado · imparcialidade (contras reais listados) · texto de
enchimento · keyword stuffing · JSON-LD válido e completo.

```bash
python3 checar_conformidade.py artigo.html --json produto.json
# exit 0 = pode publicar · exit 1 = bloqueado
```

O `publicar_wp.py` chama isso sozinho **antes de abrir conexão com o site**. Se der erro, o
artigo não sobe. Existe `--forcar` para override, mas se você usar por hábito, perdeu o
sentido de ter a trava. Validei o detector nos dois sentidos: contra um artigo bom (passa) e
contra um artigo propositalmente ruim com 8 violações plantadas (pegou todas).

---

## 6. 🚨 Auditoria dos 48 artigos publicados — o achado mais urgente

Depois de construir a trava, apontei ela para o conteúdo que **já está no ar**. O resultado
muda a ordem das prioridades: o risco maior não está no que você vai escrever, está no que
já foi publicado.

**27 dos 48 artigos (56%) têm pelo menos um problema de conformidade.**

| Problema | Ocorrências | Gravidade | Corrigível automaticamente? |
|---|---|---|---|
| **Alegação falsa de teste físico** | **37 trechos em 19 artigos** | 🔴 Crítico | ❌ Não — exige reescrita |
| Links de afiliado sem `rel="sponsored"` | 48 links em 12 artigos | 🔴 Alto | ✅ Sim |
| Divulgação de afiliado ausente | 10 artigos | 🟠 Médio | ✅ Sim |

### Por que a alegação de teste físico é o item mais grave

Seus artigos dizem "**testamos** o Acer Aspire 5 na prática durante 30 dias", "**testei** esta
TV por 30 dias em casa", "**testamos** e comparamos detalhadamente". Ao mesmo tempo, outros
artigos seus declaram — corretamente — "*não testamos esta unidade fisicamente*".

Essa contradição é o problema. Ela é:

- **Exatamente o padrão que o Google penalizou** em março: sites de review afiliado com
  comparações geradas por IA, sem experiência de primeira mão, perderam de 40% a 70% de
  tráfego. O sinal que o algoritmo procura é justamente alegação de teste sem lastro.
- **Risco legal no Brasil.** O CDC (art. 37) trata como publicidade enganosa a afirmação
  falsa sobre a origem da informação. Isso não é penalidade de algoritmo, é exposição jurídica.
- **Autossabotagem de E-E-A-T.** Seu maior ativo é a honestidade declarada. Um artigo dizendo
  "testei 30 dias" ao lado de outro dizendo "não testamos fisicamente" destrói a credibilidade
  dos dois.

Os 5 artigos com mais alegações: `qcy-t13-anc-review-2026` (7), `lg-55au801-review-2026` (6),
`roku-vs-fire-tv-stick-4k` (3), `samsung-galaxy-buds-core` (2), `kit-teclado-mouse-ultra-slim` (2).
A lista completa está em `auditoria-48-artigos.csv`, ordenada por score de risco.

### Como corrigir

```bash
# 1. Veja o que seria mudado, sem gravar nada
python3 corrigir_artigos.py --dry-run

# 2. Aplique as correções mecânicas (rel=sponsored + divulgação)
export WP_USER="seu_usuario"
export WP_APP_PASSWORD="xxxx xxxx xxxx xxxx"
python3 corrigir_artigos.py --aplicar

# 3. Liste os trechos que exigem reescrita humana, com sugestão de troca
python3 corrigir_artigos.py --relatorio-alegacoes
```

O passo 3 não é automatizável de propósito: trocar "testamos o fone durante duas semanas" por
"analisamos as especificações e cruzamos com relatos de compradores verificados" muda o
sentido da frase, e às vezes o parágrafo inteiro precisa ser reescrito. O script te entrega o
trecho, o contexto e a sugestão — a decisão é sua. São 37 trechos, dá para fazer em uma tarde.

**Ordem recomendada:** rode o passo 2 hoje (é seguro e reversível), e faça o passo 3 começando
pelos artigos de TV e áudio, que são os seus clusters de maior volume.

---

## 7. Prioridades — o que fazer nesta ordem

1. **Hoje:** rodar `corrigir_artigos.py --aplicar` — corrige 48 links e 10 divulgações
   automaticamente, sem risco.
2. **Esta semana:** reescrever as 37 alegações falsas de teste físico
   (`--relatorio-alegacoes`). Este é o item de maior impacto de todo o plano.
3. **Esta semana:** resolver o duplicado de "Tablets Volta às Aulas" — 301 do post 4474
   para o 4476.
4. **Esta semana:** gerar o Application Password no WP e testar o `publicar_wp.py`.
5. **Próximas 2 semanas:** produzir 4 artigos com o kit para validar o fluxo — todos
   precisam passar na trava antes de subir.
6. **Setembro:** subir n8n e automatizar a revalidação semanal de preços.
7. **Outubro:** atacar o cluster de Black Friday com antecedência (ver `pauta-90-dias.csv`) —
   conteúdo de BF precisa estar indexado 6–8 semanas antes.

---

## 8. O que mudou nas regras do Google (e o que isso exige de você)

Em **15 de maio de 2026** o Google reescreveu a definição de spam para incluir, textualmente,
"manipular as respostas da **IA generativa** na Pesquisa Google". Isso importa diretamente
para a sua pauta: das 36 pautas do `pauta-90-dias.csv`, 18 são listas "Melhores X de 2026" —
formato que analistas do setor já apontam como fronteira de risco quando a ordenação é
montada para baitar citação de IA em vez de informar o leitor.

Não é motivo para abandonar o formato: é motivo para que **a ordem da lista se justifique no
texto**. Se um produto está em primeiro, o artigo precisa dizer por quê, em termos que o
leitor consiga verificar. Adicionei isso ao checklist da Parte D do `prompt-mestre.md`.

As três políticas que se aplicam ao seu site — afiliação sem valor agregado, abuso de conteúdo
em escala e manipulação de respostas de IA — estão transcritas no `prompt-mestre.md`, com o
texto oficial e a tradução operacional de cada uma.

> **O ponto central:** usar IA não é violação. O Google diz explicitamente que o critério é
> valor e originalidade, "não importa como o conteúdo é criado". O que penaliza é volume sem
> valor — e alegar experiência que não existe. Seu diferencial (metodologia declarada,
> transparência sobre não fazer teste físico, fontes consultadas) é exatamente o que te
> protege. A auditoria da seção 6 mostrou que esse diferencial está furado em 27 artigos.
> Consertar isso vale mais do que qualquer artigo novo que você publique este mês.
