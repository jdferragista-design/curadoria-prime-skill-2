# ✅ Estrutura conferida — repositório está correto

Clone fresco da `main`, commit `266aa9d` (merge do PR #2).

| Verificação | Resultado |
|---|---|
| Pastas `lote-*` | ✅ **zero** |
| Total de arquivos | ✅ **39** |
| `tools/` | ✅ 7 arquivos, um nível da raiz |
| `audit/` | ✅ 3 arquivos |
| `.gitignore` | ✅ presente |
| `articles/` e `skills/` | ✅ intactos |

**Os modelos da raiz — o que realmente importava:**

```
bbd87f3a4c  modelo-2-Power-Bank-no-Avião.html    ✅ versão corrigida
77fe0793c3  modelo-layout-da-Apple-TV-4K.html    ✅ versão corrigida
```

Testes rodados na `main`:

```
tools/checar_conformidade.py '*.html'      → 0 erros em 2 arquivos     ✅
tools/ledger.py validar                    → 30 capturas, 0 erros      ✅
tools/checar_conformidade.py 'articles/*'  → 1 erro em 4 arquivos      ✅ esperado
```

O erro em `articles/` é o `preview-tablets.html` — falso positivo conhecido: é um
preview sem assinatura de autor, e o checker exige assinatura. Os outros 3
artigos passam limpos.

**Frente encerrada.** A infraestrutura está no lugar.

---

# Próximo passo: proteger a `main`

Hoje: `main` → `protected: false`. Qualquer upload solto entra direto, sem
revisão — foi assim que 3 pastas erradas apareceram de uma vez.

## Como fazer

**Settings** (última aba, no topo) → **Branches** (menu da esquerda) →
**Add branch ruleset** *(ou "Add rule", conforme a versão da interface)*

Preencha:

| Campo | Valor |
|---|---|
| Ruleset Name | `Proteger main` |
| Enforcement status | **Active** |
| Target branches | **Add target → Include default branch** |

Depois marque, na lista de **Rules**:

- ☑️ **Restrict deletions** — impede apagar a branch
- ☑️ **Block force pushes** — impede reescrever o histórico
- ☑️ **Require a pull request before merging**
  - Required approvals: **0**

**Create**.

## Por que 0 aprovações

Você é o único mantenedor. Exigir 1 aprovação te bloquearia no próprio
repositório — o GitHub não deixa aprovar o próprio PR. Com 0, tudo continua
passando por PR (que é onde eu consigo revisar antes do merge), mas você mesmo
aprova e mergeia sem depender de ninguém.

## O que muda na prática

- Upload direto pela web na `main` deixa de ser possível — o GitHub oferece
  criar uma branch e abrir PR
- Cada mudança ganha uma tela de diff antes de entrar
- O histórico da `main` fica imutável

## Limpeza opcional

A branch `arena/019ff772-ai-skill` ainda existe e já foi mergeada no PR #1.
Pode apagar em **Branches** → ícone de lixeira.

---

## Fila a partir daqui

1. ~~Reorganizar a estrutura~~ ✅
2. **Proteger a `main`** ← agora
3. **Corrigir os posts 4537 e 4541** — estão **no ar** com os mesmos defeitos que
   acabamos de remover dos modelos. É o primeiro item com exposição real ao
   público e ao Google
4. Fila P0 — 12 artigos de maior risco
5. As 6 checagens pendentes do checker
