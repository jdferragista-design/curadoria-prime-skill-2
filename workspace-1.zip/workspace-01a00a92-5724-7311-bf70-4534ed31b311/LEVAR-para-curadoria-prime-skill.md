# O que levar para `curadoria-prime-skill`

Estado do repo privado hoje: espelha o commit local `42a3484`.
Estado local agora: `90dc917`. Diferença: **6 arquivos**, +78/−11.

Método para todos: abrir o arquivo no GitHub → ✏️ (lápis) → **Ctrl+A** → colar a versão
nova inteira → **Commit changes**. Nunca upload de pasta — não é preciso aqui.

Fonte de cada versão nova: `/home/user/ai-skill-v2/<mesmo caminho>`.
(Ou extraia `/home/user/curadoria-prime-repo.zip`, que já está atualizado.)

---

## 1. `skills/curadoria-review/references/regras-editoriais.md`
**+27/−3** · O mais importante da leva.
Versão 1.0 → **1.1**. Entra a **§2.7** (nenhum produto recomendado sem 3 pontos de
atenção verificáveis; ausência bloqueia publicação) e o item 13 da §13 passa a
remeter à §2.7.

## 2. `skills/curadoria-review/assets/checklist-bloqueio.md`
**+1** · Uma linha nova no checklist, espelhando a §2.7.

## 3. `skills/curadoria-review/assets/modelos/modelo-power-bank-aviao.html`
**+47/−1** · Ganha os blocos `Pontos de Atenção` nos 5 power banks.
Depois da mudança: **0 erros, 0 alertas — ✅ Aprovado** no checker.
`<div>` 84/84, JSON-LD válido.

## 4. `skills/curadoria-review/assets/modelos/modelo-layout-apple-tv-4k.html`
**+2/−2** · Só o título do bloco: `Pontos Negativos` → `Pontos de Atenção`.
Os 8 contras já existiam. `<div>` 64/64.

## 5. `tools/checar_conformidade.py`
**+6/−6** · Correção de bug na regex de `[honestidade]`: reconhecia apenas primeira
pessoa (`não testamos`) e acusava falso alerta em texto de terceira pessoa
(`a Curadoria Prime não testou`). Incluídos `testou`, `avaliou`, `realizou`, `fez`,
`conduziu`. Rodado nos 6 HTML do repo: nenhuma regressão.

## 6. `articles/tablets-para-volta-as-aulas-2026.html`
**+3/−3** · Três `<h3>`: `⚠️ Limitações` → `⚠️ Pontos de Atenção`.
Conteúdo idêntico — os 3 itens por ficha já estavam lá; o checker é que não
reconhecia o rótulo. Confirmado por diff reverso: nada mais mudou.

---

## Não vai nesta leva

- `tools/corrigir_artigos.py` — **não tocar**. Segue a v2 validada.
- Os outros 33 arquivos — inalterados.

## Deleções (à parte — o editor web não apaga; use a lixeira do arquivo)

- `articles/preview-tablets.html` — rascunho; único arquivo com erro de bloqueio.
  Já cumpriu a função: o conteúdo está no ar e corrigido.
- `articles/volta-as-aulas-2026-versao-antiga.html` — versão superada.
  As notas 9.0 / 8.8 / 8.2 dele **não** migram para lugar nenhum: rating externo é
  proibido pela §2.4.

## Depois de subir

Confira no commit do GitHub se aparece **6 files changed**. Se aparecer mais, algo foi
junto sem querer.

## Ainda pendente

- Aplicar no WordPress a troca dos 3 títulos (`Limitações` → `Pontos de Atenção`) em
  `curadoriaprime.com/tablets-para-volta-as-aulas-2026/`.
- `Contex` → Private ou delete.
