# §17 — Cadência de revisão e frescor editorial

> **Patch para `regras_editoriais_ia_curadoria_prime.md`.**
> Inserir entre a §16 (Regra operacional final) e o "Prompt mestre copiável".
> A §16 passa a referenciar a §17 no item "atualização de páginas que já recebem impressões".

---

## 17. Cadência de revisão e frescor editorial

Um artigo publicado não é um ativo estável. Preço, estoque, variante, concorrente e
versão de software mudam sem aviso, e o artigo continua no ar afirmando o que era
verdade no dia da publicação. Esta seção define **quando** revisar — a §12 já define
**como**.

A regra que governa esta seção: **nenhuma afirmação sensível ao tempo pode permanecer
no ar sem data visível e sem prazo de validade declarado.**

### 17.1. Estados de frescor

Todo artigo publicado tem um estado, derivado de sinais objetivos e não de opinião:

| Estado | Condição | Consequência |
| --- | --- | --- |
| **VERDE** | Captura de preço com até 30 dias **e** nenhum gatilho da §17.2 ativo | Nada a fazer. |
| **AMARELO** | Captura entre 31 e 90 dias, **ou** um gatilho de nível 2 ativo | Entra na fila de revisão. Bloco de compra mantém o preço **apenas com a data da captura explícita**. |
| **VERMELHO** | Captura acima de 90 dias, **ou** qualquer gatilho de nível 1, **ou** artigo nunca revisado desde a publicação | Bloco de compra **suspenso**: substituir valores por "consultar preço atual na loja" com link. Revisão obrigatória antes de qualquer nova divulgação do artigo. |

O limite de 30 dias não é arbitrário: é o `DIAS_FRESCOR` já implementado em
`tools/ledger.py`, que imprime alerta quando a captura mais recente ultrapassa esse
prazo. A §17 apenas transforma um alerta de ferramenta em obrigação editorial.

**Um artigo VERMELHO não é despublicado.** Despublicar destrói links e histórico.
O que se suspende é a afirmação que envelheceu, não a página.

### 17.2. Gatilhos de revisão fora do calendário

Certos eventos tornam o artigo desatualizado independentemente da data.

**Nível 1 — revisão obrigatória, prazo de 7 dias:**

- produto descontinuado, esgotado de forma persistente ou sem vendedor confiável;
- sucessor direto lançado no Brasil;
- recall, notificação de órgão regulador ou falha de segurança divulgada;
- mudança de preço superior a 20% em relação à última captura registrada;
- link de afiliado quebrado, redirecionando para catálogo genérico ou para produto diferente;
- descoberta de afirmação incorreta, alegação de teste não documentada ou `AggregateRating` externo remanescente;
- fonte citada saiu do ar ou passou a contradizer o artigo.

**Nível 2 — revisão na próxima janela, prazo de 30 dias:**

- concorrente novo relevante na mesma faixa de preço;
- atualização de software ou firmware que altere recursos descritos;
- mudança de variante vendida no Brasil (memória, cor, bundle, versão nacional vs. importada);
- alteração de garantia, assistência ou homologação;
- artigo novo do próprio site que compete pela mesma intenção — avaliar consolidação (§9.2);
- queda relevante de impressões ou posição média no período (§17.5).

Quem identificar um gatilho registra na fila **no mesmo dia**, mesmo sem executar a
revisão. Gatilho não registrado é gatilho perdido.

### 17.3. Prazos por classe de artigo

Nem todo conteúdo envelhece na mesma velocidade. A revisão programada é o piso; os
gatilhos da §17.2 têm precedência sobre qualquer prazo abaixo.

| Classe | Exemplo | Recaptura de preço | Revisão editorial |
| --- | --- | --- | --- |
| **Review de produto com bloco de compra** | `/apple-tv-4k/` | 30 dias | 90 dias |
| **Guia comparativo / listicle** | `/melhor-fone-bluetooth-ate-500-reais-2026/` | 30 dias, **todos** os SKUs citados | 60 dias |
| **Guia sazonal com ano no título** | `/presentes-dia-dos-pais-2026-tech-premium/` | 15 dias na janela sazonal | revisão obrigatória ao fim da temporada: consolidar, arquivar ou reposicionar |
| **Conteúdo explicativo sem preço** | "o que é Wi-Fi 6" | não se aplica | 180 dias |

Guia comparativo tem prazo mais curto que review porque o risco é multiplicado: um
guia com oito produtos tem oito preços podendo envelhecer, e basta um errado para
comprometer a credibilidade da recomendação inteira.

**Regra sazonal específica:** artigo com ano no título ou no slug não pode ter o ano
trocado como forma de renovação — isso é o verniz proibido pela §9.4. Ao fim da
temporada, escolher explicitamente entre consolidar na URL permanente, manter com
aviso de contexto histórico, ou redirecionar 301.

### 17.4. Profundidade da revisão

Nem toda revisão é uma reescrita. Distinguir três níveis, do mais barato ao mais caro:

**Nível A — recaptura (10 minutos).** Rodar `ledger.py add` para os SKUs do artigo,
atualizar valores e a data da captura no bloco de compra, conferir se os links de
afiliado ainda resolvem para o produto certo. **Não altera `dateModified`** e não
gera nota de atualização — nada editorial mudou.

**Nível B — verificação (30 a 60 minutos).** Nível A, mais: conferir disponibilidade
e variante, testar todas as fontes citadas, revisar se os concorrentes mencionados
continuam sendo os relevantes, checar se surgiu sucessor. Altera `dateModified`
somente se algum fato do texto mudou.

**Nível C — revisão substancial (§12 completa).** Reavaliação das conclusões, da nota
e do veredito com os dados atuais. Altera `dateModified` e recebe a nota de
atualização da §12.4.

Mapeamento padrão: revisão programada de preço = A; revisão programada editorial = B;
gatilho de nível 1 = C.

### 17.5. Fila de revisão e priorização

A fila vive em `skills/curadoria-review/assets/fila-atualizacao.md` e ganha três
colunas: `estado`, `ultima_revisao`, `proxima_revisao`.

A §16 manda priorizar "páginas que já recebem impressões", mas o repositório não
coleta esse dado — a regra é órfã. Fechar o circuito com o procedimento mínimo
viável, sem depender de API:

1. **Mensalmente**, exportar do Search Console o relatório de Desempenho dos últimos
   90 dias por página (CSV: página, cliques, impressões, CTR, posição média).
2. Salvar em `audit/gsc/AAAA-MM.csv`, versionado no repositório. O histórico é o que
   dá valor — um mês isolado não mostra tendência.
3. Ordenar a fila por **impressões × idade da última revisão**. Uma página com muitas
   impressões e revisão antiga é a que perde mais dinheiro e mais confiança por dia.
4. Marcar como gatilho de nível 2 qualquer página com queda superior a 30% em
   impressões ou perda de mais de 3 posições no período.

Se o export mensal não acontecer, a fila cai para ordenação por idade pura. Funciona,
mas gasta capacidade em páginas que ninguém lê.

**Regra de capacidade.** Com aproximadamente um artigo por dia, reservar **um dia por
semana exclusivamente para revisão**. Publicar cinco artigos novos por semana enquanto
quarenta envelhecem é aumentar o passivo, não o patrimônio. Quando a fila VERMELHA
tiver mais de dez itens, **suspender a publicação de artigos novos** até drená-la.

### 17.6. Registro

Toda revisão gera uma linha em `audit/revisoes.csv`, com o mesmo rigor do LEDGER:

```
data,url,nivel,gatilho,responsavel,o_que_mudou,dateModified_alterado
```

O registro serve a três propósitos: provar diligência editorial se o site for
questionado, permitir medir se a cadência está sendo cumprida de fato, e evitar que
duas pessoas revisem a mesma página.

Sem linha em `revisoes.csv`, a revisão **não aconteceu** — mesmo que o artigo tenha
sido editado.

### 17.7. Bloqueio

Acrescentar ao checklist da §15, na subseção "Atualização e SEO":

- [ ] O artigo tem estado de frescor definido e data da próxima revisão?
- [ ] Nenhuma afirmação sensível ao tempo está sem data visível?
- [ ] Se o artigo está AMARELO ou VERMELHO, o bloco de compra foi ajustado conforme a §17.1?

---

## Notas de implementação

**O que muda no código:**

1. `tools/ledger.py` — novo subcomando `frescor`, que cruza os SKUs do LEDGER com os
   artigos citados na coluna `artigo` e imprime o estado de cada URL. A lógica de
   idade já existe (`DIAS_FRESCOR`); falta agregá-la por artigo em vez de por captura.
2. `tools/checar_conformidade.py` — nova checagem `[frescor]`: se o HTML contém `R$`
   em bloco de compra, exigir data de captura a até 90 dias no mesmo bloco.
3. `audit/revisoes.csv` — criar com o cabeçalho da §17.6.
4. `audit/gsc/` — criar a pasta com um `README.md` explicando o export mensal.

**Custo real de adoção:** um dia por semana de revisão, mais cerca de dez minutos
mensais para o export do Search Console. Nada disso exige ferramenta paga nem
credencial de API.

**Ordem sugerida:** só ligar a §17 depois de terminar a limpeza dos artigos que já
estão no ar. Uma fila de revisão construída sobre 36 alegações falsas mede a coisa
errada — primeiro zerar o passivo, depois instalar o cronômetro.
