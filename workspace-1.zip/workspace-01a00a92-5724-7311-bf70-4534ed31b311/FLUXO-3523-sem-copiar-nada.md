# Como corrigir o 3523 sem abrir o editor do WordPress

Aquela mensagem — *"Nada aqui é corrigível automaticamente. Os itens acima
precisam da sua reescrita no editor"* — estava **errada**. Era texto da v1.1.0,
de antes de o campo de edição existir. Ela mandava você fazer à mão um trabalho
que o plugin já faz sozinho. Removida na v1.2.5.

## O fluxo real, do começo ao fim

1. **Conformidade → 3523 → Varrer.**
2. Clique em **"Sugerir para todos os 23 trechos"** (botão novo).
   O plugin percorre as caixas vazias uma por uma, rolando a tela junto,
   e mostra *"sugerindo 7 de 23…"*. Custo estimado aparece **antes** de rodar:
   R$ 0,0165 no flash-lite para o artigo inteiro.
   Dá para clicar em **parar** a qualquer momento; o que já veio fica.
3. **Leia e edite as 23 caixas.** É aqui que está o seu trabalho — e é
   trabalho de revisor, não de digitador. Caixa que você já tinha preenchido
   não é tocada pelo lote.
4. Caixa que você quiser deixar como está: **apague o conteúdo**. Campo vazio
   é ignorado na gravação.
5. Marque **"Revisei os textos"** e clique em **"Salvar minhas reescritas"**.

Pronto. O plugin grava direto no post, cria uma revisão antes (reversível pelo
histórico do WordPress) e valida cada troca com `CPC_Diff::validar()`.

**Você não abre o editor do WP. Não copia trecho. Não cola nada.**

## Contagem de ações no 3523

| | antes | agora |
|---|---|---|
| cliques em "Sugerir" | 23 | 1 |
| revisões de texto | 23 | 23 |
| gravações | 1 | 1 |
| **total** | **47** | **25** |

A revisão dos 23 textos continua sendo sua, e é proposital: é ela que faz o
artigo deixar de ser "conteúdo gerado por IA em massa" aos olhos do Google.
O que o plugin elimina é a digitação e o vaivém entre telas.

## Quando o editor do WP ainda é necessário

Só em dois casos, ambos raros e sinalizados na tela:

- **Trecho repetido idêntico no post.** O `CPC_Editor` se recusa a adivinhar
  qual ocorrência trocar. Aparece em "Falhas" com o motivo.
- **Trecho quebrado por HTML** que a busca flexível não conseguiu remontar.

No 3523, hoje: **23 de 23 gravam** (`cpc-colisao`: 23 aplicadas, 0 recusadas).

## Onde ainda vale reclamar da tela

23 caixas num artigo é muita rolagem — e **13 delas são `preco_sem_data`**,
a regra que ainda não foi calibrada. Se ela for ajustada para aceitar faixa de
preço sem data explícita, o 3523 cai de 23 para ~10 caixas. Isso continua no
backlog e é a próxima coisa que muda o volume de verdade.
