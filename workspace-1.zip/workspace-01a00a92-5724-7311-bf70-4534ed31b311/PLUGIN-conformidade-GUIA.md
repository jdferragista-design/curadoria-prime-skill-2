# Plugin `curadoria-conformidade` v1.1.0 — pronto para instalar

**Arquivo:** `/home/user/curadoria-conformidade.zip` (27.575 B, 13 entradas)
**Instalação:** Plugins → Adicionar novo → Enviar plugin → escolher o ZIP → Ativar.

O ZIP tem a pasta na raiz e as classes em `includes/` — a estrutura correta, não o
formato achatado que quebrou o `Ai-image-optimizer-alt`.

---

## O que ele faz

Transforma em rotina o trabalho que vinha sendo feito artigo por artigo: varre os
posts, mostra o que está fora de conformidade e corrige o que é seguro corrigir —
**sempre com preview e aprovação sua antes de gravar.**

### Telas

| Tela | Onde | Para quê |
|---|---|---|
| **Painel** | menu lateral "Conformidade" | lista todos os posts com contagem de problemas, filtro por regra, botão "Varrer tudo" e exportação CSV |
| **Post** | clicar num post da lista | achados com o trecho exato destacado, diff antes/depois e o botão de aplicar |
| **Falhas** | Conformidade → Falhas | o que o plugin tentou corrigir e não conseguiu — sua fila de trabalho manual |
| **Config** | Conformidade → Configurações | autor canônico, tipos de post, domínios extras de afiliado |
| **Metabox** | lateral do editor de post | status de conformidade sem sair da edição |

---

## Relatório de falhas (v1.1)

Antes, quando a trava barrava uma gravação, você via um `wp_die` branco e a
informação morria ali. Agora tudo que dá errado fica registrado, com **o que
aconteceu e o que fazer a respeito**. O menu mostra um contador quando há
pendências, e o painel avisa com link direto.

A tela tem duas partes: **"o que mais está falhando"**, agrupado por tipo, com os
artigos afetados clicáveis; e o **histórico** cronológico. Dá para exportar em CSV
e limpar (limpar apaga só o histórico — não desfaz nem refaz correção nenhuma).

### Os 9 tipos registrados

| Tipo | Gravidade | Significa |
|---|---|---|
| Gravação recusada pela trava | alta | a correção perderia conteúdo e foi abortada antes de gravar |
| Erro do WordPress ao gravar | alta | a trava passou mas `wp_update_post` falhou (permissão, plugin de segurança, limite do servidor) |
| Bloco de schema não faz parse | alta | JSON-LD malformado; o corretor não encosta nele porque regex quebraria o bloco |
| Falha ao regravar o schema | alta | parseou e corrigiu, mas não serializou de volta (byte UTF-8 inválido) |
| Detector acusa, corretor não resolve | média | a análise apontou o problema e a correção não mudou nada — **candidato a bug do plugin** |
| Correção de schema bloqueada por permissão | média | sem `unfiltered_html`; as demais regras rodaram |
| Imagem em placeholder sem URL de origem | média | base64 sem `data-src`: não há o que restaurar, reinsira pela biblioteca |
| Erro ao analisar o post | alta | a varredura lançou exceção nesse post; a fila continua sem ele |
| Sem ponto de inserção para a divulgação | baixa | não há link de afiliado para ancorar; normalmente o post não é de afiliado |

**Duas decisões de projeto que valem explicar:**

A trava de segurança **continua barrando a gravação** — o registro não afrouxa
nada. O que mudou é que agora você volta para a tela com a mensagem e o caso fica
anotado, em vez de bater numa página branca.

E "detector acusa, corretor não resolve" só é registrado quando a análise
**realmente tinha apontado** aquela regra naquele post. Se você marcou as regras
por atacado e não havia o problema, é silêncio esperado e não vira linha. Assim o
relatório fica sendo sinal, não ruído: cada aparição desse tipo é uma
discrepância entre detector e corretor, ou seja, bug meu, não do artigo.

Rodando contra os artigos reais do site esse filtro se provou necessário — sem
ele, os 3 artigos de teste geravam 7 linhas de ruído; com ele, geram zero.

---

## Os 10 detectores

| Regra | Gravidade | Correção | O que pega |
|---|---|---|---|
| `alegacao_teste` | alta | 🖐 humano | 16 padrões de teste físico no texto visível |
| `alegacao_schema` | alta | 🖐 humano | os mesmos padrões dentro do JSON-LD |
| `urgencia_falsa` | alta | 🖐 humano | "estoque limitado", "verificado há 2 horas", "só hoje"… |
| `schema_malformado` | alta | 🖐 humano | JSON-LD que não faz parse (diagnostica a aspa reta de polegadas) |
| `schema_agg` | alta | 🤖 auto | `aggregateRating` inventado |
| `sponsored` | alta | 🤖 auto | link de afiliado sem `rel="sponsored"` |
| `img_lazy` | alta | 🤖 auto | imagem presa no placeholder base64 |
| `schema_autor` | média | 🤖 auto | autor do schema fora do padrão |
| `divulgacao` | média | 🤖 auto | link de afiliado sem aviso de comissão |
| `preco_sem_data` | média | 🖐 humano | `R$ N` sem data de verificação por perto |

**Alegação de teste e urgência falsa nunca são reescritas pelo plugin.** Trocar
"testamos" por "analisamos" muda o sentido da frase e é decisão editorial sua —
ele marca o trecho, mostra o contexto e para.

---

## As quatro travas antes de gravar

1. **Nonce + capability por post** (`edit_post` no objeto, não genérico).
2. **Checkbox de confirmação** obrigatório — nenhum caminho grava sem clique.
3. **Revalidação no momento de gravar** — o post pode ter mudado desde o preview.
4. **Trava de integridade**: aborta se o resultado perder uma `<img>`, perder um
   `<a>`, encolher o texto visível em mais de 10%, ou quebrar um bloco JSON-LD que
   antes fazia parse.

Antes de escrever ele cria uma revisão (`wp_save_post_revision`), então dá para
reverter pelo próprio WordPress.

---

## Validação executada

**`php -l`** nos 8 arquivos PHP → zero erros. **Bootstrap** com stubs do WP → 7/7
classes carregadas, 4 constantes, 9 actions, hooks de ativação e desativação.

**25 testes do relatório de falhas** (`/home/user/.smoke/cpc-log-test.php`) → todos
passando: detecção e classificação dos incidentes, bloco ilegível saindo intacto,
reset entre execuções, teto de 300 registros para não inchar o `wp_options`,
truncamento do detalhe em 500 caracteres, CSV com BOM e aspas escapadas, e uma
verificação que lê o código-fonte para garantir que **todo tipo emitido está
catalogado** com diagnóstico e ação.

**35 testes automatizados** (`/home/user/.smoke/cpc-test.php`) → todos passando:
detecção dos 10 problemas, ausência de falsos positivos num artigo conforme,
limpeza do `<br />` do wpautop antes do parse, diagnóstico da aspa reta,
idempotência, as travas de segurança e a fronteira de bloco Gutenberg.

**Contra artigos reais do site** (`/home/user/.smoke/cpc-reais.php`):

| Artigo | Achados | Correção automática | Trava |
|---|---|---|---|
| 3181 antes (como estava publicado) | teste 1 · urgência 2 · aggregate 1 · schema quebrado 2 · lazy 10 · preço 4 | 10 imagens + 1 aggregateRating | ✅ |
| 3181 depois (sua entrega manual) | só preço sem data | nada a fazer | ✅ |
| 2943 Stanley (no ar) | aggregate 1 · autor 2 · lazy 7 · preço 1 | 7 imagens + 1 aggregate + 2 autores | ✅ |
| 4537 Apple TV v2 | só preço sem data | nada a fazer | ✅ |

A linha que mais importa é a segunda: rodado contra a versão do 3181 que **você
mesmo corrigiu à mão**, o plugin não encontra nada para consertar. Ele está
calibrado no seu padrão editorial, não num padrão genérico.

### Dois bugs que os testes pegaram e já estão corrigidos

- **Divulgação duplicada.** Aplicar a correção duas vezes empilhava um segundo
  bloco de transparência. Agora há guarda de idempotência.
- **Falso positivo em "Fontes consultadas".** Os links para as *homepages* de
  Amazon e Mercado Livre no bloco de fontes do 3181 estavam sendo cobrados como
  links de afiliado. Não são: não monetizam e marcá-los `sponsored` seria errado.
  O detector agora distingue home da loja (`amazon.com.br/`) de link de produto
  (`amazon.com.br/dp/...`) e de home com tag de afiliado (`?tag=`).

---

## Primeiro uso sugerido

1. Ative e vá em **Conformidade → Configurações**, confirme o autor canônico.
2. **Varrer tudo** — 48 artigos, alguns segundos.
3. Exporte o **CSV** para ter o retrato inicial registrado.
4. Comece pelos automáticos do schema: a fila de 29 artigos com `aggregateRating`
   sai em poucos cliques, um post por vez, cada um com seu diff.
5. Depois ataque as alegações de teste (18 artigos), que exigem sua reescrita.

### Uma limitação a saber de antemão

Se o seu usuário não tiver a capability `unfiltered_html`, o WordPress remove
`<script type="application/ld+json">` ao salvar. Nesse caso o plugin **desabilita
sozinho** as correções de schema e avisa na tela — em vez de "consertar" o schema
e fazer você perder o bloco inteiro. Em instalação normal, administrador em site
single-site tem essa permissão.

O `preco_sem_data` vai continuar acusando enquanto os preços estiverem escritos
fixos no corpo do texto. A solução de raiz é shortcode com data de verificação —
é a evolução natural do plugin, não parte da v1.
