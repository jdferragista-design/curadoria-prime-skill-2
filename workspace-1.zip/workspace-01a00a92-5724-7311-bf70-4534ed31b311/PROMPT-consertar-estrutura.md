> Copie tudo abaixo da linha e cole no outro chat.

---

## Tarefa: reorganizar a estrutura do repositório `jdferragista-design/Ai-skill` (branch `main`)

Um upload recente subiu 12 arquivos corretos, mas com os nomes das **pastas de
staging** que eu usei só para organizar o envio. Esses prefixos (`lote-0-`,
`lote-1-`, `lote-2-`) viraram diretórios reais no repositório e não deveriam
existir.

**Nenhum arquivo precisa ser criado do zero, exceto o `.gitignore`.** Todo o
resto é movimentação de arquivos que já estão no repo.

### Estado atual (verificado em clone fresco, commit `53e5048`, 40 arquivos)

```
Ai-skill/
├── README.md
├── modelo-2-Power-Bank-no-Avião.html          🔴 versão DEFEITUOSA
├── modelo-layout-da-Apple-TV-4K.html          🔴 versão DEFEITUOSA
├── regras_editoriais_ia_curadoria_prime.md
├── articles/                    (6 arquivos — não mexer)
├── skills/                      (18 arquivos — não mexer)
├── lote-0-modelos-corrigidos/
│   ├── modelo-2-Power-Bank-no-Avião.html      ✅ versão corrigida
│   └── modelo-layout-da-Apple-TV-4K.html      ✅ versão corrigida
├── lote-1-scripts/
│   ├── checar_conformidade.py
│   ├── corrigir_artigos.py
│   ├── gerar_artigo.py
│   ├── ledger.py
│   └── publicar_wp.py
└── lote-2-docs-e-dados/
    ├── README-audit.md
    ├── README-tools.md
    ├── auditoria-48-artigos.csv
    ├── exemplo-produto.json
    └── pauta-90-dias.csv
```

---

## O que fazer

### 1. Substituir os 2 modelos da raiz pelas versões corrigidas — PRIORIDADE

Os arquivos em `lote-0-modelos-corrigidos/` são as versões **já corrigidas** dos
dois modelos que estão na raiz. Eles foram subidos ao lado dos defeituosos em vez
de por cima. Confirmado por hash — são arquivos diferentes:

| arquivo | sha256 (início) | trava de conformidade |
|---|---|---|
| `modelo-2-Power-Bank-no-Avião.html` (raiz) | `420d2ead3a` | 🔴 2 erros |
| `lote-0-…/modelo-2-Power-Bank-no-Avião.html` | `bbd87f3a4c` | ✅ 0 erros |
| `modelo-layout-da-Apple-TV-4K.html` (raiz) | `0da0317517` | 🔴 3 erros |
| `lote-0-…/modelo-layout-da-Apple-TV-4K.html` | `77fe0793c3` | ✅ 0 erros |

**Ação:** mover os dois arquivos de `lote-0-modelos-corrigidos/` para a raiz,
**sobrescrevendo** os homônimos. Depois, a pasta `lote-0-modelos-corrigidos/`
deve deixar de existir.

Não edite o conteúdo dos HTMLs. Eles já estão corretos — basta que ocupem o
lugar dos defeituosos.

> Contexto de por que isso importa: esses dois arquivos são os modelos que a
> equipe copia para produzir artigos novos. As versões da raiz ainda contêm a
> frase `"Testamos a fundo"` (alegação de teste físico que não ocorreu — risco de
> CDC art. 37) e 6 blocos `aggregateRating` com nota de terceiros no JSON-LD
> (proibido pela regra §2.4 do próprio repositório). Enquanto a raiz não for
> substituída, o defeito continua se propagando.

### 2. `lote-1-scripts/` → `tools/`

Mover os 5 scripts, sem renomear os arquivos:

| de | para |
|---|---|
| `lote-1-scripts/checar_conformidade.py` | `tools/checar_conformidade.py` |
| `lote-1-scripts/corrigir_artigos.py` | `tools/corrigir_artigos.py` |
| `lote-1-scripts/gerar_artigo.py` | `tools/gerar_artigo.py` |
| `lote-1-scripts/ledger.py` | `tools/ledger.py` |
| `lote-1-scripts/publicar_wp.py` | `tools/publicar_wp.py` |

⚠️ `tools/` precisa ficar **a exatamente um nível da raiz**. O `ledger.py`
resolve o caminho `../skills/curadoria-mercado/assets/historico-precos/LEDGER.csv`
de forma relativa. Não aninhe em `scripts/tools/` nem coisa parecida.

### 3. `lote-2-docs-e-dados/` → dividir entre `tools/` e `audit/`

Os dois README foram renomeados só para não colidirem durante o upload. Devem
voltar ao nome original:

| de | para |
|---|---|
| `lote-2-docs-e-dados/README-tools.md` | `tools/README.md` |
| `lote-2-docs-e-dados/exemplo-produto.json` | `tools/exemplo-produto.json` |
| `lote-2-docs-e-dados/README-audit.md` | `audit/README.md` |
| `lote-2-docs-e-dados/auditoria-48-artigos.csv` | `audit/auditoria-48-artigos.csv` |
| `lote-2-docs-e-dados/pauta-90-dias.csv` | `audit/pauta-90-dias.csv` |

⚠️ Os dois CSV estão com quebra de linha **CRLF** e a primeira coluna de
`auditoria-48-artigos.csv` é `risco`. Mover como binário, sem normalizar o
conteúdo.

### 4. Criar `.gitignore` na raiz

Único arquivo novo. Conteúdo exato (4 linhas):

```
__pycache__/
*.pyc
.env
artigo.html
```

### 5. Remover as pastas de staging

`lote-0-modelos-corrigidos/`, `lote-1-scripts/` e `lote-2-docs-e-dados/` devem
ficar vazias após os passos acima e desaparecer da árvore. **Nenhum caminho no
repositório pode começar com `lote-`.**

---

## Se você tiver acesso de escrita ao repositório

Execute:

```bash
git clone https://github.com/jdferragista-design/Ai-skill.git
cd Ai-skill

git mv -f lote-0-modelos-corrigidos/*.html .
git mv lote-1-scripts tools
git mv lote-2-docs-e-dados/README-tools.md tools/README.md
git mv lote-2-docs-e-dados/exemplo-produto.json tools/
mkdir -p audit
git mv lote-2-docs-e-dados/README-audit.md audit/README.md
git mv lote-2-docs-e-dados/auditoria-48-artigos.csv audit/
git mv lote-2-docs-e-dados/pauta-90-dias.csv audit/

printf '__pycache__/\n*.pyc\n.env\nartigo.html\n' > .gitignore
git add .gitignore

git commit -m "Reorganizar upload em tools/ e audit/; substituir modelos pela versão corrigida

- lote-1-scripts/ -> tools/
- lote-2-docs-e-dados/ -> tools/ + audit/
- modelos corrigidos sobrescrevem os da raiz (remove 'Testamos a fundo' e 6 blocos aggregateRating)
- adiciona .gitignore"

git push
```

## Se você NÃO tiver acesso de escrita

Não tente contornar com API sem token nem invente credenciais. Em vez disso,
**me devolva um passo a passo para eu executar na interface web do GitHub**,
usando o fato de que renomear um arquivo para um caminho contendo `/` move o
arquivo (Edit → clicar no nome do arquivo → digitar o caminho novo → Commit).
Liste cada arquivo com o caminho de origem e o de destino, na ordem dos passos 1
a 5 acima, e avise que no passo 1 o GitHub vai perguntar se quero substituir o
arquivo existente — a resposta é sim.

---

## Verificação obrigatória ao final

Rode e me mostre a saída dos três:

```bash
# 1) nenhuma pasta de staging sobrando — saída esperada: vazia
git ls-files | grep '^lote-'

# 2) árvore final — esperado: 39 arquivos
git ls-files | wc -l

# 3) o teste que importa — esperado: 0 erros
python3 tools/checar_conformidade.py '*.html' --resumo
```

Se o item 3 acusar **5 erros**, o passo 1 não pegou e os modelos defeituosos
continuam na raiz. Esse é o único item da lista com consequência fora do
repositório — refaça antes de dar a tarefa por concluída.

Bônus, se quiser confirmar que o caminho relativo sobreviveu à mudança de pasta:

```bash
python3 tools/ledger.py validar   # esperado: 30 capturas, 0 erros, 4 alertas
```

## Árvore final esperada

```
Ai-skill/
├── .gitignore
├── README.md
├── modelo-2-Power-Bank-no-Avião.html          ✅ corrigido
├── modelo-layout-da-Apple-TV-4K.html          ✅ corrigido
├── regras_editoriais_ia_curadoria_prime.md
├── articles/     (6)
├── audit/        (3)  README.md, auditoria-48-artigos.csv, pauta-90-dias.csv
├── skills/       (18)
└── tools/        (7)  README.md, exemplo-produto.json, 5 scripts .py
```

## Restrições

- Trabalhe direto na branch `main`.
- Não toque em `articles/`, `skills/`, `README.md` nem
  `regras_editoriais_ia_curadoria_prime.md`.
- Não altere o **conteúdo** de nenhum arquivo. Esta tarefa é só movimentação de
  caminhos, mais a criação do `.gitignore`.
- Não crie uma pasta `skills/` nova nem mexa na existente.
- Responda em português.
