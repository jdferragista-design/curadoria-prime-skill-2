# PROMPT — Limpeza dos modelos e da pasta `articles/`

> **Como usar:** cole tudo isto como primeira mensagem de um chat novo.
> Antes de enviar, anexe o arquivo `curadoria-prime-repo.zip` ao chat
> (ou baixe o repo em `github.com/jdferragista-design/curadoria-prime-skill`
> → Code → Download ZIP, e anexe esse).
> Sem o ZIP anexado o chat novo não tem os arquivos.

---

## Contexto

Sou dono do **curadoriaprime.com**, site brasileiro de reviews de produto com links
de afiliado (Amazon e Mercado Livre). O conteúdo é produzido com apoio de IA dentro de
um processo editorial humano. Tenho um repositório privado,
`jdferragista-design/curadoria-prime-skill`, que guarda as regras editoriais, os
scripts de verificação e os **modelos de artigo** usados como molde para tudo que
publico.

Adote a persona de **especialista em agentes de IA e em conformidade editorial para
sites de afiliado no Brasil**. Responda sempre em português do Brasil. Seja direto:
aponte o que está errado antes de elogiar o que está certo.

### O que já está resolvido — não refaça

- O repositório novo está no ar e íntegro. O antigo (`Ai-skill`) foi deletado.
- `tools/corrigir_artigos.py` já é a **v2**, que lê `content.raw` via `?context=edit`.
  A v1 lia `content.rendered` e, ao gravar de volta, o `wpautop` do WordPress injetava
  centenas de `<br />` que destruíam o layout (num post, `<br>` foi de 10 para 365).
  **Nunca rode a v1 com `--aplicar`.** É irreversível.
- Os links de afiliado dos modelos já têm `rel="sponsored"`, e a divulgação de comissão
  já aparece antes do primeiro link.
- A ressalva de honestidade ("não testamos fisicamente") já está nos dois modelos.

---

## Diagnóstico já feito — ponto de partida, confira mas não repita do zero

Rodei `python3 tools/checar_conformidade.py` nos seis HTML. Resultado:

| Arquivo | Erros | Alertas |
|---|---|---|
| `skills/curadoria-review/assets/modelos/modelo-power-bank-aviao.html` | 0 | 2 |
| `skills/curadoria-review/assets/modelos/modelo-layout-apple-tv-4k.html` | 0 | 1 |
| `articles/alternativas-galaxy-tab-s10-fe-ipad-estudar.html` | 0 | 4 |
| `articles/tablets-para-volta-as-aulas-2026.html` | 0 | 6 |
| `articles/volta-as-aulas-2026-versao-antiga.html` | 0 | 1 |
| `articles/preview-tablets.html` | **1** | 6 |

### Defeito nº 1 — o grave: modelos que recomendam sem apontar defeito

`modelo-power-bank-aviao.html` recomenda **5 power banks**, com preço e link de compra
para cada um, e **não traz um único contra**. Busquei por "contra", "ponto fraco",
"limitação", "desvantagem": zero ocorrências. O `modelo-layout-apple-tv-4k.html` tem o
mesmo problema.

Isso importa por três motivos, em ordem de gravidade:

1. **É o molde.** Todo artigo gerado a partir dele herda a ausência de contras. O
   defeito não fica em dois arquivos: entra em tudo que eu publicar daqui pra frente.
2. **É o padrão que o Google pune.** Em 2026 o Google passou a tratar *biased best-of
   listicles* — listas "melhores X" sem contraponto real — como sinal de spam de
   conteúdo. Sites de review com afiliado e conteúdo de IA perderam de 40% a 70% de
   tráfego na atualização de março de 2026, e o motivo citado foi ausência de sinais de
   avaliação de primeira mão.
3. **O checker já reclama.** O alerta `[imparcialidade] Bloco de contras não
   localizado` está lá, sendo ignorado.

### Defeito nº 2 — arquivos duplicados em `articles/`

`preview-tablets.html` (5.462 palavras) tem **os 11 títulos H2 exatamente iguais** aos
de `tablets-para-volta-as-aulas-2026.html` (5.832 palavras). É rascunho da mesma peça.
É também o único arquivo com erro de bloqueio: `[autoria] Sem assinatura de autor
visível`.

`volta-as-aulas-2026-versao-antiga.html` (7.164 palavras) é, pelo nome e pelo conteúdo,
versão superada da mesma pauta.

Minha inclinação é **deletar os dois**, não consertar. Mas quero seu parecer antes:
diga se algum deles tem trecho que valha resgatar para o arquivo canônico.

---

## Tarefa

Trabalhe **só nos arquivos locais**. Você não tem credencial de escrita no GitHub —
não tente `git push`, vai falhar. Eu subo as alterações pela interface web depois.

### Etapa 1 — confirmar o diagnóstico

```bash
cd ai-skill-v2   # ajuste ao caminho onde o ZIP foi extraído

python3 tools/checar_conformidade.py 'skills/curadoria-review/assets/modelos/*.html'
python3 tools/checar_conformidade.py 'articles/*.html'
```

Leia a saída completa, não só o resumo. Me diga se bate com a tabela acima e se
encontrou algo que eu não listei.

### Etapa 2 — decidir sobre as duplicatas

Compare `preview-tablets.html` com `tablets-para-volta-as-aulas-2026.html` e
`volta-as-aulas-2026-versao-antiga.html` entre si. Recomende: apagar, fundir ou manter.
Justifique. **Não apague nada sem eu confirmar.**

### Etapa 3 — inserir contras nos dois modelos

Adicione um bloco de contras real em cada modelo, para **cada produto recomendado**.

Restrição técnica do checker — ele só reconhece o bloco se o título for exatamente
`Contras`, `Pontos de Atenção` ou `Pontos Negativos`, dentro de uma tag `<h2>`–`<h6>`,
seguido de um `<ul>`. A regra está em `tools/checar_conformidade.py`, linha 251. Use
`Pontos de Atenção`, que combina com o tom do site.

Mínimo **3 contras por produto**, e precisam ser contras de verdade. Nada de defeito
disfarçado de elogio ("a única desvantagem é ser bom demais"). Como não há teste
físico, extraia os contras de:

- limitações objetivas de especificação (peso, ausência de porta, tempo de recarga,
  falta de certificação);
- reclamações recorrentes em avaliações de compradores verificados e no Reclame Aqui,
  que é a base metodológica que o próprio modelo já declara usar;
- o que o produto **não** faz e o comprador provavelmente espera que faça.

Preserve o HTML existente: as classes CSS, a estrutura de grid e flex, e o JSON-LD.
O `modelo-power-bank-aviao.html` tem JSON-LD válido e completo — não quebre.

### Etapa 4 — validar

```bash
python3 tools/checar_conformidade.py 'skills/curadoria-review/assets/modelos/*.html'
```

Meta: **0 erros e 0 alertas de `[imparcialidade]`** nos dois modelos.

Confirme também que o HTML continua íntegro — conte as tags `<div>` de abertura e
fechamento antes e depois da sua edição, e me mostre os dois números.

### Etapa 5 — propagar a regra

Depois de corrigir os modelos, atualize o texto normativo para que a exigência valha
para todo artigo futuro, não só para esses dois arquivos:

- `skills/curadoria-review/references/regras-editoriais.md` — este é o documento
  **canônico**, com 900 linhas. O arquivo de mesmo tema na raiz do repositório é apenas
  um ponteiro para ele; não duplique conteúdo lá.
- `skills/curadoria-review/assets/checklist-bloqueio.md` — espelho parcial da §15.

Proponha a redação da nova regra e **me mostre antes de gravar**. Ela deve dizer, em
substância: nenhum produto pode ser recomendado sem no mínimo 3 pontos de atenção
verificáveis, e a ausência desse bloco bloqueia a publicação.

---

## Regras de trabalho

- Português do Brasil, sempre.
- Não invente contra de produto. Se não houver base para 3, diga quantos conseguiu
  sustentar e por quê — é melhor eu saber do que receber texto inventado. Alegar
  característica falsa sobre produto é infração ao art. 37 do Código de Defesa do
  Consumidor.
- Não mexa em `tools/corrigir_artigos.py`. Está na v2 correta e validada.
- Não toque nos posts publicados no WordPress nesta conversa. Isso é a fase seguinte.
- Mostre o diff antes de gravar qualquer arquivo.

---

## O que vem depois — só para você não me sugerir fora de hora

Terminada esta limpeza, a fase seguinte é a remediação dos **15 artigos já no ar**,
começando por `python3 tools/corrigir_artigos.py --dry-run --id 2943` e conferindo que
a saída diz `fonte: content.raw`. Depois vêm as **36 alegações de teste físico
inexistente** espalhadas por 18 artigos, que exigem reescrita humana. Não comece por
aí. O molde primeiro.
