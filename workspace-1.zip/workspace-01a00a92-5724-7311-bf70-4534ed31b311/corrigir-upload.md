# Não, ainda não está certo — mas o conserto é rápido

Os arquivos chegaram todos. **O problema é onde eles estão.**

Os nomes das pastas de staging (`lote-0…`, `lote-1…`, `lote-2…`) foram junto para
o repositório. Eram só rótulos para organizar o upload — não deviam existir lá.

---

## O que está no repo agora

```
Ai-skill/
├── modelo-2-Power-Bank-no-Avião.html      🔴 versão COM DEFEITO, ainda no ar
├── modelo-layout-da-Apple-TV-4K.html      🔴 versão COM DEFEITO, ainda no ar
├── lote-0-modelos-corrigidos/             ⚠️  as versões boas, no lugar errado
│   ├── modelo-2-Power-Bank-no-Avião.html
│   └── modelo-layout-da-Apple-TV-4K.html
├── lote-1-scripts/                        ⚠️  deveria ser tools/
│   └── (5 scripts)
└── lote-2-docs-e-dados/                   ⚠️  deveria ser tools/ + audit/
    └── (5 arquivos)
```

**O mais grave:** os modelos corrigidos não substituíram os defeituosos. Foram
parar numa pasta ao lado. Confirmei rodando a trava:

| | erros |
|---|---|
| `modelo-*.html` (raiz) | 🔴 **5** — `"Testamos a fundo"` + 6 `aggregateRating` |
| `lote-0-modelos-corrigidos/modelo-*.html` | ✅ 0 |

Os hashes confirmam que são arquivos diferentes. **A versão que qualquer pessoa
vai copiar continua sendo a defeituosa.**

Uma coisa boa: o `ledger.py` funcionou mesmo de dentro de `lote-1-scripts/`,
porque a pasta está na raiz e `../skills/…` resolve igual. Depois de renomear
para `tools/` continua funcionando.

Falta também o `.gitignore`.

---

## Como consertar — 4 passos na interface do GitHub

Tudo por renomeação. Não precisa subir nada de novo, exceto o `.gitignore`.

No GitHub, renomear um arquivo para um caminho com `/` **move** o arquivo. É esse
truque que resolve tudo aqui.

### Passo 1 — substituir os 2 modelos defeituosos

Abra `lote-0-modelos-corrigidos/modelo-layout-da-Apple-TV-4K.html` → ícone de
lápis (**Edit**) → clique no **nome do arquivo** no topo → apague o prefixo da
pasta, deixando só:

```
modelo-layout-da-Apple-TV-4K.html
```

O GitHub vai avisar que o arquivo já existe e perguntar se quer substituir.
**Sim, é exatamente isso que queremos.**

Repita para `modelo-2-Power-Bank-no-Avião.html`.

Commit:
```
Substituir modelos pela versão corrigida (§2.2 e §2.4)
```

Ao final, a pasta `lote-0-modelos-corrigidos/` desaparece sozinha — o Git remove
pastas vazias.

### Passo 2 — `lote-1-scripts/` vira `tools/`

Para cada um dos 5 scripts: **Edit** → clique no nome → troque o prefixo:

| de | para |
|---|---|
| `lote-1-scripts/gerar_artigo.py` | `tools/gerar_artigo.py` |
| `lote-1-scripts/checar_conformidade.py` | `tools/checar_conformidade.py` |
| `lote-1-scripts/ledger.py` | `tools/ledger.py` |
| `lote-1-scripts/corrigir_artigos.py` | `tools/corrigir_artigos.py` |
| `lote-1-scripts/publicar_wp.py` | `tools/publicar_wp.py` |

### Passo 3 — distribuir o `lote-2-docs-e-dados/`

Este divide em duas pastas, e os dois README voltam ao nome original:

| de | para |
|---|---|
| `lote-2-docs-e-dados/README-tools.md` | `tools/README.md` |
| `lote-2-docs-e-dados/exemplo-produto.json` | `tools/exemplo-produto.json` |
| `lote-2-docs-e-dados/README-audit.md` | `audit/README.md` |
| `lote-2-docs-e-dados/auditoria-48-artigos.csv` | `audit/auditoria-48-artigos.csv` |
| `lote-2-docs-e-dados/pauta-90-dias.csv` | `audit/pauta-90-dias.csv` |

### Passo 4 — criar o `.gitignore`

**Add file → Create new file**, nome `.gitignore`:

```
__pycache__/
*.pyc
.env
artigo.html
```

---

## Alternativa: uma linha de comando

Se tiver git na máquina, os 4 passos viram isto:

```bash
git clone https://github.com/jdferragista-design/Ai-skill.git
cd Ai-skill

mv lote-0-modelos-corrigidos/*.html .
mv lote-1-scripts tools
mv lote-2-docs-e-dados/README-tools.md tools/README.md
mv lote-2-docs-e-dados/exemplo-produto.json tools/
mkdir audit
mv lote-2-docs-e-dados/README-audit.md audit/README.md
mv lote-2-docs-e-dados/*.csv audit/
rmdir lote-0-modelos-corrigidos lote-2-docs-e-dados

printf '__pycache__/\n*.pyc\n.env\nartigo.html\n' > .gitignore

git add -A
git commit -m "Reorganizar upload: tools/ e audit/; substituir modelos pela versão corrigida"
git push
```

---

## Como saber que ficou certo

A árvore final deve ser:

```
Ai-skill/
├── .gitignore
├── README.md
├── modelo-2-Power-Bank-no-Avião.html      ← versão corrigida
├── modelo-layout-da-Apple-TV-4K.html      ← versão corrigida
├── regras_editoriais_ia_curadoria_prime.md
├── articles/          (6 arquivos)
├── audit/             (3 arquivos)
├── skills/            (18 arquivos)
└── tools/             (7 arquivos)
```

**Nenhuma pasta começando com `lote-`.** Total: 39 arquivos.

E o teste que importa, rodado na raiz do repo:

```bash
python3 tools/checar_conformidade.py '*.html' --resumo
```

Deve dar **0 erros**. Se ainda acusar 5, o passo 1 não pegou e os modelos
defeituosos continuam na raiz — é o único erro desta lista que tem consequência
real, porque é o arquivo que as pessoas copiam.
