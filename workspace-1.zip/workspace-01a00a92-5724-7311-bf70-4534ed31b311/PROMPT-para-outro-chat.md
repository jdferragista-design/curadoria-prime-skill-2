# Prompt para o outro chat do Arena.ai

**Sobre o Contex:** não vale a pena. Se o outro chat é do Arena.ai, ele tem as
mesmas ferramentas que eu — e a mesma limitação: **nenhum de nós consegue dar
push sem credencial do GitHub.** Usar o Contex como ponte só transferiria o
problema de lugar; você teria que subir 11 arquivos lá (com o mesmo limite de 5
por vez) para depois pedir a alguém que também não consegue gravar.

Já que o gargalo é o upload manual de qualquer jeito, **eu já fiz a parte que
podia ser feita sem credencial.** Sobrou menos trabalho para você.

---

## O que já está pronto

**Os dois modelos com defeito estão corrigidos e validados** em
`envio-lotes/lote-0-modelos-corrigidos/`. Passaram de 5 erros para 0.

| | antes | depois |
|---|---|---|
| `modelo-layout-da-Apple-TV-4K.html` | 3 erros | ✅ 0 |
| `modelo-2-Power-Bank-no-Avião.html` | 2 erros | ✅ 0 |

O que mudei, e só isso — diff de 7 inserções e 8 deleções:

- `"Testamos a fundo a 3ª geração"` → `"Analisamos a fundo a 3ª geração"` (§2.2).
  A ressalva "não testamos esta unidade fisicamente" foi **preservada**.
- 6 blocos `aggregateRating` removidos (1 no Apple TV, 5 no Power Bank) — §2.4.
  Confirmei que o JSON-LD continua sintaticamente válido nos dois arquivos.

---

## Os 3 uploads

Tudo pela interface do GitHub, na branch `main`. Nenhum chat necessário.

`https://github.com/jdferragista-design/Ai-skill` → **Add file** → **Upload files**

### Upload 1 — os modelos corrigidos (2 arquivos)

De `envio-lotes/lote-0-modelos-corrigidos/`:

```
modelo-2-Power-Bank-no-Avião.html
modelo-layout-da-Apple-TV-4K.html
```

Substituem os que estão na raiz — mesmo nome, o GitHub sobrescreve.

Commit:
```
Corrigir violações §2.2 e §2.4 nos modelos de layout

- "Testamos a fundo" vira "Analisamos a fundo" no modelo Apple TV 4K;
  a ressalva de que não testamos a unidade fisicamente foi mantida
- remove 6 blocos aggregateRating (nota agregada de terceiros publicada
  como se fosse nossa avaliação)

Os posts 4537 e 4541 herdaram estes defeitos e precisam da mesma correção.
```

### Upload 2 — os scripts (5 arquivos)

De `envio-lotes/lote-1-scripts/`. **Antes de arrastar**, no campo de nome do
arquivo digite `tools/` para criar a pasta — ou arraste a pasta `tools` inteira
de `ai-skill-merge/`, que é mais simples e preserva a estrutura sozinha.

```
tools/gerar_artigo.py
tools/checar_conformidade.py
tools/ledger.py
tools/corrigir_artigos.py
tools/publicar_wp.py
```

Commit:
```
Adicionar tools/ — regras editoriais como código executável

- checar_conformidade.py: trava com 16 checagens, exit 1 se reprovar
- gerar_artigo.py: schema opt-in (§7.3), author Person (§2.6)
- ledger.py: porteiro do LEDGER.csv, informa o que o histórico autoriza afirmar
- corrigir_artigos.py, publicar_wp.py

Sem dependências externas.
```

### Upload 3 — docs e dados (5 arquivos)

De `envio-lotes/lote-2-docs-e-dados/`. **Atenção aos nomes** — os dois README
foram renomeados aqui para não colidirem no mesmo lote, e precisam voltar ao
nome original no destino:

| arquivo no lote | caminho no repo |
|---|---|
| `README-tools.md` | `tools/README.md` |
| `exemplo-produto.json` | `tools/exemplo-produto.json` |
| `README-audit.md` | `audit/README.md` |
| `auditoria-48-artigos.csv` | `audit/auditoria-48-artigos.csv` |
| `pauta-90-dias.csv` | `audit/pauta-90-dias.csv` |

Renomear na hora do upload é chato. **Mais fácil:** faça dois uploads arrastando
as pastas `tools` e `audit` de `ai-skill-merge/` diretamente — elas já têm os
nomes certos, e o GitHub aceita pasta arrastada sem contar arquivo por arquivo.

Commit:
```
Adicionar audit/ e documentação de tools/

audit/ registra o estado real dos 48 artigos publicados: 27 têm problema
(37 alegações de teste não realizado, 48 links sem rel="sponsored",
10 sem divulgação de afiliado).
```

### Falta o `.gitignore`

36 bytes, não vale um upload. **Add file → Create new file**, nome `.gitignore`:

```
__pycache__/
*.pyc
.env
artigo.html
```

---

## Se ainda assim quiser usar um chat

Aí o prompt é este — mas note que ele **só serve se aquele chat tiver credencial
de escrita no GitHub**, que é justamente o que eu não tenho:

```
Você tem acesso de escrita ao repositório
github.com/jdferragista-design/Ai-skill.

Estou anexando arquivos em levas de 5. Aguarde eu dizer "acabou" antes de
commitar qualquer coisa.

Destino de cada arquivo na branch main:

  modelo-2-Power-Bank-no-Avião.html   → raiz (substitui o existente)
  modelo-layout-da-Apple-TV-4K.html   → raiz (substitui o existente)
  gerar_artigo.py                     → tools/
  checar_conformidade.py              → tools/
  ledger.py                           → tools/
  corrigir_artigos.py                 → tools/
  publicar_wp.py                      → tools/
  README-tools.md                     → tools/README.md      (RENOMEAR)
  exemplo-produto.json                → tools/
  README-audit.md                     → audit/README.md      (RENOMEAR)
  auditoria-48-artigos.csv            → audit/
  pauta-90-dias.csv                   → audit/

Crie também .gitignore na raiz com este conteúdo:

  __pycache__/
  *.pyc
  .env
  artigo.html

Regras:

1. NÃO altere o conteúdo de nenhum arquivo. Já foram testados contra um
   clone real deste repositório. O checar_conformidade.py tem lógica sutil
   — distingue "não testamos fisicamente" de "testamos a fundo" — e um
   refactor bem-intencionado quebra isso silenciosamente.

2. tools/ e audit/ vão na RAIZ do repo, não aninhadas. O ledger.py resolve
   ../skills/curadoria-mercado/assets/historico-precos/LEDGER.csv e quebra
   fora da raiz.

3. NÃO crie nem toque em nada dentro de skills/. Já existe no repo.

4. Faça DOIS commits separados: um para os 2 modelos da raiz, outro para
   tools/ + audit/ + .gitignore. São mudanças de natureza diferente e
   devem poder ser revertidas de forma independente.

Depois de commitar, se você puder executar comandos, rode na raiz:

  python3 tools/ledger.py validar
  python3 tools/checar_conformidade.py 'articles/*.html' --resumo
  python3 tools/checar_conformidade.py '*.html' --resumo

Esperado:
  1º — 30 capturas, 0 erros, 4 alertas
  2º — 0 erros em 3 dos 4. O preview-tablets.html acusa 1 erro por falta
       de assinatura e isso está CORRETO: é um preview. Não conserte.
  3º — 0 erros nos 2 modelos.

Me diga os hashes dos commits ao terminar.
```

---

## Depois dos uploads

**Proteja a `main`** — isso só você pode fazer, nenhum agente faz por API sem
permissão de admin:

Settings → Branches → Add rule → `main` → *Require a pull request before merging*

**Ainda em aberto**, quando quiser retomar:

- Aplicar as mesmas duas correções aos posts **4537** e **4541** no WordPress
- A fila **P0** da auditoria: 12 artigos de maior risco
- As 6 checagens restantes do checker (das 9 previstas; 3 já implementei)
