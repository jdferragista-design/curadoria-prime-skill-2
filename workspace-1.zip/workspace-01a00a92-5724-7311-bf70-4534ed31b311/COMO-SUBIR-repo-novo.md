# Repositório novo — pronto para subir

Tudo está em **`ai-skill-v2/`** (39 arquivos versionados, já com um commit inicial
feito). Também há o **`curadoria-prime-repo.zip`** com a mesma árvore, caso prefira
subir pelo navegador.

---

## Como subir

### Opção A — pela linha de comando (recomendada)

Crie o repositório **vazio** no GitHub: sem README, sem `.gitignore`, sem licença.
Qualquer arquivo inicial cria um commit que vai conflitar com o histórico daqui.

Depois, de dentro de `ai-skill-v2/`:

```bash
git remote add origin https://github.com/jdferragista-design/<NOME-NOVO>.git
git push -u origin main
```

O commit inicial já está feito, com a mensagem descrevendo as correções.

### Opção B — pelo navegador

1. Crie o repositório **marcando** "Add a README file" (para poder usar o editor web).
2. Descompacte o `curadoria-prime-repo.zip` no seu computador.
3. **Add file → Upload files** → arraste as **pastas** `articles/`, `audit/`,
   `skills/`, `tools/` e os arquivos soltos da raiz.

> Arraste as **pastas inteiras**, nunca arquivo por arquivo. Foi arrastando
> arquivos avulsos que a estrutura se perdeu nas duas vezes anteriores: o
> navegador solta tudo na raiz. O Chrome preserva a hierarquia quando você
> arrasta o diretório.

Depois do upload, confira que existe `tools/corrigir_artigos.py` e que **não**
existe nenhum `corrigir_artigos-*.py` na raiz.

---

## Proteja a `main` antes de trabalhar

No repositório novo: **Settings → Rules → New ruleset**, alvo `main`, com
*Require a pull request before merging*, *Block force pushes* e *Restrict
deletions*. O repo antigo tinha isso (ruleset `20804816`); o novo nasce sem.

---

## O que foi corrigido

### 1. `tools/corrigir_artigos.py` — agora é a v2, no caminho certo

Este era o problema central. A v1 lia `content.rendered` (HTML já processado pelo
`wpautop`) e gravava de volta em `content`, fazendo o WordPress reprocessar:

| post | `<br>` antes | depois |
|------|-------------:|-------:|
| 2943 | 10 | 365 |
| 3226 | 35 | 526 |
| 3183 |  2 | 268 |

A v2 lê o fonte com `context=edit`, exige credencial válida (recusa gravar sem
ela), faz backup do raw antes de cada POST, relê o post depois e **restaura
sozinha** se detectar reprocessamento. Também corrigi a paginação — a v1 pedia
`per_page=50` numa página só, e com 48 artigos estava a dois posts de truncar em
silêncio.

Um achado que confirma a decisão de tratar Gutenberg: os modelos HTML do repo
usam blocos `<!-- wp:html -->`. O caminho Gutenberg da v2 (que embrulha o bloco
de divulgação em `wp:html` em vez de inserir `<div>` solto) não era hipótese.

### 2. Regras editoriais desduplicadas

Havia duas cópias byte a byte idênticas, de 728 linhas cada (md5
`9f75c35bfd94f3998c444584a6dfa340`). Duas cópias que precisam mudar juntas é uma
que fica para trás.

- **Canônica:** `skills/curadoria-review/references/regras-editoriais.md` — é a
  que as skills carregam, e cinco arquivos já apontavam para ela contra dois.
- **Raiz:** virou ponteiro explícito. Não apaguei porque o caminho está
  referenciado externamente; apagar quebraria em silêncio.
- `assets/checklist-bloqueio.md` ganhou aviso de que é espelho parcial da §15.

### 3. §17 instalada

Estava órfã em `/home/user/secao-17-cadencia-revisao.md`, escrita mas nunca
incorporada. Agora está no fim das regras canônicas, e a §16 a referencia no item
"atualização de páginas que já recebem impressões". As regras foram de 728 para
900 linhas.

### 4. Falsos positivos do checker

- **`[honestidade]`**: a regex exigia literalmente "não realizamos testes
  físicos". A frase real usada nos artigos — "não testamos esta unidade
  fisicamente" — não casava, e o checker acusava artigo honesto. Ampliei para as
  formas reais. Testei 7 casos, incluindo um negativo ("Testamos o produto por
  duas semanas") que continua sendo pego.
- **`[fontes]`**: o alerta agora explica que artigo sem dado externo
  legitimamente não tem a seção (§3.4).

### 5. Nomes de arquivo

- `modelo-2-Power-Bank-no-Avião.html` e `modelo-layout-da-Apple-TV-4K.html`
  saíram da raiz para `skills/curadoria-review/assets/modelos/`, sem acento e sem
  espaço. As referências em `analise-visual-apple-tv.md` foram atualizadas e
  agora são links clicáveis.
- `articles/volta-às-aulas-2026-versão- antiga.html` → `volta-as-aulas-2026-versao-antiga.html`
  (tinha acento **e** espaço no meio do nome).

### 6. Limpeza

- `corrigir_artigos-PATCHED.py` e `corrigir_artigos-v2.patch` **não** foram para o
  repo novo. O primeiro virou `tools/corrigir_artigos.py`; o segundo é artefato de
  revisão.
- `.gitignore` agora cobre `backups/` (os raws que a v2 salva) e `*.patch`.
- READMEs atualizados: o da raiz documenta onde editar as regras e a remediação;
  o de `tools/` explica por que a credencial é obrigatória até no `--dry-run`.

---

## Validação executada

```
sintaxe dos 5 .py ......................... OK
ledger.py validar ......................... 0 erros, 4 alertas (mesmos de antes)
links markdown relativos .................. 0 quebrados
duplicatas por md5 ........................ nenhuma
guarda "sem credencial" ................... recusa com explicação
guarda 401 ................................ orienta sobre senha de aplicação
guarda --tls-inseguro + --aplicar ......... recusa
regex [honestidade] ....................... 7/7 casos, incluindo negativo
transformação HTML (2943/3226/3183/3858) .. <br> estável, <div> balanceado,
                                            0 afiliados sem sponsored
```

**O que não foi validado:** o caminho de escrita. Não tenho credencial do WP, então
o POST, o backup e a verificação pós-gravação nunca rodaram de verdade. A lógica
está testada, mas o primeiro `--aplicar` é o teste real — por isso continue fazendo
**um artigo primeiro**, conferido no navegador, antes do lote dos 15.

---

## Primeiros passos no repo novo

1. Subir e proteger a `main`.
2. `--dry-run --id 2943` e confirmar `fonte: content.raw` na saída.
3. `--aplicar --id 2943`, conferir no navegador.
4. Lote dos 15 (não 8 — o script também toca sete artigos da fila manual).
5. Reescrita manual das 36 alegações em 18 artigos. Comece por `3523` (QCY T13,
   7 alegações) e `3002` (LG 55AU801, 6) — juntos são 13 das 36.
6. Post 4537: aplicar `/home/user/4537-apple-tv-CORRIGIDO-v2.html`.
7. Post 4541: as 5 `aggregateRating`, as 2 alegações e o checklist comentado de
   4.099 caracteres.

A pauta de 90 dias (`audit/pauta-90-dias.csv`) fica atrás disso tudo, com exceção
dos guias de Black Friday, que começam em 15/09.
