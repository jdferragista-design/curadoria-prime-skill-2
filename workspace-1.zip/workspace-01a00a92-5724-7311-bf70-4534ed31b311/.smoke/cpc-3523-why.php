<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$h = file_get_contents('/home/user/qcy3523.html');
$a = CPC_Rules::analisar($h);
foreach($a as $x){
  if($x['auto']) continue;
  foreach($x['ocorrencias'] as $o){
    list($n,$e)=CPC_Editor::substituir($h,$o['trecho'],'X');
    if(!$e) continue;
    echo "=== RECUSA [".$x['regra']."]\n";
    echo "trecho: ".mb_substr($o['trecho'],0,150,'UTF-8')."\n";
    // por que? achar a 1a palavra e ver o html cru ao redor
    $palavras = preg_split('/\s+/u', trim($o['trecho']));
    $p1 = $palavras[0]; $p2 = $palavras[1] ?? '';
    echo "  1a palavra '$p1' ocorre ".substr_count($h,$p1)."x no HTML\n";
    $pos = strpos($h, $p1.' '.$p2);
    if($pos===false) $pos = strpos($h,$p1);
    if($pos!==false) echo "  HTML cru: ".str_replace("\n",'\n',substr($h,max(0,$pos-60),260))."\n";
    echo "\n";
  }
}
