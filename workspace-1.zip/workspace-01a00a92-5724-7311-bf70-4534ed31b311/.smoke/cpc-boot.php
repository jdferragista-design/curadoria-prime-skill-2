<?php
define('ABSPATH','/fake/wp/');
$GLOBALS['__hooks']=[];
function add_action($h,$c,$p=10,$a=1){ $GLOBALS['__hooks']['action'][$h][]=$c; }
function add_filter($h,$c,$p=10,$a=1){ $GLOBALS['__hooks']['filter'][$h][]=$c; }
function is_admin(){ return true; }
function get_option($k,$d=array()){ return $d; }
function add_option($k,$v){ return true; }
function wp_parse_args($a,$d){ return array_merge($d,(array)$a); }
function plugin_dir_path($f){ return dirname($f).'/'; }
function plugin_dir_url($f){ return 'http://x/wp-content/plugins/curadoria-conformidade/'; }
function plugin_basename($f){ return 'curadoria-conformidade/'.basename($f); }
function register_activation_hook($f,$c){ $GLOBALS['__hooks']['activate'][]=$c; }
function register_deactivation_hook($f,$c){ $GLOBALS['__hooks']['deactivate'][]=$c; }
function __($s,$d=null){ return $s; }
function esc_html__($s,$d=null){ return $s; }
function esc_attr__($s,$d=null){ return $s; }
function _n($a,$b,$n,$d=null){ return $n==1?$a:$b; }
function add_menu_page(){ return 'toplevel_page_cpc-painel'; }
function add_submenu_page(){ return 'cpc_page_cpc-config'; }
function add_meta_box(){}
function wp_create_nonce($a){ return 'nonce'; }
function current_user_can(){ return true; }
function trailingslashit($s){ return rtrim($s,'/').'/'; }
require '/home/user/curadoria-conformidade/curadoria-conformidade.php';
echo "BOOTSTRAP OK\n";
foreach (['CPC_Plugin','CPC_Rules','CPC_Fixer','CPC_Diff','CPC_Scanner','CPC_Admin','CPC_Log'] as $c)
  printf("  %-14s %s\n", $c, class_exists($c)?'carregada':'*** FALTANDO ***');
$s = CPC_Plugin::settings();
echo "settings(): ".count($s)." chaves | autor=".$s['autor_canonico']." | post_types=".implode('/',$s['post_types'])."\n";
echo "constantes: ";
foreach (['CPC_VERSION','CPC_FILE','CPC_DIR','CPC_URL'] as $k) echo $k.'='.(defined($k)?'ok':'FALTA').' ';
echo "\nhooks: action=".count($GLOBALS['__hooks']['action']??[])." activate=".count($GLOBALS['__hooks']['activate']??[])." deactivate=".count($GLOBALS['__hooks']['deactivate']??[])."\n";
echo "regras conhecidas: ".count(CPC_Rules::rotulos())." | automaticas: ".implode(', ',CPC_Fixer::regras_automaticas())."\n";
