from playwright.sync_api import sync_playwright
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":900},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto("https://www.mercadolivre.com.br/noindex/catalog/reviews/MLB58587883?noIndex=true",
            timeout=60000,wait_until="networkidle")
    pg.wait_for_timeout(5000)
    print("url:",pg.url.split("?")[0])
    t=pg.inner_text("body")
    print("---- topo do texto ----")
    print(t[:900])
    open("/home/user/.smoke/_mlhub_txt.txt","w",encoding="utf-8").write(t)
    b.close()
