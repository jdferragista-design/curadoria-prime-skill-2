import sys
body=open('/home/user/correcoes/3002/CORPO-para-colar.html',encoding='utf-8').read()
html=f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#1a1a2e;line-height:1.7;max-width:820px;margin:0 auto;padding:25px;}}
img{{max-width:100%;height:auto}} table{{width:100%;border-collapse:collapse}} td,th{{border:1px solid #e2e2f0;padding:8px;font-size:14px}}
h2{{margin-top:34px}}</style></head><body>{body}</body></html>'''
open('/home/user/.smoke/3002-preview.html','w',encoding='utf-8').write(html)
print("preview escrito:",len(html))
