<?php
/**
 * Teste do motor de substituição (CPC_Editor). Sem WordPress.
 * Foco: garantir que ele NUNCA troque a ocorrência errada.
 */
define( 'ABSPATH', '/tmp/wp/' );

// stubs mínimos
function __( $t, $d = '' ) { return $t; }
function _n( $s, $p, $n, $d = '' ) { return $n == 1 ? $s : $p; }
function esc_html__( $t, $d = '' ) { return $t; }

require_once __DIR__ . '/../curadoria-conformidade/includes/class-cpc-editor.php';

$ok = 0; $fail = 0;
function t( $nome, $cond ) {
	global $ok, $fail;
	if ( $cond ) { $ok++; echo "  ok   $nome\n"; }
	else { $fail++; echo "  FALHA $nome\n"; }
}

echo "── substituição simples ──\n";
list( $r, $e ) = CPC_Editor::substituir( '<p>Nós testamos o fone por 3 semanas.</p>', 'testamos o fone', 'analisamos a ficha técnica do fone' );
t( 'troca única aplicada', '' === $e && strpos( $r, 'analisamos a ficha técnica do fone' ) !== false );
t( 'resto do HTML intacto', strpos( $r, '<p>' ) === 0 && strpos( $r, 'por 3 semanas' ) !== false );

echo "\n── recusa quando ambíguo ──\n";
$dup = '<p>testamos o fone</p><p>testamos o fone</p>';
list( $r2, $e2 ) = CPC_Editor::substituir( $dup, 'testamos o fone', 'X' );
t( 'recusa 2 ocorrências', '' !== $e2 );
t( 'html devolvido sem alteração', $r2 === $dup );
t( 'mensagem cita a contagem', strpos( $e2, '2' ) !== false );

echo "\n── recusa quando não encontra ──\n";
list( $r3, $e3 ) = CPC_Editor::substituir( '<p>nada aqui</p>', 'texto inexistente xyz', 'Y' );
t( 'recusa ausência', '' !== $e3 );
t( 'html intacto', $r3 === '<p>nada aqui</p>' );

echo "\n── âncora flexível: tag no meio do trecho ──\n";
$html = '<p>Nós <strong>testamos</strong> o fone por semanas.</p>';
list( $r4, $e4 ) = CPC_Editor::substituir( $html, 'testamos o fone', 'avaliamos a ficha do fone' );
t( 'casa apesar do <strong>', '' === $e4 );
t( 'substituiu de fato', strpos( $r4, 'avaliamos a ficha do fone' ) !== false );
t( 'não duplicou conteúdo', substr_count( $r4, 'por semanas' ) === 1 );

echo "\n── âncora flexível: &nbsp; e quebra de linha ──\n";
$html2 = "<p>Nós testamos&nbsp;o\n  fone hoje.</p>";
list( $r5, $e5 ) = CPC_Editor::substituir( $html2, 'testamos o fone', 'estudamos o fone' );
t( 'casa com nbsp/quebra', '' === $e5 && strpos( $r5, 'estudamos o fone' ) !== false );

echo "\n── flexível ambíguo também recusa ──\n";
$html3 = '<p>Nós <b>testamos</b> o fone.</p><p>testamos o  fone.</p>';
list( $r6, $e6 ) = CPC_Editor::substituir( $html3, 'testamos o fone', 'Z' );
t( 'recusa flexível ambíguo', '' !== $e6 && $r6 === $html3 );

echo "\n── no-op ──\n";
list( $r7, $e7 ) = CPC_Editor::substituir( '<p>abc</p>', 'abc', 'abc' );
t( 'texto igual = erro explícito', '' !== $e7 );
list( $r8, $e8 ) = CPC_Editor::substituir( '<p>abc</p>', '', 'x' );
t( 'original vazio = erro', '' !== $e8 );

echo "\n── lote ──\n";
$base = '<p>Nós testamos o fone. Depois testamos a caixa de som com cuidado.</p><p>Compre agora, últimas unidades!</p>';
list( $novo, $ap, $rec ) = CPC_Editor::aplicar_lote(
	$base,
	array(
		array( 'original' => 'testamos o fone', 'novo' => 'analisamos o fone', 'regra' => 'alegacao_teste' ),
		array( 'original' => 'testamos a caixa de som', 'novo' => 'analisamos a caixa de som', 'regra' => 'alegacao_teste' ),
		array( 'original' => 'últimas unidades', 'novo' => 'disponibilidade varia', 'regra' => 'urgencia_falsa' ),
		array( 'original' => 'inexistente zzz', 'novo' => 'algo', 'regra' => 'alegacao_teste' ),
		array( 'original' => 'Compre agora', 'novo' => '', 'regra' => 'urgencia_falsa' ), // vazio: ignorar
	)
);
t( '3 aplicadas', count( $ap ) === 3 );
t( '1 recusada', count( $rec ) === 1 );
t( 'campo vazio ignorado (não vira recusa)', $rec[0]['trecho'] === 'inexistente zzz' );
t( 'todas as trocas no texto final',
	strpos( $novo, 'analisamos o fone' ) !== false
	&& strpos( $novo, 'analisamos a caixa de som' ) !== false
	&& strpos( $novo, 'disponibilidade varia' ) !== false );
t( 'trecho de campo vazio preservado', strpos( $novo, 'Compre agora' ) !== false );
t( 'nenhum resto do texto antigo', strpos( $novo, 'testamos' ) === false );

echo "\n── segurança: trecho com regex especial ──\n";
$rx = '<p>Preço: R$ 1.299,00 (só hoje!)</p>';
list( $r9, $e9 ) = CPC_Editor::substituir( $rx, 'R$ 1.299,00 (só hoje!)', 'faixa usual R$ 1.250–1.400' );
t( 'metacaracteres não quebram', '' === $e9 && strpos( $r9, 'faixa usual' ) !== false );

echo "\n════ $ok ok · $fail falhas ════\n";
exit( $fail ? 1 : 0 );
