# -*- coding: utf-8 -*-
import re, sys

PATH = 'correcoes/3523/CORPO-para-colar.html'
s = open(PATH, encoding='utf-8').read()
orig_len = len(s)
subs = []

# ---- 1. padronizar 8.5 -> 8,5 no callout do topo
subs.append((
 '<strong style="color:#fbbf24;">Nota: 8.5/10</strong>',
 '<strong style="color:#fbbf24;">Nota: 8,5/10</strong>'))

# ---- 2. bloco de calculo da nota, inserido logo apos o callout verde do veredito
ANCHOR = '''Perde apenas para quem precisa de multipoint ou tem Samsung Galaxy com ecossistema completo.</p></div>'''

LINHAS = [
 ('Custo-benefício', '30%', '9,5', '2,85',
  'Entrega ANC de 28 dB, driver de 10 mm e app com equalizador por R$ 169–186, faixa em que os rivais diretos começam em R$ 229.'),
 ('Ficha técnica', '25%', '8,0', '2,00',
  'Bluetooth 5.3, ENC de 4 microfones e IPX5. Perde pontos por trazer apenas SBC e AAC (sem aptX/LDAC) e não ter carregamento sem fio.'),
 ('Satisfação verificada', '25%', '9,0', '2,25',
  '4,8/5 em 6.546 opiniões no Mercado Livre e 4,6/5 em 751 na Amazon — volume alto e avaliação consistente entre as duas lojas.'),
 ('Consenso técnico', '10%', '8,0', '0,80',
  'Aparece de forma recorrente em listas de melhor ANC de entrada, com a ressalva repetida sobre agudos e volume máximo.'),
 ('Confiança e suporte', '10%', '6,5', '0,65',
  'Marca consolidada no segmento e app com atualizações, mas assistência técnica limitada no Brasil e garantia dependente do vendedor.'),
]

cor = lambda n: '#28a745' if float(n.replace(',','.')) >= 8 else '#f59e0b'
linhas_html = ''.join(
 f'<tr style="background: {"#ffffff" if i%2==0 else "#f8f9fa"};">'
 f'<td style="padding: 14px 16px; border-bottom: 1px solid #e9ecef; vertical-align: top;">'
 f'<strong style="color: #2d3277;">{c}</strong><br><span style="color: #888; font-size: 13px;">peso {p}</span></td>'
 f'<td style="padding: 14px 16px; border-bottom: 1px solid #e9ecef; text-align: center; vertical-align: top;">'
 f'<strong style="color: {cor(n)}; font-size: 17px;">{n}</strong></td>'
 f'<td style="padding: 14px 16px; border-bottom: 1px solid #e9ecef; text-align: center; vertical-align: top; color: #555;">{sub}</td>'
 f'<td style="padding: 14px 16px; border-bottom: 1px solid #e9ecef; vertical-align: top; color: #555; font-size: 14.5px; line-height: 1.6;">{j}</td>'
 f'</tr>'
 for i,(c,p,n,sub,j) in enumerate(LINHAS))

BLOCO = (
'<h3 style="color: #2d3277; margin-top: 35px;">🧮 Como chegamos ao 8,5</h3>'
'<p>A nota não é uma impressão geral: ela vem de cinco critérios com pesos fixos, os mesmos aplicados a todo produto que avaliamos. '
'A régua completa está na página <a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/como-avaliamos/">Como Avaliamos e Pontuamos Produtos</a>. '
'Veja a conta deste fone, aberta:</p>'
'<div style="background: linear-gradient(135deg, #f8f9fa 0%, #f1f3f4 100%); padding: clamp(12px, 3.5vw, 25px); border-radius: 15px; border: 1px solid #e9ecef; margin: 25px 0; box-sizing: border-box; max-width: 100%;">'
'<p style="margin: 0 0 8px 0; font-size: 12.5px; color: #888; font-style: italic;">↔ deslize para ver a tabela completa</p>'
'<div style="overflow-x: auto; -webkit-overflow-scrolling: touch; max-width: 100%; margin: 0;">'
'<table style="width: 100%; min-width: 560px; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden;">'
'<thead><tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">'
'<th style="padding: 14px 16px; color: #fff; text-align: left; font-size: 15px;">Critério</th>'
'<th style="padding: 14px 16px; color: #fff; text-align: center; font-size: 15px;">Nota</th>'
'<th style="padding: 14px 16px; color: #fff; text-align: center; font-size: 15px;">Contribuição</th>'
'<th style="padding: 14px 16px; color: #fff; text-align: left; font-size: 15px;">Por que essa nota</th>'
'</tr></thead><tbody>' + linhas_html + '</tbody></table></div></div>'
'<div style="background: linear-gradient(135deg, #5a4fcf 0%, #764ba2 100%); border-radius: 12px; padding: clamp(16px, 4vw, 24px); margin: 25px 0; box-sizing: border-box; max-width: 100%;">'
'<p style="margin: 0 0 10px 0; color: #fff; font-size: 15px; line-height: 1.7;">'
'2,85 + 2,00 + 2,25 + 0,80 + 0,65 = <strong style="color: #fbbf24;">8,55</strong>, arredondado para o múltiplo de 0,5 mais próximo:</p>'
'<p style="margin: 0; color: #fff; font-size: 22px; font-weight: 700; line-height: 1.4;">'
'8,5/10 &nbsp;<span style="background: rgba(255,255,255,0.18); padding: 4px 12px; border-radius: 20px; font-size: 16px;">⭐ Recomendado</span></p></div>'
'<div style="background: #fffbeb; border-left: 5px solid #fde68a; padding: 18px 20px; margin: 25px 0; border-radius: 8px; box-sizing: border-box; max-width: 100%;">'
'<p style="margin: 0; color: #78350f; font-size: 15px; line-height: 1.7;">'
'<strong>O que essa nota não mede:</strong> conforto ao longo de horas, encaixe na sua orelha, timbre percebido e durabilidade real. '
'Nada disso pode ser verificado por documento, e por isso fica de fora do cálculo em vez de virar palpite com aparência de medida. '
'A nota avalia a proposta do produto, não o desempenho medido por nós.</p></div>')

subs.append((ANCHOR, ANCHOR + BLOCO))

for old, new in subs:
    n = s.count(old)
    if n != 1:
        print(f'ABORTADO: ocorrencias={n} para {old[:70]!r}'); sys.exit(1)
    s = s.replace(old, new, 1)

open(PATH, 'w', encoding='utf-8').write(s)
print(f'OK {len(subs)} substituicoes | {orig_len} -> {len(s)} B')
