import re, sys

def fix(path):
    b = open(path, encoding='utf-8').read()
    orig = b

    # 1) padding fixo -> fluido (clamp) nos wrappers de bloco, e box-sizing
    def pad(m):
        s = m.group(0)
        s = re.sub(r'padding:\s*25px;', 'padding: clamp(12px, 3.5vw, 25px);', s)
        s = re.sub(r'padding:\s*20px;', 'padding: clamp(12px, 3vw, 20px);', s)
        if 'box-sizing' not in s:
            s = s.replace('style="', 'style="box-sizing: border-box; max-width: 100%; ', 1)
        return s
    b = re.sub(r'<div style="background: linear-gradient\(135deg, #f8f9fa[^"]*"', pad, b)

    # 2) cada <table> ganha min-width e vai para dentro de um container rolavel
    out = []
    pos = 0
    n = 0
    for m in re.finditer(r'<table\b[^>]*>.*?</table>', b, re.S):
        tbl = m.group(0)
        if b[max(0,m.start()-90):m.start()].find('overflow-x') != -1:
            continue
        ncols = max(tbl.count('<th'), max((r.count('<td') for r in re.findall(r'<tr.*?</tr>', tbl, re.S)), default=0))
        minw = 560 if ncols >= 5 else (480 if ncols == 4 else 380)
        new_tbl = re.sub(r'(<table\b[^>]*style=")', r'\1min-width: %dpx; ' % minw, tbl, count=1)
        wrapped = ('<div style="overflow-x: auto; -webkit-overflow-scrolling: touch; '
                   'max-width: 100%; margin: 0;">' + new_tbl + '</div>')
        out.append(b[pos:m.start()]); out.append(wrapped); pos = m.end(); n += 1
    out.append(b[pos:])
    b = ''.join(out)

    # 3) trava geral: nada dentro do conteudo pode estourar a largura
    open(path, 'w', encoding='utf-8').write(b)
    print(f'{path}\n  tabelas envolvidas: {n} | bytes {len(orig)} -> {len(b)}')

for p in sys.argv[1:]:
    fix(p)
