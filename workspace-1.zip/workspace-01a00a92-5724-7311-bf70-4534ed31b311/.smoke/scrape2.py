from playwright.sync_api import sync_playwright
import json
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":900},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto("https://www.amazon.com.br/dp/B0FVFZDYG7",timeout=60000,wait_until="domcontentloaded")
    pg.wait_for_timeout(3000)
    for _ in range(6):
        pg.mouse.wheel(0,5000); pg.wait_for_timeout(1200)
    revs=pg.eval_on_selector_all('[data-hook="review"]',"""els=>els.map(e=>{
        const g=s=>{const n=e.querySelector(s);return n?n.innerText.trim():''};
        return {stars:g('[data-hook="review-star-rating"] .a-icon-alt')||g('.a-icon-alt'),
                date:g('[data-hook="review-date"]'),
                title:g('[data-hook="review-title"]'),
                body:g('[data-hook="review-body"]'),
                full:e.innerText}})""")
    out["amazon"]=revs
    print("=== AMAZON",len(revs),"===")
    for r in revs:
        print("\n---",r["stars"],"|",r["date"])
        print("TITLE:",r["title"].replace("\n"," / ")[:120])
        print("BODY :",r["body"].replace("\n"," ")[:400])
        if not r["body"]: print("FULL :",r["full"].replace("\n"," | ")[:400])
    # busca ML pelo produto
    pg2=ctx.new_page()
    pg2.goto("https://lista.mercadolivre.com.br/smart-tv-lg-55au801",timeout=60000,wait_until="domcontentloaded")
    pg2.wait_for_timeout(4000)
    items=pg2.eval_on_selector_all('a.poly-component__title, a.ui-search-link',"els=>els.slice(0,8).map(e=>({t:e.innerText,h:e.href}))")
    print("\n=== ML busca ===")
    for i in items: print("  -",i["t"][:95],"\n    ",i["h"][:120])
    out["ml_search"]=items
    b.close()
json.dump(out,open("/home/user/.smoke/_rev2.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
