# -*- coding: utf-8 -*-
b = open('.smoke/3523-corpo-novo.html', encoding='utf-8').read()
orig=b
P=[]
P.append(("comparativo-preco",
'<strong>QCY T13 ANC a R$ 169-186</strong> ou <strong><a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/samsung-galaxy-buds-core-vale-a-pena/" rel="noopener">Samsung Galaxy Buds Core</a> a R$ 229–380</strong>?',
'<strong>QCY T13 ANC (R$ 169–186)</strong> ou <strong><a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/samsung-galaxy-buds-core-vale-a-pena/" rel="noopener">Samsung Galaxy Buds Core</a> (R$ 229–380)</strong>? Faixas apuradas em agosto de 2026.'))
P.append(("tabela-preco-linha",
'Preço (agosto 2026)',
'Preço (faixa apurada em 15/08/2026)'))
P.append(("cta-precos",
'Preços de agosto 2026 — confira o prazo de entrega com seu CEP.',
'Faixas de preço apuradas em 15/08/2026 — confira o valor atual e o prazo de entrega com seu CEP antes de comprar.'))
out=b; falhou=[]
for tag,o,n in P:
    c=out.count(o)
    if c==1: out=out.replace(o,n)
    else: falhou.append((tag,c))
open('.smoke/3523-corpo-novo.html','w',encoding='utf-8').write(out)
print("aplicados:",len(P)-len(falhou),"/",len(P))
for t,c in falhou: print("  NAO:",t,c)
print("links:",out.count('<a '),"imgs:",out.count('<img'))
