<?php
define('ABSPATH', '/fake/wp/');
$GLOBALS['__hooks'] = [];
function add_action($h,$c,$p=10,$a=1){ $GLOBALS['__hooks']['action'][$h][]=$c; }
function add_filter($h,$c,$p=10,$a=1){ $GLOBALS['__hooks']['filter'][$h][]=$c; }
function is_admin(){ return true; }
function get_option($k,$d=array()){ return $d; }
function wp_parse_args($a,$d){ return array_merge($d,(array)$a); }
function plugin_dir_path($f){ return dirname($f).'/'; }
function plugin_dir_url($f){ return 'http://x/wp-content/plugins/ai-image-optimizer-alt/'; }
function register_activation_hook($f,$c){ $GLOBALS['__hooks']['activate'][]=$c; }
function __($s,$d=null){ return $s; }
function esc_html__($s,$d=null){ return $s; }
function esc_attr__($s,$d=null){ return $s; }
function _n($a,$b,$n,$d=null){ return $n==1?$a:$b; }
function add_media_page(){ return 'media_page_x'; }
function add_options_page(){ return 'settings_page_x'; }
function add_meta_box(){}
function wp_create_nonce($a){ return 'nonce'; }
function trailingslashit($s){ return rtrim($s,'/').'/'; }
function wp_basename($p){ return basename($p); }
function current_user_can(){ return true; }
function plugin_basename($f){ return 'ai-image-optimizer-alt/'.basename($f); }
require '/home/user/ai-image-optimizer-alt/ai-image-optimizer-alt.php';
echo "BOOTSTRAP OK\n";
foreach (['AIIOA_Plugin','AIIOA_Article','AIIOA_OpenRouter','AIIOA_Optimizer','AIIOA_Admin','AIIOA_Article_Admin'] as $c)
  printf("  %-22s %s\n", $c, class_exists($c) ? 'carregada' : '*** FALTANDO ***');
$s = AIIOA_Plugin::settings();
echo "settings(): ".count($s)." chaves | modelo=".$s['model']." | idioma=".$s['language']."\n";
echo "hooks registrados: filter=".count($GLOBALS['__hooks']['filter'] ?? [])." action=".count($GLOBALS['__hooks']['action'] ?? [])."\n";
