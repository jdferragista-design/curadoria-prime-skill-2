<?php
/**
 * Testes do relatório de falhas: os incidentes precisam ser detectados,
 * classificados e persistidos — e a pré-visualização não pode poluir o log.
 */
define( 'ABSPATH', '/fake/wp/' );

function esc_url( $u ) { return $u; }
function esc_attr( $s ) { return htmlspecialchars( $s, ENT_QUOTES ); }
function esc_html( $s ) { return htmlspecialchars( $s, ENT_QUOTES ); }
function home_url( $p = '' ) { return 'https://curadoriaprime.com' . $p; }
function current_user_can( $c ) { return true; }
function wp_parse_args( $a, $d ) { return array_merge( $d, (array) $a ); }
function wp_json_encode( $d, $f = 0 ) { return json_encode( $d, $f ); }
function __( $s, $d = null ) { return $s; }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u ); }
function current_time( $t ) { return date( 'Y-m-d H:i:s' ); }
function get_current_user_id() { return 1; }

// options em memória
$GLOBALS['__opt'] = array();
function get_option( $k, $d = array() ) { return array_key_exists( $k, $GLOBALS['__opt'] ) ? $GLOBALS['__opt'][ $k ] : $d; }
function update_option( $k, $v, $a = null ) { $GLOBALS['__opt'][ $k ] = $v; return true; }
function delete_option( $k ) { unset( $GLOBALS['__opt'][ $k ] ); return true; }

foreach ( array( 'log', 'plugin', 'rules', 'fixer', 'diff' ) as $c ) {
	require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";
}

$falhas = 0;
function ok( $c, $m ) { global $falhas; if ( $c ) { echo "  ✅ $m\n"; } else { echo "  ❌ $m\n"; $falhas++; } }
function tem_inc( $tipo ) {
	foreach ( CPC_Fixer::incidentes() as $i ) { if ( $i['tipo'] === $tipo ) return $i; }
	return null;
}

// ══════════ 1. Imagem sem URL para restaurar ══════════
echo "\n[1] Imagem em placeholder sem data-src\n";
$html = '<img src="data:image/svg+xml;base64,AAAA" alt="TV"><p>Texto qualquer aqui para dar corpo.</p>';
CPC_Fixer::aplicar( $html, array( 'img_lazy' ) );
$i = tem_inc( 'img_sem_url' );
ok( $i, 'registra img_sem_url' );
ok( $i && false !== strpos( $i['detalhe'], 'sem data-src' ), 'detalhe explica a causa' );
ok( CPC_Log::gravidade( 'img_sem_url' ) === 'media', 'gravidade média (não bloqueia nada)' );

echo "\n[1b] data-src que também é placeholder\n";
$html2 = '<img src="data:image/gif;base64,R0lGOD" data-src="data:image/gif;base64,R0lGOD" alt="x">';
CPC_Fixer::aplicar( $html2, array( 'img_lazy' ) );
ok( tem_inc( 'img_sem_url' ), 'registra quando o data-src também é base64' );

// ══════════ 2. Schema ilegível ══════════
echo "\n[2] Schema que não faz parse\n";
$aspa = '<script type="application/ld+json">{"@type":"Product","name":"TV 50" LG","author":{"@type":"Person","name":"Fulano"}}</script>';
CPC_Fixer::aplicar( $aspa, array( 'schema_agg', 'schema_autor' ) );
$i = tem_inc( 'schema_ilegivel' );
ok( $i, 'registra schema_ilegivel' );
ok( $i && false !== strpos( $i['detalhe'], 'aspa reta' ), 'aponta a aspa reta de polegadas' );
ok( CPC_Log::gravidade( 'schema_ilegivel' ) === 'alta', 'gravidade alta' );

// o bloco quebrado tem de sair intacto
list( $saida, $log ) = CPC_Fixer::aplicar( $aspa, array( 'schema_agg', 'schema_autor' ) );
ok( $saida === $aspa, 'bloco ilegível sai intacto (não tenta consertar por regex)' );

// ══════════ 3. Divulgação sem âncora ══════════
echo "\n[3] Post sem link de afiliado\n";
CPC_Fixer::aplicar( '<p>Artigo institucional sem nenhum link comercial.</p>', array( 'divulgacao' ) );
ok( tem_inc( 'divulgacao_sem_ancora' ), 'registra divulgacao_sem_ancora' );
ok( CPC_Log::gravidade( 'divulgacao_sem_ancora' ) === 'baixa', 'gravidade baixa (é esperado)' );

// ══════════ 4. Regra sem efeito ══════════
echo "\n[4] Regra pedida que não acha nada\n";
CPC_Fixer::aplicar( '<p>Texto limpo.</p>', array( 'sponsored' ) );
ok( tem_inc( 'regra_sem_efeito' ), 'registra regra_sem_efeito' );

// ══════════ 5. Correção bem-sucedida não gera incidente ══════════
echo "\n[5] Correção que funciona não polui o relatório\n";
$bom = '<p><a href="https://amzn.to/4biQQdq">Ver</a></p><img data-src="https://x.com/a.jpg" src="data:image/gif;base64,R0lGOD">';
CPC_Fixer::aplicar( $bom, array( 'sponsored', 'img_lazy' ) );
ok( ! tem_inc( 'img_sem_url' ), 'imagem restaurada não vira incidente' );
ok( ! tem_inc( 'regra_sem_efeito' ), 'regra que funcionou não vira incidente' );

// ══════════ 6. Reset entre execuções ══════════
echo "\n[6] Incidentes resetam a cada aplicar()\n";
CPC_Fixer::aplicar( '<img src="data:image/gif;base64,R0lGOD">', array( 'img_lazy' ) );
$n1 = count( CPC_Fixer::incidentes() );
CPC_Fixer::aplicar( '<img src="data:image/gif;base64,R0lGOD">', array( 'img_lazy' ) );
$n2 = count( CPC_Fixer::incidentes() );
ok( $n1 === $n2, "não acumula entre chamadas ($n1 → $n2)" );

// ══════════ 7. Persistência ══════════
echo "\n[7] CPC_Log persiste, agrupa e limita\n";
CPC_Log::limpar();
CPC_Log::registrar( 'trava_seguranca', 3181, 'perderia 2 imagem(ns)', 'img_lazy' );
CPC_Log::registrar( 'trava_seguranca', 4541, 'perderia 1 link(s)', 'sponsored' );
CPC_Log::registrar( 'schema_ilegivel', 3181, 'aspa reta', 'schema' );
ok( count( CPC_Log::tudo() ) === 3, 'grava os 3 incidentes' );

$g = CPC_Log::por_tipo();
ok( isset( $g['trava_seguranca'] ) && $g['trava_seguranca']['n'] === 2, 'agrupa por tipo' );
ok( count( $g['trava_seguranca']['posts'] ) === 2, 'lista os posts afetados' );
ok( array_key_first( $g ) === 'trava_seguranca', 'ordena pelo mais frequente' );

$tudo = CPC_Log::tudo();
ok( $tudo[0]['tipo'] === 'schema_ilegivel', 'mais recente primeiro' );
ok( isset( $tudo[0]['em'], $tudo[0]['post_id'], $tudo[0]['regra'] ), 'guarda quando/post/regra' );

echo "\n[7b] Teto de tamanho\n";
CPC_Log::limpar();
for ( $k = 0; $k < 320; $k++ ) { CPC_Log::registrar( 'regra_sem_efeito', $k, "item $k" ); }
ok( count( CPC_Log::tudo() ) === CPC_Log::LIMITE, 'trunca em ' . CPC_Log::LIMITE . ' (não estoura o wp_options)' );
ok( CPC_Log::tudo()[0]['detalhe'] === 'item 319', 'mantém os mais recentes' );

echo "\n[7c] Detalhe longo é truncado\n";
CPC_Log::limpar();
CPC_Log::registrar( 'erro_gravacao', 1, str_repeat( 'x', 2000 ) );
ok( mb_strlen( CPC_Log::tudo()[0]['detalhe'] ) === 500, 'detalhe limitado a 500 chars' );

// ══════════ 8. Todo tipo tem orientação ══════════
echo "\n[8] Catálogo de tipos\n";
$sem_texto = array();
foreach ( CPC_Log::tipos() as $t => $d ) {
	if ( empty( $d['rotulo'] ) || empty( $d['o_que_e'] ) || empty( $d['o_que_faz'] ) || empty( $d['gravidade'] ) ) {
		$sem_texto[] = $t;
	}
}
ok( ! $sem_texto, 'todos os ' . count( CPC_Log::tipos() ) . ' tipos têm rótulo, diagnóstico, ação e gravidade' );

// tipos emitidos pelo código existem no catálogo
$emitidos = array();
$src = file_get_contents( '/home/user/curadoria-conformidade/includes/class-cpc-fixer.php' )
	. file_get_contents( '/home/user/curadoria-conformidade/includes/class-cpc-admin.php' )
	. file_get_contents( '/home/user/curadoria-conformidade/includes/class-cpc-scanner.php' );
preg_match_all( "/(?:incidente|CPC_Log::registrar)\(\s*'([a-z_]+)'/", $src, $m );
$desconhecidos = array_diff( array_unique( $m[1] ), array_keys( CPC_Log::tipos() ) );
ok( ! $desconhecidos, 'todo tipo emitido está catalogado' . ( $desconhecidos ? ': ' . implode( ',', $desconhecidos ) : '' ) );

// ══════════ 9. CSV ══════════
echo "\n[9] CSV\n";
CPC_Log::limpar();
CPC_Log::registrar( 'trava_seguranca', 3181, 'perderia 2 imagens; texto "encolheria" 30%', 'img_lazy' );
$csv = CPC_Log::csv();
ok( substr( $csv, 0, 3 ) === "\xEF\xBB\xBF", 'BOM UTF-8 (abre certo no Excel)' );
ok( false !== strpos( $csv, 'quando,tipo,gravidade,post_id,regra,detalhe' ), 'cabeçalho correto' );
ok( false !== strpos( $csv, '""encolheria""' ), 'aspas do detalhe escapadas' );
ok( substr_count( trim( $csv ), "\n" ) === 1, 'uma linha por incidente' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
echo $falhas ? "❌ $falhas FALHA(S)\n" : "✅ TODOS OS TESTES PASSARAM\n";
exit( $falhas ? 1 : 0 );
