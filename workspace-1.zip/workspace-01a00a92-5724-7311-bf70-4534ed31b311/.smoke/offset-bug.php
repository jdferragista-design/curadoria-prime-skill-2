<?php
// Reproduz contexto() exatamente como está no plugin
function contexto_atual( $txt, $ini, $fim, $margem = 90 ) {
    $a = max( 0, $ini - $margem );
    $s = mb_substr( $txt, $a, ( $fim - $a ) + $margem, 'UTF-8' );
    return trim( preg_replace( '/\s+/u', ' ', $s ) );
}
function contexto_corrigido( $txt, $ini_bytes, $fim_bytes, $margem = 90 ) {
    $ini = mb_strlen( substr( $txt, 0, $ini_bytes ), 'UTF-8' );
    $fim = mb_strlen( substr( $txt, 0, $fim_bytes ), 'UTF-8' );
    $a = max( 0, $ini - $margem );
    $s = mb_substr( $txt, $a, ( $fim - $a ) + $margem, 'UTF-8' );
    return trim( preg_replace( '/\s+/u', ' ', $s ) );
}

$txt = 'Testamos o QCY T13 ANC em uso diário por mais de duas semanas: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. Veja o que encontramos. 1. Unboxing e Primeiras Impressões A caixa do QCY T13 ANC é funcional e sem excessos — papelão reciclado com janela plástica.';

preg_match_all('/\bTestamos\b/u', $txt, $mm, PREG_OFFSET_CAPTURE);
foreach ($mm[0] as $hit) {
    echo "trecho......: {$hit[0]}\n";
    echo "offset bytes: {$hit[1]}\n";
    echo "ATUAL.......: " . contexto_atual($txt, $hit[1], $hit[1]+strlen($hit[0])) . "\n";
    echo "CORRIGIDO...: " . contexto_corrigido($txt, $hit[1], $hit[1]+strlen($hit[0])) . "\n";
}
echo "\n--- bytes vs chars ---\n";
echo "strlen (bytes): " . strlen($txt) . "\n";
echo "mb_strlen (ch): " . mb_strlen($txt,'UTF-8') . "\n";
