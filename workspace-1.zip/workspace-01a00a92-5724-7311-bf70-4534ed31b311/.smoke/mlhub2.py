from playwright.sync_api import sync_playwright
import re
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
URLS=["https://www.mercadolivre.com.br/noindex/catalog/reviews/MLB58587883?objectId=MLB58587883&siteId=MLB&isItem=false&noIndex=true",
      "https://www.mercadolivre.com.br/noindex/catalog/reviews/MLB4615627273?objectId=MLB4615627273&siteId=MLB&isItem=true&noIndex=true"]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":900},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    for u in URLS:
        pg=ctx.new_page()
        pg.goto(u,timeout=60000,wait_until="networkidle"); pg.wait_for_timeout(4500)
        t=pg.inner_text("body")
        print("\n=====",u.split('/')[-1][:60])
        print(t[:600].replace("\n"," | ")[:600])
        m=re.search(r'(\d[,\.]\d)\s',t); print(">> nota:",m.group(1) if m else None)
        m=re.search(r'([\d\.]+)\s*(?:opini|avalia|comentári)',t,re.I); print(">> total:",m.group(0) if m else None)
        pg.close()
    b.close()
