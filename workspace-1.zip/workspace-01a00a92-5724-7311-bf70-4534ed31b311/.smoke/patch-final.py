# -*- coding: utf-8 -*-
import re, sys
b = open('.smoke/3523-src.html', encoding='utf-8').read()
orig = b
P = []   # (etiqueta, original, novo)

# ---------- 1. BLOCO DE METODOLOGIA (o mais grave) ----------
P.append(("metodologia",
'<strong>📋 Metodologia:</strong> Este review é baseado em <strong>teste real de 2 semanas</strong> — uso diário em home office, transporte público, academia e chamadas. Especificações confirmadas no <a href="https://www.qcybrasil.com/produtos/qcy-t13-anc/" rel="noopener nofollow" target="_blank">site oficial QCY Brasil</a>. <strong>🔍 Tipo de análise:</strong> teste prático do autor + dados de compradores verificados na Amazon e Mercado Livre.',
'<strong>📋 Metodologia:</strong> Esta é uma <strong>análise documental comparativa</strong> — não tivemos o produto em mãos. Ela cruza a ficha técnica oficial, verificada no <a href="https://www.qcybrasil.com/produtos/qcy-t13-anc/" rel="noopener nofollow" target="_blank">site oficial QCY Brasil</a>, a comparação ponto a ponto com os concorrentes diretos da faixa e a leitura sistemática de avaliações verificadas de compradores na Amazon e no Mercado Livre. <strong>🔍 O que isto não é:</strong> não há medição de dB, de autonomia ou de latência feita por nós. Onde o texto traz número, ele vem do fabricante ou dos relatos — e está identificado como tal.'))

# ---------- 2. INTRODUÇÃO ----------
P.append(("intro",
'Essa é exatamente a pergunta certa — e é ela que este review responde com testes reais, não só especificações copiadas da caixa.',
'Essa é exatamente a pergunta certa — e é ela que este review responde cruzando a ficha técnica oficial, a comparação com os rivais diretos e o que dizem os compradores verificados, dizendo em cada ponto de onde vem a informação.'))

# ---------- 3. A FRASE-ÂNCORA DO "TESTAMOS" ----------
P.append(("ancora-testamos",
'<p>Testamos o fone em uso diário por mais de duas semanas: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. Veja o que encontramos.</p>',
'<p>Nossa análise parte da ficha técnica oficial da QCY, da comparação ponto a ponto com os concorrentes diretos da faixa e da leitura sistemática de avaliações verificadas de compradores brasileiros — com atenção aos cenários que mais aparecem nos relatos: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. O que a documentação e os relatos sustentam está abaixo. <strong>O que depende de ter o produto no ouvido — conforto após horas, encaixe na sua orelha, microfone em rua movimentada — nós não verificamos, e dizemos isso onde importa.</strong></p>'))

# ---------- 4. UNBOXING: título e corpo ----------
P.append(("h2-unboxing",
'>1. Unboxing e Primeiras Impressões</h2>',
'>1. O Que Vem na Caixa</h2>'))
P.append(("indice-unboxing",
'>Unboxing</a>',
'>O que vem na caixa</a>'))
P.append(("unboxing-abertura",
'<p>A caixa do QCY T13 ANC é funcional e sem excessos — papelão reciclado com janela plástica que mostra o estojo. É a embalagem de quem investe o dinheiro no produto, não na apresentação. Dentro dela:</p>',
'<p>Como não abrimos uma unidade, o conteúdo abaixo vem do material oficial da QCY e das fotos publicadas por compradores nas avaliações da Amazon e do Mercado Livre. A embalagem é funcional e sem excessos — papelão reciclado com janela plástica que mostra o estojo. Segundo o fabricante, a caixa traz:</p>'))
P.append(("unboxing-primeira-impressao",
'<p>A primeira impressão ao tirar o estojo da caixa é positiva: o plástico tem acabamento fosco que não acumula digitais facilmente, a dobradiça da tampa é firme e o clique magnético ao fechar tem uma resposta satisfatória. O tamanho é realmente compacto — na horizontal, o estojo cabe na palma da mão e não faz volume no bolso da calça.</p>',
'<p>Nas avaliações com foto, o acabamento fosco do plástico aparece descrito como resistente a marcas de dedo, e a firmeza da dobradiça e o clique magnético da tampa são elogios recorrentes. O tamanho compacto é confirmado pelas dimensões oficiais do estojo — cabe na palma da mão e é citado nos relatos como discreto no bolso.</p>'))
P.append(("unboxing-ponteira-M",
'Ao encaixar pela primeira vez, a ponteira M (média, já instalada) serviu bem para a maioria do time de teste — o encaixe passivo antes de qualquer ANC já é razoável.',
'A ponteira M já vem instalada de fábrica e, pelos relatos, serve à maioria dos usuários — o isolamento passivo, antes de qualquer ANC, é descrito como razoável.'))

# ---------- 5. DESIGN / CONFORTO ----------
P.append(("design-3horas",
'A leveza é o principal aliado do conforto em sessões longas: usamos o fone por até 3 horas seguidas sem sentir aquela pressão acumulada no canal auditivo que é comum em earbuds mais pesados.',
'A leveza é o principal aliado do conforto em sessões longas: os relatos de uso prolongado (duas a três horas seguidas) mencionam pouca pressão acumulada no canal auditivo, o que é coerente com o peso declarado. <strong>Conforto, porém, depende da anatomia de cada orelha — e isso nenhuma análise documental resolve por você.</strong>'))
P.append(("design-encaixe",
'Para uso cotidiano — transporte, escritório, academia leve —, o encaixe se manteve firme em todos os nossos testes.',
'Para uso cotidiano — transporte, escritório, academia leve —, os relatos de compradores descrevem encaixe firme na maioria dos casos.'))

# ---------- 6. TABELA DE SOM ----------
P.append(("tabela-som",
'>O que ouvimos</th>',
'>O que os relatos e a ficha técnica indicam</th>'))

# ---------- 7. ANC: título ----------
P.append(("h2-anc",
'>4. ANC de 28dB: Funciona de Verdade? (Testamos em 3 Ambientes)</h2>',
'>4. ANC de 28dB: Funciona de Verdade? (O Que Esperar em 3 Ambientes)</h2>'))
P.append(("indice-anc",
'>ANC 28dB</a>',
'>ANC 28dB</a>'))
P.append(("anc-intro",
'Entendendo essa limitação técnica, os testes fazem mais sentido:</p>',
'Entendendo essa limitação técnica, dá para projetar com honestidade o comportamento em cada ambiente — é isso que fazemos abaixo, combinando a arquitetura do ANC com o que os compradores relatam:</p>'))

# ---------- 8. ANC ambiente 1 ----------
P.append(("anc-amb1",
'O ruído de fundo do motor diesel — aquele zumbido grave e contínuo de ~80–90Hz — foi reduzido de forma muito perceptível com o ANC ligado. No nosso teste, conseguimos ouvir música em volume 35–40% sem perder detalhes da faixa, enquanto sem ANC o volume mínimo confortável subia para 55–60% para cobrir o mesmo ruído.',
'O zumbido grave e contínuo do motor diesel (~80–90Hz) está exatamente na faixa que o ANC feedforward trata melhor, e é o cenário mais citado nas avaliações brasileiras: os relatos descrevem conseguir ouvir música em volume sensivelmente mais baixo com o ANC ligado do que sem ele. Não há, que tenhamos localizado, medição independente em dB para esse caso — o número de 28dB é declarado pela QCY.'))
P.append(("anc-amb1-fim",
'Não é isolamento de avião, mas para o trajeto diário de ônibus o ganho de concentração é real e mensurável. <strong>Resultado: bom — superou expectativas para o preço.</strong>',
'Não é isolamento de fone premium, mas para o trajeto diário de ônibus os relatos convergem em ganho perceptível de concentração. <strong>Expectativa realista: bom para a faixa de preço.</strong>'))

# ---------- 9. ANC ambiente 2 ----------
P.append(("anc-amb2",
'Este foi o cenário em que o ANC do T13 mais impressionou. O ruído contínuo e uniforme do ar-condicionado central (~55–65Hz predominante) é exatamente o tipo de frequência que o ANC feedforward cancela com maior eficiência. Com o ANC ligado, o ruído do ar praticamente desapareceu — a diferença foi imediata e marcante.',
'Este é o cenário em que essa arquitetura tende a ir melhor. O ruído contínuo e uniforme do ar-condicionado central (~55–65Hz predominante) é o tipo de frequência que o ANC feedforward cancela com maior eficiência, e é onde as avaliações mais usam a palavra "silêncio" para descrever o efeito.'))
P.append(("anc-amb2-edifier",
'Testamos lado a lado com o <a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/edifier-w820nb-review/" rel="noopener">Edifier W820NB</a> (ANC de 38dB) no mesmo ambiente: o W820NB cancelou mais ~20–30% do resíduo de ruído que o T13 ANC deixou passar. Para home office com AC, o T13 ANC é excelente — o W820NB é melhor, mas custa o dobro e é over-ear. <strong>Resultado: excepcional — melhor cenário do produto.</strong>',
'Na comparação entre as fichas técnicas, o <a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/edifier-w820nb-review/" rel="noopener">Edifier W820NB</a> declara 38dB contra os 28dB do T13 ANC — cerca de 10dB a mais no papel, o que na prática significa mais resíduo de ruído eliminado. Não fizemos a comparação lado a lado, e vale o alerta: números de ANC declarados por fabricantes não seguem um padrão único de medição, então servem como indicativo, não como placar exato. O W820NB custa cerca do dobro e é over-ear — outra categoria de produto. <strong>Expectativa realista: é o melhor cenário para o T13 ANC.</strong>'))

# ---------- 10. ANC ambiente 3 ----------
P.append(("anc-amb3",
'Aqui o ANC mostrou sua limitação mais característica: o microfone feedforward capta o vento diretamente antes de processar o cancelamento, e isso gera um leve chiado de processamento audível — como um farfalhar interno.',
'Aqui aparece a limitação mais característica dessa arquitetura, e ela é previsível pelo projeto: o microfone feedforward capta o vento diretamente antes de processar o cancelamento, o que gera um chiado audível — como um farfalhar interno. É também a queixa que mais se repete nas avaliações negativas de uso ao ar livre.'))
P.append(("anc-amb3-fim",
'<strong>Resultado: limitado com vento, requer mudança de modo.</strong>',
'<strong>Expectativa realista: limitado com vento, exige trocar de modo.</strong>'))

# ---------- 11. ANC conclusão ----------
P.append(("anc-conclusao",
'O ANC do T13 supera qualquer earbud na mesma faixa de preço que testamos — e a maioria dos que custam até R$ 280.',
'Entre os TWS que declaram ANC até cerca de R$ 250, os 28dB do T13 ANC estão entre os números mais altos anunciados — lembrando que essa é uma comparação de especificações declaradas, não de medições nossas.'))

# ---------- 12. BATERIA ----------
P.append(("h2-bateria",
'>6. Bateria: Testamos na Prática</h2>',
'>6. Bateria: O Que os Números Oficiais Mostram</h2>'))
P.append(("bateria-confirmamos",
'Os números são honestos: confirmamos as especificações nos testes com volume a 60%.',
'Não medimos a autonomia. Os números abaixo são os declarados pela QCY, e os relatos de compradores em geral os sustentam para volume moderado — com a ressalva de que autonomia varia com volume, codec e temperatura.'))
P.append(("bateria-tabela-titulo",
'Autonomia real medida (volume 60%)</h4>',
'Autonomia declarada pelo fabricante (volume moderado)</h4>'))

# ---------- 13. RODAPÉ: unidade adquirida ----------
P.append(("rodape-unidade",
'<strong>Produto analisado:</strong> QCY T13 ANC Preto (unidade adquirida pelo autor)',
'<strong>Base da análise:</strong> ficha técnica oficial da QCY, avaliações verificadas de compradores (Amazon e Mercado Livre) e comparação com concorrentes diretos. Não recebemos unidade do fabricante nem adquirimos uma para teste.'))

# ---------- 14. PREÇOS: datar ----------
P.append(("hero-preco",
'>💰 R$ 169-186</span>',
'>💰 R$ 169–186 (ago/2026)</span>'))
P.append(("hero-estrelas",
'>⭐ 4,8★ (6.546 ML) · 4,6★ (751 AMZ)</span>',
'>⭐ 4,8★ (6.546 ML) · 4,6★ (751 AMZ) — ago/2026</span>'))
P.append(("onde-comprar",
'🛒 Onde Comprar: Melhores Preços de Hoje',
'🛒 Onde Comprar — preços apurados em 15/08/2026'))


# ---------- correcoes do PASSO 2 que estavam soltas ----------
P.append(("comparativo-preco",
'<strong>QCY T13 ANC a R$ 169-186</strong> ou <strong><a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/samsung-galaxy-buds-core-vale-a-pena/" rel="noopener">Samsung Galaxy Buds Core</a> a R$ 229\u2013380</strong>?',
'<strong>QCY T13 ANC (R$ 169\u2013186)</strong> ou <strong><a style="color: #667eea; font-weight: 600;" href="https://curadoriaprime.com/samsung-galaxy-buds-core-vale-a-pena/" rel="noopener">Samsung Galaxy Buds Core</a> (R$ 229\u2013380)</strong>? Faixas apuradas em agosto de 2026.'))
P.append(("tabela-preco-linha", 'Pre\u00e7o (agosto 2026)', 'Pre\u00e7o (faixa apurada em 15/08/2026)'))
P.append(("cta-precos",
'Pre\u00e7os de agosto 2026 \u2014 confira o prazo de entrega com seu CEP.',
'Faixas de pre\u00e7o apuradas em 15/08/2026 \u2014 confira o valor atual e o prazo de entrega com seu CEP antes de comprar.'))

# ---------- JSON-LD, que vive DENTRO do post_content ----------
P.append(("schema-description",
'"description": "QCY T13 ANC Review 2026: ANC real de 28dB por R$ 169-186. Testamos som, bateria, chamadas e cancelamento de ru\u00eddo em 3 ambientes. Veja se vale a pena."',
'"description": "QCY T13 ANC Review 2026: ANC real de 28dB por R$ 169-186. Analisamos som, bateria, chamadas e cancelamento de ru\u00eddo com base na ficha t\u00e9cnica oficial e em avalia\u00e7\u00f5es verificadas de compradores."'))
P.append(("schema-pricevaliduntil", '"priceValidUntil": "2026-08-31"', '"priceValidUntil": "2026-12-31"'))

out = b
falhou = []
for tag, o, n in P:
    c = out.count(o)
    if c == 1:
        out = out.replace(o, n)
    else:
        falhou.append((tag, c))

open('.smoke/3523-final.html','w',encoding='utf-8').write(out)
print("aplicados:", len(P)-len(falhou), "/", len(P))
if falhou:
    print("NAO APLICADOS:")
    for t,c in falhou: print("   ",t,"ocorrencias=",c)
print()
print("links  antes/depois:", orig.count('<a '), out.count('<a '))
print("imgs   antes/depois:", orig.count('<img'), out.count('<img'))
print("h2     antes/depois:", orig.count('<h2'), out.count('<h2'))
print("bytes  antes/depois:", len(orig), len(out))
