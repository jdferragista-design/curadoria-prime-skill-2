<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;}
function _n($a,$b,$n,$d=null){return $n==1?$a:$b;} function sprintf_wp(){}
function wp_parse_url($u,$c=-1){return parse_url($u);}
function wp_kses_post($s){return $s;}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$html=file_get_contents('/home/user/qcy3523.html');
$achados=CPC_Rules::analisar($html);

echo "=== 1. os maiores trechos editaveis ===\n";
$todos=array();
foreach($achados as $a){
  if(!empty($a['auto'])) continue;
  foreach($a['ocorrencias'] as $o) $todos[]=array($a['regra'],mb_strlen($o['trecho']),$o['trecho']);
}
usort($todos,function($x,$y){return $y[1]-$x[1];});
printf("  total de campos editaveis: %d\n",count($todos));
foreach(array_slice($todos,0,5) as $t){
  printf("  %-18s %5d chars | <img> %d | <a> %d\n",$t[0],$t[1],substr_count($t[2],'<img'),substr_count($t[2],'<a '));
}

echo "\n=== 2. a frase duplicada ===\n";
$f='A diferença de preço é de apenas R$ 30';
echo "  no HTML publicado: ".substr_count($html,$f)." ocorrencias\n";
foreach($todos as $t){
  if(mb_strpos($t[2],'A diferença de preço é de apenas')!==false){
    printf("  campo da regra '%s', %d chars\n",$t[0],$t[1]);
    echo "  trecho: ".mb_substr(preg_replace('/\s+/',' ',$t[2]),0,200)."\n";
  }
}

echo "\n=== 3. quantos trechos sao repetidos no corpo ===\n";
$rep=0;
foreach($todos as $t){
  $n=substr_count($html,$t[2]);
  if($n>1){ $rep++; printf("  %dx | %-16s | %s…\n",$n,$t[0],mb_substr(preg_replace('/\s+/',' ',$t[2]),0,70)); }
}
echo "  campos com trecho repetido: $rep\n";
