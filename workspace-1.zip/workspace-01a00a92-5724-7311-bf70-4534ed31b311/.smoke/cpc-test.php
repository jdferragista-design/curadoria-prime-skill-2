<?php
/**
 * Harness de teste: stubs mínimos do WP + casos reais extraídos dos artigos
 * da Curadoria Prime. Roda fora do WordPress.
 */
define( 'ABSPATH', '/fake/wp/' );
define( 'WPINC', 'wp-includes' );

function esc_url( $u ) { return $u; }
function esc_attr( $s ) { return htmlspecialchars( $s, ENT_QUOTES ); }
function esc_html( $s ) { return htmlspecialchars( $s, ENT_QUOTES ); }
function home_url( $p = '' ) { return 'https://curadoriaprime.com' . $p; }
function current_user_can( $c ) { return true; }
function get_option( $k, $d = array() ) { return $d; }
function wp_parse_args( $a, $d ) { return array_merge( $d, (array) $a ); }
function wp_json_encode( $d, $f = 0 ) { return json_encode( $d, $f ); }
function __( $s, $d = null ) { return $s; }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u ); }

require '/home/user/curadoria-conformidade/includes/class-cpc-plugin.php';
require '/home/user/curadoria-conformidade/includes/class-cpc-rules.php';
require '/home/user/curadoria-conformidade/includes/class-cpc-fixer.php';
require '/home/user/curadoria-conformidade/includes/class-cpc-diff.php';

$falhas = 0;
function ok( $cond, $msg ) {
	global $falhas;
	if ( $cond ) { echo "  ✅ $msg\n"; } else { echo "  ❌ $msg\n"; $falhas++; }
}
function achado( $achados, $regra ) {
	foreach ( $achados as $a ) { if ( $a['regra'] === $regra ) return $a; }
	return null;
}

// Após a v1.2.1 o campo editável é a FRASE, não o token. Duas detecções na
// mesma frase viram UM campo com dois tokens — contar ocorrências passou a
// medir frases. O contrato que importa é: nenhum token detectado se perdeu.
function tokens( $achados, $regra ) {
	$a = achado( $achados, $regra );
	if ( ! $a ) { return array(); }
	$t = array();
	foreach ( $a['ocorrencias'] as $o ) {
		foreach ( ( isset( $o['tokens'] ) ? $o['tokens'] : array() ) as $x ) { $t[] = mb_strtolower( $x, 'UTF-8' ); }
	}
	return $t;
}

// ══════════════ 1. DETECÇÃO ══════════════
echo "\n[1] Detectores\n";

$html = <<<'H'
<p>Nós testamos o LG AU801 durante 30 dias e medimos o brilho real.</p>
<p>Preço verificado há 2 horas: R$ 1.973. Estoque limitado, últimas unidades!</p>
<p><a href="https://mercadolivre.com/sec/2eZsRku">Ver no Mercado Livre</a></p>
<p><a href="https://shopee.com.br/produto-123">Ver na Shopee</a></p>
<img data-lazyloaded="1" src="data:image/svg+xml;base64,AAAA" data-src="https://curadoriaprime.com/wp-content/uploads/tv.jpg" alt="TV LG">
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Product","name":"LG AU801",
"aggregateRating":{"@type":"AggregateRating","ratingValue":"4.6","reviewCount":"815"},
"author":{"@type":"Person","name":"Equipe Curadoria Prime"}}
</script>
H;

$a = CPC_Rules::analisar( $html );
$regras = array_column( $a, 'regra' );
echo "  regras disparadas: " . implode( ', ', $regras ) . "\n";

ok( achado( $a, 'alegacao_teste' ), 'pega alegação de teste' );
$tk = tokens( $a, 'alegacao_teste' );
ok( in_array( 'testamos', $tk, true ) && in_array( 'medimos', $tk, true ), 'pega "testamos" E "medimos" (tokens: ' . implode( ', ', $tk ) . ')' );
ok( achado( $a, 'urgencia_falsa' ), 'pega urgência falsa' );
$tu = tokens( $a, 'urgencia_falsa' );
ok( count( $tu ) >= 3, 'pega as 3 urgências (tokens: ' . implode( ' | ', $tu ) . ')' );
ok( achado( $a, 'schema_agg' ), 'pega aggregateRating' );
ok( achado( $a, 'schema_autor' ), 'pega autor divergente' );
ok( achado( $a, 'sponsored' ), 'pega link sem sponsored' );
ok( achado( $a, 'sponsored' )['n'] === 2, 'pega ML e Shopee (' . achado( $a, 'sponsored' )['n'] . ')' );
ok( achado( $a, 'img_lazy' ), 'pega imagem com placeholder' );
ok( achado( $a, 'divulgacao' ), 'pega falta de divulgação' );
ok( achado( $a, 'preco_sem_data' ), 'pega preço sem data' );

// ══════════════ 2. FALSOS POSITIVOS ══════════════
echo "\n[2] Falsos positivos (o que NÃO pode disparar)\n";

$limpo = <<<'H'
<p>Não testamos este produto fisicamente. Nossa análise é documental.</p>
<p>Preço de R$ 1.973 verificado em 13/08/2026 no Mercado Livre.</p>
<p>Este artigo contém links de afiliado e podemos receber uma comissão.</p>
<p><a href="https://mercadolivre.com/sec/2eZsRku" rel="sponsored noopener noreferrer nofollow">Ver oferta</a></p>
<img src="https://curadoriaprime.com/wp-content/uploads/tv.jpg" alt="TV LG">
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Review","reviewRating":{"@type":"Rating","ratingValue":"8.4","bestRating":"10"},
"author":{"@type":"Person","name":"Cristiano Martins"}}
</script>
H;

$b = CPC_Rules::analisar( $limpo );
echo "  regras disparadas: " . ( $b ? implode( ', ', array_column( $b, 'regra' ) ) : '(nenhuma)' ) . "\n";
ok( ! achado( $b, 'alegacao_teste' ), '"não testamos" NÃO é alegação' );
ok( ! achado( $b, 'preco_sem_data' ), 'preço com data não dispara' );
ok( ! achado( $b, 'sponsored' ), 'link já com sponsored não dispara' );
ok( ! achado( $b, 'divulgacao' ), 'divulgação presente não dispara' );
ok( ! achado( $b, 'img_lazy' ), 'imagem normal não dispara' );
ok( ! achado( $b, 'schema_agg' ), 'review /10 do editor é preservado' );
ok( ! achado( $b, 'schema_autor' ), 'autor canônico não dispara' );
ok( empty( $b ), 'artigo conforme: ZERO achados' );

// ══════════════ 2b. HOME DE LOJA NO BLOCO "FONTES" ══════════════
echo "\n[2b] Link para home da loja (bloco Fontes) não é afiliado\n";
$fontes = '<p>Fontes: <a href="https://www.amazon.com.br/" rel="nofollow noopener">Amazon</a> e '
	. '<a href="https://www.mercadolivre.com.br/" rel="nofollow noopener">Mercado Livre</a>, consultados em 13/08/2026.</p>';
$f = CPC_Rules::analisar( $fontes );
ok( ! achado( $f, 'sponsored' ), 'home da loja NÃO exige sponsored' );
ok( ! achado( $f, 'divulgacao' ), 'home da loja não exige bloco de divulgação' );

$deep = '<p><a href="https://www.amazon.com.br/dp/B0C123">Ver produto</a></p>';
ok( achado( CPC_Rules::analisar( $deep ), 'sponsored' ), 'link de produto na mesma loja AINDA exige sponsored' );
$comq = '<p><a href="https://www.amazon.com.br/?tag=curadoria-20">Ver</a></p>';
ok( achado( CPC_Rules::analisar( $comq ), 'sponsored' ), 'home COM ?tag= de afiliado exige sponsored' );

// ══════════════ 3. wpautop no schema ══════════════
echo "\n[3] Schema com <br /> do wpautop\n";
$quebrado = '<script type="application/ld+json">{<br />"@type":"Product",<br />"author":{"@type":"Person","name":"Cristiano Martins"}}</script>';
$c = CPC_Rules::analisar( $quebrado );
ok( ! achado( $c, 'schema_malformado' ), '<br /> é limpo antes do parse (não reporta falso quebrado)' );

echo "\n[3b] Aspa reta de polegadas\n";
$aspa = '<script type="application/ld+json">{"@type":"Product","name":"TV 50" LG"}</script>';
$d = CPC_Rules::analisar( $aspa );
$m = achado( $d, 'schema_malformado' );
ok( $m, 'detecta JSON quebrado' );
ok( $m && false !== strpos( $m['ocorrencias'][0]['contexto'], 'aspa reta' ), 'diagnostica a causa (aspa reta)' );

// ══════════════ 4. CORREÇÃO ══════════════
echo "\n[4] Correção automática\n";
list( $novo, $log ) = CPC_Fixer::aplicar( $html, CPC_Fixer::regras_automaticas() );
foreach ( $log as $l ) { echo "    → $l\n"; }

ok( false === strpos( $novo, 'data-lazyloaded' ), 'data-lazyloaded removido' );
ok( false === strpos( $novo, 'data:image/svg' ), 'placeholder base64 removido' );
ok( false !== strpos( $novo, 'src="https://curadoriaprime.com/wp-content/uploads/tv.jpg"' ), 'URL real promovida para src' );
ok( substr_count( $novo, 'rel="sponsored noopener noreferrer nofollow"' ) === 2, 'sponsored nos 2 links' );
ok( false === strpos( $novo, 'aggregateRating' ), 'aggregateRating removido' );
ok( false !== strpos( $novo, 'Cristiano Martins' ), 'autor padronizado' );
ok( false === strpos( $novo, 'Equipe Curadoria Prime' ), 'autor antigo sumiu' );
ok( false !== strpos( $novo, 'Transparência' ), 'divulgação inserida' );

// o schema tem de continuar válido
$blocos = CPC_Rules::blocos_jsonld( $novo );
$parse_ok = true;
foreach ( $blocos as $bl ) {
	if ( ! is_array( json_decode( CPC_Rules::limpar_jsonld( $bl['bruto'] ), true ) ) ) { $parse_ok = false; }
}
ok( $parse_ok, 'JSON-LD continua fazendo parse depois da correção' );

echo "\n[4b] O corretor NÃO toca no que exige humano\n";
ok( false !== strpos( $novo, 'testamos' ), 'alegação de teste preservada (exige reescrita)' );
ok( false !== strpos( $novo, 'Estoque limitado' ), 'urgência falsa preservada (exige reescrita)' );

// ══════════════ 5. IDEMPOTÊNCIA ══════════════
echo "\n[5] Idempotência\n";
list( $novo2, $log2 ) = CPC_Fixer::aplicar( $novo, CPC_Fixer::regras_automaticas() );
ok( $novo2 === $novo, 'rodar 2x não muda nada (' . count( $log2 ) . ' ações na 2ª)' );

// ══════════════ 6. TRAVA DE SEGURANÇA ══════════════
echo "\n[6] Trava de segurança\n";
ok( empty( CPC_Diff::validar( $html, $novo ) ), 'correção legítima passa na trava' );

$sabotado = preg_replace( '/<img\b[^>]*>/', '', $html );
$err = CPC_Diff::validar( $html, $sabotado );
ok( ! empty( $err ), 'perda de imagem é barrada' );
echo "    → " . implode( '; ', $err ) . "\n";

$sabotado2 = preg_replace( '/<a\b[^>]*>.*?<\/a>/s', '', $html );
ok( ! empty( CPC_Diff::validar( $html, $sabotado2 ) ), 'perda de link é barrada' );

$sabotado3 = str_replace( '"aggregateRating"', '"aggregateRating}', $html );
ok( ! empty( CPC_Diff::validar( $html, $sabotado3 ) ), 'quebra de JSON-LD é barrada' );

// ══════════════ 7. GUTENBERG ══════════════
echo "\n[7] Fronteira de bloco Gutenberg\n";
$gut = "<!-- wp:paragraph -->\n<p>Intro do artigo.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"https://amzn.to/4biQQdq\">Comprar</a></p>\n<!-- /wp:paragraph -->";
list( $g, $glog ) = CPC_Fixer::aplicar( $gut, array( 'divulgacao' ) );
ok( false !== strpos( $g, '<!-- wp:html -->' ), 'divulgação embrulhada em wp:html' );
$abre = substr_count( $g, '<!-- wp:' );
$fecha = substr_count( $g, '<!-- /wp:' );
ok( $abre === $fecha, "blocos balanceados ($abre abre / $fecha fecha)" );
ok( false === strpos( $g, '<!-- /wp:paragraph -->' . "\n" . '<!-- wp:html -->' . "\n" . '<p>' ), 'não partiu parágrafo ao meio' );
$pos_div = strpos( $g, 'Transparência' );
$pos_link = strpos( $g, 'amzn.to' );
ok( $pos_div < $pos_link, 'divulgação vem ANTES do link de afiliado' );

echo "\n" . str_repeat( '─', 52 ) . "\n";
echo $falhas ? "❌ $falhas FALHA(S)\n" : "✅ TODOS OS TESTES PASSARAM\n";
exit( $falhas ? 1 : 0 );
