from playwright.sync_api import sync_playwright
import re, json

UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA, locale="pt-BR", viewport={"width":1366,"height":900},
                      extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()

    # ---------- AMAZON ----------
    try:
        pg.goto("https://www.amazon.com.br/dp/B0FVFZDYG7", timeout=60000, wait_until="domcontentloaded")
        pg.wait_for_timeout(4000)
        t=pg.title()
        print("AMZ title:",t)
        try:
            pg.get_by_text(re.compile("avaliações de clientes|Avaliações de clientes",re.I)).first.scroll_into_view_if_needed(timeout=8000)
        except Exception: pass
        pg.mouse.wheel(0,14000); pg.wait_for_timeout(3500)
        pg.mouse.wheel(0,9000);  pg.wait_for_timeout(2500)
        html=pg.content()
        open("/home/user/.smoke/_amz_rendered.html","w",encoding="utf-8").write(html)
        revs=pg.eval_on_selector_all('[data-hook="review"]', """els=>els.map(e=>({
            title:(e.querySelector('[data-hook="review-title"]')||{}).innerText||'',
            stars:(e.querySelector('[data-hook="review-star-rating"],[class*="a-icon-alt"]')||{}).textContent||'',
            body:(e.querySelector('[data-hook="review-body"]')||{}).innerText||'',
            date:(e.querySelector('[data-hook="review-date"]')||{}).innerText||''
        }))""")
        out["amazon_reviews"]=revs
        print("AMZ reviews:",len(revs))
        for r in revs[:6]:
            print("   *",r["stars"].strip()[:20],"|",r["title"].strip().replace("\n"," ")[:60],"|",r["body"].strip().replace("\n"," ")[:180])
        try:
            out["amazon_avg"]=pg.locator('#acrPopover').first.get_attribute("title")
            out["amazon_count"]=pg.locator('#acrCustomerReviewText').first.inner_text()
            print("AMZ media:",out["amazon_avg"],"| count:",out["amazon_count"])
        except Exception as e: print("amz meta err",e)
        # resumo IA
        for sel in ['[data-hook="cr-product-insights-card"]','#product-summary','[id*="lighthut"]']:
            try:
                if pg.locator(sel).count():
                    out["amazon_ai_summary"]=pg.locator(sel).first.inner_text()
                    print("AMZ resumo IA:",out["amazon_ai_summary"][:400]); break
            except Exception: pass
    except Exception as e:
        print("AMAZON FALHOU:",e)

    # ---------- MERCADO LIVRE ----------
    try:
        pg.goto("https://mercadolivre.com/sec/28LceQ9", timeout=60000, wait_until="domcontentloaded")
        pg.wait_for_timeout(5000)
        print("\nML url:",pg.url)
        print("ML title:",pg.title())
        pg.mouse.wheel(0,12000); pg.wait_for_timeout(3000)
        pg.mouse.wheel(0,10000); pg.wait_for_timeout(3000)
        open("/home/user/.smoke/_ml_rendered.html","w",encoding="utf-8").write(pg.content())
        for sel in ['[data-testid="rating-value"]','.ui-review-capability__rating__average','.ui-pdp-review__rating']:
            if pg.locator(sel).count():
                out["ml_avg"]=pg.locator(sel).first.inner_text(); print("ML média:",out["ml_avg"]); break
        for sel in ['[data-testid="rating-total"]','.ui-review-capability__rating__label','.ui-pdp-review__amount']:
            if pg.locator(sel).count():
                out["ml_count"]=pg.locator(sel).first.inner_text(); print("ML total:",out["ml_count"]); break
        cms=pg.eval_on_selector_all('[data-testid="comment-content-component"], .ui-review-capability-comments__comment__content, p.ui-review-capability-comments__comment__content',
             "els=>els.map(e=>e.innerText)")
        out["ml_comments"]=cms
        print("ML comentários:",len(cms))
        for c in cms[:10]: print("   *",c.strip().replace("\n"," ")[:200])
    except Exception as e:
        print("ML FALHOU:",e)
    b.close()
json.dump(out,open("/home/user/.smoke/_reviews.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
