import asyncio
from playwright.async_api import async_playwright
URL='https://curadoriaprime.com/qcy-t13-anc-review-2026-vale-a-pena/'
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        for w in (360,390):
            pg=await br.new_page(viewport={'width':w,'height':800},device_scale_factor=2,is_mobile=True,has_touch=True)
            try:
                await pg.goto(URL,wait_until='domcontentloaded',timeout=60000)
                await pg.wait_for_timeout(2500)
                r=await pg.evaluate("""()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})""")
                print(f"[{'OK ' if r['sw']<=r['cw']+1 else 'ESTOURA'}] @{w}px  scrollW={r['sw']} clientW={r['cw']}")
                if w==390:
                    el=await pg.query_selector('text=Como chegamos ao')
                    if el:
                        await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(800)
                        await pg.screenshot(path='.smoke/live-nota.png')
                        print('   screenshot da secao da nota: ok')
            except Exception as e: print(w,'ERRO',e)
            await pg.close()
        await br.close()
asyncio.run(main())
