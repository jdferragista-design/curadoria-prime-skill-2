<?php
function contexto_atual( $txt, $ini, $fim, $margem = 90 ) {
    $a = max( 0, $ini - $margem );
    $s = mb_substr( $txt, $a, ( $fim - $a ) + $margem, 'UTF-8' );
    return trim( preg_replace( '/\s+/u', ' ', $s ) );
}
function contexto_corrigido( $txt, $ini_b, $fim_b, $margem = 90 ) {
    $ini = mb_strlen( substr( $txt, 0, $ini_b ), 'UTF-8' );
    $fim = mb_strlen( substr( $txt, 0, $fim_b ), 'UTF-8' );
    $a = max( 0, $ini - $margem );
    $s = mb_substr( $txt, $a, ( $fim - $a ) + $margem, 'UTF-8' );
    return trim( preg_replace( '/\s+/u', ' ', $s ) );
}
// texto com MUITO multibyte antes da ocorrência (acentos + emoji, como o artigo real)
$txt = "Índice: 1️⃣ Introdução 2️⃣ Unboxing 3️⃣ Design e Conforto 4️⃣ Qualidade de Som 5️⃣ ANC 28dB 6️⃣ Chamadas 7️⃣ Bateria 8️⃣ App e Extras 9️⃣ Prós e Contras 🔟 Comparativo. "
     . "A conclusão é que não há concorrência direta. "
     . "Testamos o fone em uso diário por mais de duas semanas: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música. Veja o que encontramos. "
     . "1. Unboxing e Primeiras Impressões A caixa do QCY T13 ANC é funcional e sem excessos — papelão reciclado com janela plástica que mostra o estojo.";

preg_match_all('/\bTestamos\b/u', $txt, $mm, PREG_OFFSET_CAPTURE);
foreach ($mm[0] as $hit) {
    echo "trecho.......: {$hit[0]}\n";
    echo "offset BYTES.: {$hit[1]}   offset CHARS: " . mb_strlen(substr($txt,0,$hit[1]),'UTF-8') . "\n";
    echo "deriva.......: " . ($hit[1] - mb_strlen(substr($txt,0,$hit[1]),'UTF-8')) . " posicoes\n\n";
    echo "ATUAL (bug)..: " . contexto_atual($txt, $hit[1], $hit[1]+strlen($hit[0])) . "\n\n";
    echo "CORRIGIDO....: " . contexto_corrigido($txt, $hit[1], $hit[1]+strlen($hit[0])) . "\n";
}
