<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$h = file_get_contents('/home/user/qcy3523.html');
$a = CPC_Rules::analisar($h);

echo "Se a IA sugerir algo e o usuario mandar gravar, o que acontece?\n\n";
foreach($a as $x){
  if($x['auto']) continue;
  printf("── %s\n", $x['regra']);
  foreach($x['ocorrencias'] as $i=>$o){
    $tr=$o['trecho'];
    list($novo,$erro) = CPC_Editor::substituir($h, $tr, 'TEXTO_SUBSTITUTO_DE_TESTE');
    $n = substr_count($h, $tr);
    printf("  %2d. %-12s ocorre %2dx no HTML  →  %s\n", $i+1, '"'.mb_substr($tr,0,10,'UTF-8').'"', $n,
        $erro ? '🔴 RECUSADA: '.$erro : '✅ grava');
  }
  echo "\n";
}
