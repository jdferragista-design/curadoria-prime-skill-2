import asyncio,sys
from playwright.async_api import async_playwright
TPL = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 body{{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#333;line-height:1.75}}
 .site{{max-width:760px;margin:0 auto;padding:16px}}
 img{{max-width:100%;height:auto}}
</style></head><body><div class="site post-content">{}</div></body></html>"""
async def main():
    src=sys.argv[1]
    html=TPL.format(open(src,encoding='utf-8').read())
    f='.smoke/_t_4541.html'; open(f,'w',encoding='utf-8').write(html)
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        for w in (360,390):
            pg=await br.new_page(viewport={'width':w,'height':800},device_scale_factor=2,is_mobile=True,has_touch=True)
            await pg.goto('file:///home/user/'+f); await pg.wait_for_timeout(400)
            r=await pg.evaluate("""()=>{const de=document.documentElement;
              const over=[...document.querySelectorAll('.post-content *')].filter(el=>{
                 const r=el.getBoundingClientRect();
                 if(r.width===0)return false;
                 let p=el.parentElement,clipped=false;
                 while(p){const s=getComputedStyle(p); if(s.overflowX==='auto'||s.overflowX==='scroll'){clipped=true;break;} p=p.parentElement;}
                 return !clipped && (r.right>window.innerWidth+1||r.left<-1);
              }).map(el=>({t:el.tagName,txt:(el.textContent||'').trim().slice(0,42),
                    r:Math.round(el.getBoundingClientRect().right),w:Math.round(el.getBoundingClientRect().width),
                    st:(el.getAttribute('style')||'').slice(0,80)}));
              return {sw:de.scrollWidth,cw:de.clientWidth,n:over.length,over:over.slice(0,10)};}""")
            print(f"\n[{'OK' if r['sw']<=r['cw']+1 else 'ESTOURA'}] @{w}px scrollW={r['sw']} clientW={r['cw']} fora={r['n']}")
            for o in r['over']: print('   ',o)
            await pg.screenshot(path=f'.smoke/4541-{w}.png',full_page=False)
            await pg.close()
        await br.close()
asyncio.run(main())
