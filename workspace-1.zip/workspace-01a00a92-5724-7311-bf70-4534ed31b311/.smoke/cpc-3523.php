<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$h = file_get_contents('/home/user/qcy3523.html');
$a = CPC_Rules::analisar($h);
$txt = CPC_Rules::texto_visivel($h);

echo "texto visivel: ".strlen($txt)." bytes / ".mb_strlen($txt,'UTF-8')." chars\n";
echo "deriva total no fim do doc: ".(strlen($txt)-mb_strlen($txt,'UTF-8'))." posicoes\n\n";

foreach($a as $x){
  printf("[%s] %s  n=%d\n", $x['gravidade'], $x['regra'], $x['n']);
  foreach($x['ocorrencias'] as $i=>$o){
    $tr = $o['trecho']; $ctx = $o['contexto'];
    // o contexto DEVE conter o trecho. se nao contem, esta deslocado.
    $ok = (mb_stripos($ctx,$tr,0,'UTF-8') !== false);
    printf("   %2d. %-14s %s\n", $i+1, '"'.mb_substr($tr,0,12,'UTF-8').'"', $ok?'ctx OK':'🔴 CTX NAO CONTEM O TRECHO');
  }
  echo "\n";
}
