<?php
$ok=0;$fail=0;
function ok($c,$m){global $ok,$fail; if($c){$ok++;echo "  ok   $m\n";}else{$fail++;echo "  FALHA $m\n";}}
$src=file_get_contents('/home/user/curadoria-conformidade/includes/class-cpc-ia.php');

echo "\n[1] medidor mensal usa hora LOCAL, nao UTC\n";
ok(strpos($src,"gmdate( 'Y-m' )")===false, "uso_do_mes nao usa mais gmdate('Y-m')");
ok(strpos($src,"substr( (string) current_time( 'mysql' ), 0, 7 )")!==false,
   'filtra pelo mesmo relogio que grava o carimbo');

// simula a virada do mes em Sao Paulo (UTC-3)
$tz=new DateTimeZone('America/Sao_Paulo');
$casos=array('2026-08-31 22:30'=>'2026-08','2026-08-31 20:00'=>'2026-08','2026-09-01 00:30'=>'2026-09');
$erros=0;
foreach($casos as $local=>$esperado){
  $d=new DateTime($local,$tz);
  $gravado=$d->format('Y-m-d H:i:s');
  $filtro_novo=substr($gravado,0,7);              // corrigido
  $u=clone $d; $u->setTimezone(new DateTimeZone('UTC'));
  $filtro_velho=$u->format('Y-m');                 // bug
  if(strpos($gravado,$filtro_novo)!==0) $erros++;
  if($local==='2026-08-31 22:30')
    ok(strpos($gravado,$filtro_velho)!==0, 'o bug era real: 31/08 22h30 sumia do mes (filtro UTC dizia '.$filtro_velho.')');
}
ok($erros===0,'com o filtro local, nenhuma chamada some da contagem');

echo "\n[2] aviso de custo por modelo\n";
ok(strpos($src,'tabela_precos')!==false,'existe tabela de precos de referencia');
ok(strpos($src,'function estimativa')!==false,'existe estimativa de lote');
$adm=file_get_contents('/home/user/curadoria-conformidade/includes/class-cpc-admin.php');
ok(strpos($adm,'cpc-precos')!==false,'a tela de configuracao mostra o comparativo');
ok(strpos($adm,'CPC_IA::estimativa( $mod, 1219 )')!==false,'estima o site inteiro, nao so um artigo');

echo "\n[3] a aritmetica do comparativo\n";
$cambio=5.45;
$est=function($in,$out,$campos)use($cambio){ return (556*$in+215*$out)/1e6*$campos*$cambio; };
$haiku=$est(1.00,5.00,1219); $flash=$est(0.10,0.40,1219);
printf("     haiku-4.5: R$ %.2f · flash-lite: R$ %.2f · razao %.1fx\n",$haiku,$flash,$haiku/$flash);
ok($haiku>10 && $flash<1.5,'haiku passa de R$ 10 no site inteiro e flash-lite fica abaixo de R$ 1,50');
ok($haiku/$flash>7,'a diferenca entre modelos e grande o bastante para merecer aviso');

echo "\n".str_repeat('=',52)."\n";
echo $fail? "❌ $fail FALHA(S)\n" : "✅ $ok TESTES PASSARAM\n";
exit($fail?1:0);
