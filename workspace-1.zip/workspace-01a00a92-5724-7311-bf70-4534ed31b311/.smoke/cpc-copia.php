<?php
// Por que "como deve ficar" aparece vazio ao copiar a pagina.
// Um <textarea> preenchido por JS via .value NAO altera o no de texto do DOM.
// Ctrl+A / "copiar" serializa o DOM, entao a sugestao nao vai junto.
echo "=== soma do medidor com os 3 cards ===\n";
$cards=array(
  array('deepseek-v4-flash',1254,0.0007),
  array('anthropic/claude-haiku-4.5',771,0.0073),
  array('google/gemini-3.1-flash-lite',640,0.0017),
);
$acc=0;
foreach($cards as $c){
  $acc+=$c[2];
  printf("  %-30s %5d tok · R$ %.4f · acumulado R$ %.4f -> exibido 'mês: R$ %s'\n",
    $c[0],$c[1],$c[2],$acc,number_format($acc,2,',','.'));
}
echo "\n  As 3 chamadas somam R$ ".number_format($acc,4,',','.').", que arredonda para R$ 0,01.\n";
echo "  O medidor esta COERENTE: nao encolheu, so nao tem casas decimais\n";
echo "  suficientes para mostrar a diferenca entre 0,0080 e 0,0097.\n";

echo "\n=== tokens de saida por card ===\n";
$in=556;
foreach($cards as $c){
  $out=$c[1]-$in;
  printf("  %-30s saida ~%4d tok (~%4d chars) %s\n",$c[0],$out,(int)round($out*3.6),
    $out>=690?'<- COLADO no teto 700':'');
}
