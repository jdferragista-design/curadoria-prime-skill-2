<?php
define('ABSPATH', '/tmp/wp/');
function esc_html($s){return $s;}
function esc_attr($s){return $s;}
function wp_kses_post($s){return $s;}
function sanitize_text_field($s){return $s;}
function __($s,$d=null){return $s;}
function esc_html__($s,$d=null){return $s;}
function wp_json_encode($d,$o=0){return json_encode($d,$o|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
function get_option($k,$d=false){return $d;}
function update_option($k,$v,$a=null){return true;}
function wp_parse_args($a,$d=[]){ if(is_object($a))$a=get_object_vars($a); elseif(!is_array($a))$a=[]; return array_merge($d,$a);}
function wp_parse_url($u,$c=-1){return $c===-1?parse_url($u):parse_url($u,$c);}
function untrailingslashit($s){return rtrim($s,'/');}
function trailingslashit($s){return rtrim($s,'/').'/';}
function add_action(){}
function add_filter(){}
function current_time($t){return date('Y-m-d H:i:s');}
foreach (['class-cpc-plugin','class-cpc-rules'] as $m) require_once "/home/user/curadoria-conformidade/includes/$m.php";
$r = CPC_Rules::analisar(file_get_contents($argv[1]));
$c=[]; foreach($r as $i) $k=$i["regra"]??$i["id"]??$i["codigo"]??json_encode(array_keys($i));$c[$k]=($c[$k]??0)+1;
ksort($c);
foreach($c as $t=>$n) printf("  %-20s %d\n",$t,$n);
if(!$c) echo "  (nenhum achado)\n";
