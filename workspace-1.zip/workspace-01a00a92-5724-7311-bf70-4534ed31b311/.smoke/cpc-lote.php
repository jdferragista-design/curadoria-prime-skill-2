<?php
define('ABSPATH','/tmp/wp/');
function esc_html($s){return $s;} function esc_attr($s){return $s;} function wp_kses_post($s){return $s;}
function sanitize_text_field($s){return $s;} function __($s,$d=null){return $s;} function esc_html__($s,$d=null){return $s;}
function wp_json_encode($d,$o=0){return json_encode($d,$o|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
function get_option($k,$d=false){return $d;} function update_option($k,$v,$a=null){return true;}
function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);}
function wp_parse_url($u,$c=-1){return $c===-1?parse_url($u):parse_url($u,$c);}
function untrailingslashit($s){return rtrim($s,'/');} function trailingslashit($s){return rtrim($s,'/').'/';}
function add_action(){} function add_filter(){} function current_time($t){return date('Y-m-d H:i:s');}
foreach(['class-cpc-plugin','class-cpc-rules'] as $m) require_once "/home/user/curadoria-conformidade/includes/$m.php";
$tot=[]; $totn=0; $arq=0;
foreach(array_slice($argv,1) as $f){
  if(!is_file($f)) continue;
  $arq++;
  foreach(CPC_Rules::analisar(file_get_contents($f)) as $a){
    $tot[$a['regra']]=($tot[$a['regra']]??0)+$a['n']; $totn+=$a['n'];
  }
}
arsort($tot);
echo "arquivos: $arq   ocorrências: $totn\n\n";
foreach($tot as $r=>$n) printf("  %-20s %5d  (%4.1f%%)\n",$r,$n,100*$n/max(1,$totn));
