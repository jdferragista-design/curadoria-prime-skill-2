<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$h=file_get_contents('/home/user/qcy3523.html');
$a=CPC_Rules::analisar($h);

// mesma FRASE aparecendo em regras diferentes?
$mapa=[];
foreach($a as $x){ if($x['auto']) continue;
  foreach($x['ocorrencias'] as $o){ $mapa[$o['trecho']][] = $x['regra']; } }

echo "=== frases que aparecem em MAIS DE UMA regra ===\n";
$n=0;
foreach($mapa as $frase=>$regras){
  if(count($regras)>1){ $n++;
    echo "\n[".implode(' + ',$regras)."]\n  ".mb_substr($frase,0,130,'UTF-8')."\n"; }
}
echo $n? "\n>>> $n colisao(oes)\n" : "\nnenhuma colisao exata\n";

// e sobreposicao parcial (uma frase contida na outra)?
echo "\n=== sobreposicao parcial ===\n";
$frases=array_keys($mapa); $m=0;
for($i=0;$i<count($frases);$i++) for($j=$i+1;$j<count($frases);$j++){
  if(str_contains($frases[$i],$frases[$j]) || str_contains($frases[$j],$frases[$i])){
    $m++; echo "  A: ".mb_substr($frases[$i],0,80,'UTF-8')."\n  B: ".mb_substr($frases[$j],0,80,'UTF-8')."\n\n"; }
}
echo $m? ">>> $m sobreposicao(oes)\n" : "nenhuma\n";

// SIMULACAO: usuario preenche TODOS os campos e grava
echo "\n=== simulacao: editor preenche os 24 campos e grava ===\n";
$ed=[];
foreach($a as $x){ if($x['auto']) continue;
  foreach($x['ocorrencias'] as $k=>$o){
    $ed[]=['original'=>$o['trecho'],'novo'=>'[REESCRITO '.$x['regra'].'-'.$k.']','regra'=>$x['regra']]; } }
list($novo,$apl,$rec)=CPC_Editor::aplicar_lote($h,$ed);
printf("aplicadas: %d · recusadas: %d\n",count($apl),count($rec));
foreach($rec as $r) echo "  RECUSA [".$r['regra']."] ".mb_substr($r['trecho'],0,90,'UTF-8')."\n     -> ".$r['erro']."\n";
