<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;}
function _n($a,$b,$n,$d=null){return $n==1?$a:$b;}
function wp_parse_url($u,$c=-1){return parse_url($u);} function wp_kses_post($s){return $s;}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";
$html=file_get_contents('/home/user/qcy3523.html');
foreach(CPC_Rules::analisar($html) as $a){
  printf("\n##### %s | %s | n=%d | auto=%s\n",$a['regra'],$a['gravidade'],$a['n'],!empty($a['auto'])?'sim':'NAO');
  foreach($a['ocorrencias'] as $i=>$o){
    printf("--- [%s#%d]\n%s\n",$a['regra'],$i+1,preg_replace('/\s+/',' ',trim($o['trecho'])));
  }
}
