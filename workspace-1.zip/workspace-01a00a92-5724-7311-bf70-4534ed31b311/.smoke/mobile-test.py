import asyncio, sys
from playwright.async_api import async_playwright

TPL = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 body{{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#333;line-height:1.75}}
 .site{{max-width:760px;margin:0 auto;padding:16px}}
 img{{max-width:100%;height:auto}}
</style></head><body><div class="site post-content">{}</div></body></html>"""

async def main():
    async with async_playwright() as pw:
        br = await pw.chromium.launch()
        for path,label in [('correcoes/como-avaliamos/PAGINA-para-colar.html','como-avaliamos'),
                           ('correcoes/3523/CORPO-para-colar.html','3523')]:
            html = TPL.format(open(path,encoding='utf-8').read())
            f='.smoke/_t_%s.html'%label
            open(f,'w',encoding='utf-8').write(html)
            for w,name in [(360,'360'),(390,'390')]:
                pg = await br.new_page(viewport={'width':w,'height':800},
                                       device_scale_factor=2, is_mobile=True, has_touch=True)
                await pg.goto('file:///home/user/'+f)
                await pg.wait_for_timeout(350)
                r = await pg.evaluate("""() => {
                  const de=document.documentElement;
                  const over=[...document.querySelectorAll('.post-content *')].filter(el=>{
                    const r=el.getBoundingClientRect();
                    return r.right > window.innerWidth+1 || r.left < -1;
                  }).map(el=>({t:el.tagName,c:(el.className||'').toString().slice(0,25),
                               r:Math.round(el.getBoundingClientRect().right),
                               l:Math.round(el.getBoundingClientRect().left)}));
                  return {scrollW:de.scrollWidth, clientW:de.clientWidth,
                          bodyScroll:document.body.scrollWidth, over:over.slice(0,8), n:over.length};
                }""")
                flag = 'OK ' if r['scrollW'] <= r['clientW']+1 else 'ESTOURA'
                print(f"[{flag}] {label} @{w}px  scrollW={r['scrollW']} clientW={r['clientW']} elementos_fora={r['n']}")
                for o in r['over']: print('        ',o)
                await pg.screenshot(path=f'.smoke/shot-{label}-{name}.png', full_page=False)
                await pg.close()
        await br.close()
asyncio.run(main())
