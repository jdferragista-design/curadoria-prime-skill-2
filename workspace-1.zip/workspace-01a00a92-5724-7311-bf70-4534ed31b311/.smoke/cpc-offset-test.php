<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$falhas=0;
function ok($c,$m){ global $falhas; if($c){echo "  ok   $m\n";} else {echo "  FAIL $m\n"; $falhas++;} }

echo "\n=== v1.2.1 regressao: offset byte-vs-char + unidade de edicao ===\n\n";

echo "[1] contexto contem o proprio trecho (bug do offset)\n";
// muito multibyte ANTES da ocorrencia = maior deriva
$pre = str_repeat("Ótimo áudio com ação e emoção 🎧 ", 40);
$html = "<p>$pre</p><p>Testamos o fone por duas semanas em uso real e ele agradou.</p>";
$a = CPC_Rules::analisar($html);
$at = null; foreach($a as $x) if($x['regra']==='alegacao_teste') $at=$x;
ok($at !== null, 'detectou alegacao apos 1200+ bytes multibyte');
foreach($at['ocorrencias'] as $o){
    ok(mb_stripos($o['contexto'],$o['tokens'][0],0,'UTF-8')!==false, 'contexto contem o token "'.$o['tokens'][0].'"');
    ok(mb_stripos($o['trecho'],$o['tokens'][0],0,'UTF-8')!==false, 'trecho editavel contem o token');
}

echo "\n[2] trecho editavel e a FRASE, nao o token\n";
ok(mb_strlen($at['ocorrencias'][0]['trecho'],'UTF-8') > 20, 'frase tem >20 chars (era "Testamos" = 8)');
ok(str_contains($at['ocorrencias'][0]['trecho'],'duas semanas'), 'frase inteira capturada');

echo "\n[3] frase repetida no post nao bloqueia gravacao\n";
$h2 = '<p>Testamos o fone A e gostamos.</p><p>Testamos o fone B tambem.</p>';
$a2 = CPC_Rules::analisar($h2);
$at2=null; foreach($a2 as $x) if($x['regra']==='alegacao_teste') $at2=$x;
$grava=0; $recusa=0;
foreach($at2['ocorrencias'] as $o){
    list($n,$e)=CPC_Editor::substituir($h2,$o['trecho'],'Analisamos.');
    if($e) $recusa++; else $grava++;
}
ok($recusa===0, "as 2 frases com 'Testamos' gravam (recusas=$recusa)");
ok($grava===2, "2 campos gravaveis (grava=$grava)");

echo "\n[4] duas deteccoes na MESMA frase = 1 campo\n";
$h3='<p>Nos testamos o produto e medimos o brilho na bancada.</p>';
$a3=CPC_Rules::analisar($h3); $at3=null; foreach($a3 as $x) if($x['regra']==='alegacao_teste') $at3=$x;
ok(count($at3['ocorrencias'])===1, 'virou 1 campo, nao 2 ('.count($at3['ocorrencias']).')');
ok(count($at3['ocorrencias'][0]['tokens'])>=2, 'guarda os 2 tokens: '.implode(',',$at3['ocorrencias'][0]['tokens']));

echo "\n[5] ancora tolera tag longa e entidade\n";
$h4='<p>Na nossa <a style="color: #667eea; font-weight: 600; text-decoration: underline;" href="https://x.com/a">lista dos melhores</a> ele ganha por R$ 250 hoje.</p>';
$a4=CPC_Rules::analisar($h4); $ap=null; foreach($a4 as $x) if($x['regra']==='preco_sem_data') $ap=$x;
ok($ap!==null,'detectou preco');
list($n4,$e4)=CPC_Editor::substituir($h4,$ap['ocorrencias'][0]['trecho'],'SUBSTITUIDO');
ok($e4==='', 'grava apesar da tag de 60+ chars no meio'.($e4?" [$e4]":''));
ok(str_contains($n4,'SUBSTITUIDO'), 'substituicao entrou no html');

$h5='<p>O ANC &#8220;funciona bem&#8221; e custa R$ 199 no site.</p>';
$a5=CPC_Rules::analisar($h5); $ap5=null; foreach($a5 as $x) if($x['regra']==='preco_sem_data') $ap5=$x;
list($n5,$e5)=CPC_Editor::substituir($h5,$ap5['ocorrencias'][0]['trecho'],'X');
ok($e5==='', 'grava com entidade &#8220; no meio'.($e5?" [$e5]":''));

echo "\n[6] schema: description repetida troca em TODAS as copias\n";
$desc='Testamos por 30 dias: ANC de 28dB.';
$h6='<meta name="description" content="'.$desc.'"><meta property="og:description" content="'.$desc.'">'
   .'<script type="application/ld+json">{"@type":"Product","description":"'.$desc.'"}</script>';
list($n6,$e6)=CPC_Editor::substituir($h6,$desc,'Analise documental: ANC de 28dB.',true);
ok($e6==='', 'com $todas=true nao recusa');
ok(substr_count($n6,'Analise documental')===3, 'as 3 copias trocadas ('.substr_count($n6,'Analise documental').')');
list($n6b,$e6b)=CPC_Editor::substituir($h6,$desc,'X'); // sem $todas
ok($e6b!=='', 'sem $todas continua recusando por ambiguidade');

echo "\n[7] frase gigante sem pontuacao nao vira campo gigante\n";
$long='<p>'.str_repeat('coluna dado valor ',120).' testamos isso '.str_repeat('mais dado ',120).'</p>';
$a7=CPC_Rules::analisar($long); $at7=null; foreach($a7 as $x) if($x['regra']==='alegacao_teste') $at7=$x;
ok($at7!==null,'detectou');
ok(mb_strlen($at7['ocorrencias'][0]['trecho'],'UTF-8')<=600, 'campo limitado a 600 chars ('.mb_strlen($at7['ocorrencias'][0]['trecho'],'UTF-8').')');

echo "\n[8] nao corta frase dentro de numero\n";
$h8='<p>A TV custa R$ 1.973,50 hoje e vale muito.</p>';
$a8=CPC_Rules::analisar($h8); $ap8=null; foreach($a8 as $x) if($x['regra']==='preco_sem_data') $ap8=$x;
ok(str_contains($ap8['ocorrencias'][0]['trecho'],'1.973,50'), 'preco inteiro na frase: '.$ap8['ocorrencias'][0]['trecho']);

echo "\n[9] contexto nao corta palavra ao meio\n";
$h9='<p>'.str_repeat('palavra generica aqui ',12).'melhor custo-beneficio em ANC absoluto e o fone custa R$ 250 hoje mesmo.'.str_repeat(' mais texto solto',12).'</p>';
$a9=CPC_Rules::analisar($h9); $ap9=null; foreach($a9 as $x) if($x['regra']==='preco_sem_data') $ap9=$x;
$ctx=$ap9['ocorrencias'][0]['contexto'];
$corpo=trim(str_replace(array('…'),'',$ctx));
$primeira=preg_split('/\s+/u',$corpo)[0];
$partes=preg_split('/\s+/u',$corpo); $ultima=end($partes);
ok(str_contains($h9,$primeira),'primeira palavra do ctx e inteira: "'.$primeira.'"');
ok(str_contains($h9,$ultima),'ultima palavra do ctx e inteira: "'.$ultima.'"');
ok(str_starts_with($ctx,'…'),'marca reticencias no inicio');

echo "\n[10] mesma frase em 2 regras = 1 campo so (colisao)\n";
$h10='<p>O ANC supera qualquer earbud na faixa de preco que testamos e custa ate R$ 280.</p>';
$a10=CPC_Rules::analisar($h10);
$frases=array(); $manuais=0;
foreach($a10 as $x){ if($x['auto']) continue; $manuais++; foreach($x['ocorrencias'] as $o) $frases[]=$o['trecho']; }
ok(count($frases)===count(array_unique($frases)), 'nenhuma frase duplicada entre regras ('.count($frases).' campos)');
$dono=null; foreach($a10 as $x){ if($x['auto']) continue; foreach($x['ocorrencias'] as $o) if(count($o['tokens'])>1) $dono=$o; }
ok($dono!==null,'o campo unico carrega tokens das 2 regras');
if($dono) ok(!empty($dono['tambem']),'e registra a outra regra em [tambem]: '.implode(',',$dono['tambem']));

echo "\n[11] gravar TODOS os campos nao gera recusa\n";
$h11=file_exists('/home/user/qcy3523.html')?file_get_contents('/home/user/qcy3523.html'):null;
if($h11){
  $a11=CPC_Rules::analisar($h11); $ed=array();
  foreach($a11 as $x){ if($x['auto']) continue; foreach($x['ocorrencias'] as $k=>$o)
    $ed[]=array('original'=>$o['trecho'],'novo'=>'[X'.$k.$x['regra'].']','regra'=>$x['regra']); }
  list($nv,$ap,$rc)=CPC_Editor::aplicar_lote($h11,$ed);
  ok(count($rc)===0, 'artigo real 3523: 0 recusas ('.count($ap).' aplicadas)');
} else { echo "  -- pulado (qcy3523.html ausente)\n"; }

echo "\n[12] toda ocorrencia tem tokens[] e tambem[]\n";
$faltando=0;
foreach(array($h11?:$h9,'<p>Testamos e verificado ha 2 horas. Estoque limitado. R$ 99</p>') as $hx){
  if(!$hx) continue;
  foreach(CPC_Rules::analisar($hx) as $x) foreach($x['ocorrencias'] as $o)
    if(!isset($o['tokens'])||!isset($o['tambem'])) $faltando++;
}
ok($faltando===0,"nenhuma ocorrencia sem as chaves (faltando=$faltando)");

echo "\n[13] fundir campos NAO pode apagar a regra da estatistica\n";
$h13='<p>O ANC supera qualquer earbud na faixa de preco que testamos e custa ate R$ 280.</p>';
$a13=CPC_Rules::analisar($h13);
$vistas=array(); $somaN=0;
foreach($a13 as $x){ $vistas[]=$x['regra']; if(!$x['auto']) $somaN+=$x['n']; }
ok(in_array('alegacao_teste',$vistas,true) && in_array('preco_sem_data',$vistas,true),
   'as 2 regras continuam no relatorio: '.implode(', ',$vistas));
ok($somaN===2, "['n'] continua contando as 2 deteccoes (soma=$somaN)");
$campos=0; $movidas=0;
foreach($a13 as $x){ if($x['auto']) continue; $campos+=count($x['ocorrencias']); $movidas+=count($x['movidas']); }
ok($campos===1, "mas so 1 campo editavel (campos=$campos)");
ok($movidas===1, "e 1 trecho marcado como movido (movidas=$movidas)");
$mv=null; foreach($a13 as $x) if(!empty($x['movidas'])) $mv=$x['movidas'][0];
ok($mv && !empty($mv['para']), 'o movido diz para qual regra foi: '.($mv?$mv['para']:'-'));

echo "\n[14] artigo real 3523 mantem o total historico\n";
if($h11){
  $a14=CPC_Rules::analisar($h11); $tot=0; $campos14=0;
  foreach($a14 as $x){ $tot+=$x['n']; if(!$x['auto']) $campos14+=count($x['ocorrencias']); }
  ok($tot>=26, "total de deteccoes preservado (n=$tot, campos editaveis=$campos14)");
  ok($campos14<$tot, 'campos editaveis < deteccoes (frases fundidas)');
}

echo "\n".str_repeat('=',52)."\n";
echo $falhas ? "$falhas FALHA(S)\n" : "TODOS OS TESTES PASSARAM\n";
exit($falhas?1:0);
