<?php
$ok=0;$fail=0;
function ok($c,$m){global $ok,$fail; if($c){$ok++;echo "  ok   $m\n";}else{$fail++;echo "  FALHA $m\n";}}
$js=file_get_contents('/home/user/curadoria-conformidade/assets/admin.js');
$ad=file_get_contents('/home/user/curadoria-conformidade/includes/class-cpc-admin.php');

echo "\n[1] sugestao sobrevive a copia da pagina\n";
ok(strpos($js,'area.textContent = r.data.texto')!==false,'espelha a sugestao no no de texto do DOM');
ok(strpos($js,"setAttribute( 'data-sugerido'")!==false,'guarda a sugestao num atributo tambem');
// Depois da unificacao existe UMA implementacao (sugerirUm). O que importa e
// que ela sete .value (caixa editavel) antes de espelhar no DOM.
$i=strpos($js,'area.value       = r.data.texto');
$j=strpos($js,'area.textContent = r.data.texto');
ok($i!==false && $j!==false && $j>$i,'.value continua sendo setado (a caixa editavel funciona)');
ok(substr_count($js,"dados.append( 'action', 'cpc_sugerir' )")===1,'existe UMA so implementacao da chamada (botao e lote compartilham)');

echo "\n[2] medidor mensal legivel em valores pequenos\n";
ok(strpos($ad,"< 0.10 ? 4 : 2")!==false,'abaixo de R$ 0,10 mostra 4 casas');
// chave de array em PHP nao aceita float (vira int), entao usa lista de pares
$vals=array(array(0.0007,4),array(0.0080,4),array(0.0097,4),array(0.5,2),array(12.34,2));
foreach($vals as $par){
  list($v,$casas)=$par;
  $c = $v < 0.10 ? 4 : 2;
  ok($c===$casas,sprintf('R$ %.4f exibido com %d casas',$v,$c));
}
// o sintoma que o usuario viu
ok(number_format(0.0080,2)===number_format(0.0097,2),'com 2 casas, 0,0080 e 0,0097 eram indistinguiveis (o "mes travado")');
ok(number_format(0.0080,4)!==number_format(0.0097,4),'com 4 casas, o avanco fica visivel');

echo "\n[3] raciocinio aparece na nota de custo\n";
ok(strpos($ad,"'raciocinio' => (int) \$r['tokens_raciocinio']")!==false,'servidor envia tokens de raciocinio');
ok(strpos($js,'r.data.raciocinio > 0')!==false,'JS so mostra quando houver');
ok(strpos($js,'de raciocínio')!==false,'nota explica o que sao os tokens extras');

echo "\n".str_repeat('=',52)."\n";
echo $fail? "❌ $fail FALHA(S)\n" : "✅ $ok TESTES PASSARAM\n";
exit($fail?1:0);
