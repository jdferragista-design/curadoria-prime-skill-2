import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        pg=await br.new_page(viewport={'width':390,'height':1000},device_scale_factor=2,is_mobile=True)
        await pg.goto('file:///home/user/.smoke/_n.html'); await pg.wait_for_timeout(300)
        el=await pg.query_selector('text=arredondado para o múltiplo')
        await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(250)
        await pg.screenshot(path='.smoke/conta-390.png'); await br.close()
asyncio.run(main())
