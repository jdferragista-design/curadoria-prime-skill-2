import asyncio
from playwright.async_api import async_playwright
TPL = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#333;line-height:1.75}
.site{max-width:760px;margin:0 auto;padding:16px}img{max-width:100%%;height:auto}</style>
</head><body><div class="site post-content">%s</div></body></html>"""
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        for path,label,sel in [('correcoes/como-avaliamos/PAGINA-para-colar.html','ca',2),
                               ('correcoes/3523/CORPO-para-colar.html','p3523',0)]:
            open('.smoke/_s_%s.html'%label,'w',encoding='utf-8').write(TPL % open(path,encoding='utf-8').read())
            pg=await br.new_page(viewport={'width':360,'height':900},device_scale_factor=2,is_mobile=True)
            await pg.goto('file:///home/user/.smoke/_s_%s.html'%label)
            await pg.wait_for_timeout(300)
            el=(await pg.query_selector_all('div[style*="overflow-x"]'))[sel]
            await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(200)
            await pg.screenshot(path='.smoke/tab-%s.png'%label)
            await pg.close()
        await br.close()
asyncio.run(main())
