from playwright.sync_api import sync_playwright
import re
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":950},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto("https://www.mercadolivre.com.br/noindex/catalog/reviews/MLB4615627273?objectId=MLB4615627273&siteId=MLB&isItem=true&noIndex=true",
        timeout=60000,wait_until="networkidle"); pg.wait_for_timeout(4000)
    t=pg.inner_text("body")
    print("ML:",re.search(r'Avaliação ([\d,\.]+) de 5\. ([\d\.]+) opiniões',t).groups())
    print("ML comentários:",re.search(r'([\d\.]+)\s*comentários',t).group(1))
    # distribuição em %
    bars=pg.eval_on_selector_all('[class*="rating-levels"] *[aria-label], [class*="level"] [aria-label]',
        "els=>els.map(e=>e.getAttribute('aria-label')).filter(Boolean)")
    print("ML barras:",bars[:10])
    # Amazon
    pg2=ctx.new_page()
    pg2.goto("https://www.amazon.com.br/dp/B0FVFZDYG7",timeout=60000,wait_until="domcontentloaded")
    pg2.wait_for_timeout(4000)
    for _ in range(5): pg2.mouse.wheel(0,4000); pg2.wait_for_timeout(900)
    ta=pg2.inner_text("body")
    m=re.search(r'([\d,]+) de 5 estrelas',ta); print("\nAMZ nota:",m.group(1) if m else None)
    m=re.search(r'([\d\.]+)\s*classificações globais',ta); print("AMZ total:",m.group(1) if m else None)
    pcts=re.findall(r'([\d]+ estrelas?)\s*\n?\s*(\d+%)',ta)
    print("AMZ distribuição:",pcts[:6])
    i=ta.find("classificações globais"); print("ctx:",ta[max(0,i-300):i+300].replace("\n"," | ")[:480])
    b.close()
