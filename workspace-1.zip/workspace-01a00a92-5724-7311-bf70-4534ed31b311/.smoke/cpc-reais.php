<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$arquivos = [
 '3181 ANTES (publicado)'  => '/home/user/correcoes/3181-LG-AU801/_original-publicado.html',
 '3181 DEPOIS (corrigido)' => '/home/user/correcoes/3181-LG-AU801/3181-ARTIGO-COMPLETO.html',
 '2943 Stanley (no ar)'    => '/home/user/no-ar-2943-stanley.html',
 '4537 Apple TV (v2)'      => '/home/user/4537-apple-tv-CORRIGIDO-v2.html',
];
foreach($arquivos as $nome=>$path){
  if(!file_exists($path)){ echo "── $nome: arquivo ausente\n\n"; continue; }
  $h = file_get_contents($path);
  $t0=microtime(true); $a = CPC_Rules::analisar($h); $ms=(microtime(true)-$t0)*1000;
  printf("── %s  (%s KB, %.0f ms)\n", $nome, number_format(strlen($h)/1024,0), $ms);
  if(!$a){ echo "   ✅ ZERO achados\n\n"; continue; }
  foreach($a as $x) printf("   [%-5s] %-18s n=%-3d %s\n",$x['gravidade'],$x['regra'],$x['n'],$x['auto']?'(auto)':'(humano)');
  // aplicar automáticas e validar
  list($novo,$log)=CPC_Fixer::aplicar($h,CPC_Fixer::regras_automaticas());
  $err=CPC_Diff::validar($h,$novo);
  echo "   correção: ".($log?implode(' | ',$log):'nada a fazer')."\n";
  echo "   trava: ".($err?'🔴 BLOQUEADA → '.implode('; ',$err):'✅ passa')."\n";
  list($n2,$l2)=CPC_Fixer::aplicar($novo,CPC_Fixer::regras_automaticas());
  echo "   idempotente: ".($n2===$novo?'✅':'❌ mudou de novo')."\n";
  $rest = CPC_Rules::analisar($novo);
  $sobra = array_filter($rest, fn($r)=>$r['auto']);
  echo "   auto restantes após correção: ".(count($sobra)?'❌ '.implode(',',array_column($sobra,'regra')):'✅ nenhuma')."\n\n";
}
