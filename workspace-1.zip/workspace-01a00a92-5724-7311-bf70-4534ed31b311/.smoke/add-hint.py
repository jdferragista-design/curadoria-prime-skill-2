import re,sys
HINT='<p style="margin: 0 0 8px 0; font-size: 12.5px; color: #888; font-style: italic;">↔ deslize para ver a tabela completa</p>'
def go(path):
    b=open(path,encoding='utf-8').read(); orig=b
    out=[];pos=0;n=0
    for m in re.finditer(r'<div style="overflow-x: auto[^"]*">',b):
        pre=b[max(0,m.start()-140):m.start()]
        if 'deslize para ver' in pre: continue
        out.append(b[pos:m.start()]); out.append(HINT); out.append(m.group(0))
        pos=m.end(); n+=1
    out.append(b[pos:]); b=''.join(out)
    open(path,'w',encoding='utf-8').write(b)
    print(f'{path}: {n} avisos | {len(orig)} -> {len(b)}')
for p in sys.argv[1:]: go(p)
