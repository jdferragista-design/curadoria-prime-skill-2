from playwright.sync_api import sync_playwright
import json
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":900},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto("https://lista.mercadolivre.com.br/55au801",timeout=60000,wait_until="domcontentloaded")
    pg.wait_for_timeout(5000)
    pg.mouse.wheel(0,2500); pg.wait_for_timeout(2000)
    items=pg.eval_on_selector_all('a[href*="/MLB-"], a.poly-component__title',
        "els=>els.slice(0,25).map(e=>({t:(e.innerText||'').trim(),h:e.href}))")
    seen=[]
    for i in items:
        if i["t"] and i["h"] and not any(i["h"].split("?")[0]==s["h"].split("?")[0] for s in seen):
            seen.append(i)
    print("=== resultados ===")
    for i in seen[:10]: print(" -",i["t"][:95],"\n   ",i["h"].split("?")[0][:110])
    target=None
    for i in seen:
        if "AU801" in i["t"].upper() or "au801" in i["h"].lower(): target=i; break
    if not target and seen: target=seen[0]
    print("\n>>> alvo:",target["t"][:90] if target else None)
    if target:
        pg.goto(target["h"],timeout=60000,wait_until="domcontentloaded"); pg.wait_for_timeout(5000)
        print("PDP:",pg.title()[:100]); print("URL:",pg.url.split("?")[0])
        out["ml_url"]=pg.url.split("?")[0]; out["ml_title"]=pg.title()
        for _ in range(8): pg.mouse.wheel(0,4000); pg.wait_for_timeout(1000)
        for sel in ['[data-testid="rating-value"]','.ui-review-capability__rating__average','.ui-pdp-review__rating']:
            if pg.locator(sel).count(): out["avg"]=pg.locator(sel).first.inner_text(); break
        for sel in ['[data-testid="rating-total"]','.ui-review-capability__rating__label','.ui-pdp-review__amount','.total-opinion']:
            if pg.locator(sel).count(): out["count"]=pg.locator(sel).first.inner_text(); break
        print("média:",out.get("avg"),"| total:",out.get("count"))
        # abrir modal de todas opiniões
        for txt in ["Mostrar todas as opiniões","Ver todas as opiniões","Mostrar todos os comentários"]:
            try:
                l=pg.get_by_text(txt,exact=False).first
                if l.count(): l.click(timeout=5000); pg.wait_for_timeout(4000); print("abriu:",txt); break
            except Exception: pass
        for _ in range(5): pg.mouse.wheel(0,3000); pg.wait_for_timeout(900)
        cms=pg.eval_on_selector_all('[data-testid="comment-content-component"], .ui-review-capability-comments__comment__content',
            "els=>els.map(e=>e.innerText.trim()).filter(t=>t.length>15)")
        out["comments"]=cms
        print("\n=== comentários:",len(cms),"===")
        for c in cms[:14]: print("  •",c.replace("\n"," ")[:230])
        open("/home/user/.smoke/_ml_pdp.html","w",encoding="utf-8").write(pg.content())
    b.close()
json.dump(out,open("/home/user/.smoke/_ml.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
