import asyncio
from playwright.async_api import async_playwright
TPL = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#333;line-height:1.75}
.site{max-width:760px;margin:0 auto;padding:16px}img{max-width:100%%;height:auto}</style>
</head><body><div class="site post-content">%s</div></body></html>"""
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        open('.smoke/_n.html','w',encoding='utf-8').write(TPL % open('correcoes/3523/CORPO-para-colar.html',encoding='utf-8').read())
        for w in (360,760):
            pg=await br.new_page(viewport={'width':w,'height':1200},device_scale_factor=2,is_mobile=(w==360))
            await pg.goto('file:///home/user/.smoke/_n.html'); await pg.wait_for_timeout(300)
            el=await pg.query_selector('h3:has-text("Como chegamos")')
            await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(250)
            await pg.screenshot(path='.smoke/nota-%d.png'%w); await pg.close()
        await br.close()
asyncio.run(main())
