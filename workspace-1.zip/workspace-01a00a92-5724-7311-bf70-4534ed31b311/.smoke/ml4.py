from playwright.sync_api import sync_playwright
import json
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
URL="https://www.mercadolivre.com.br/smart-tv-profissional-4k-55-lg-uhd-55au801-processador-7-ai-ger8-super-upscaling-google-cast-alexa-integrado-controle-ai-smart-magic-webos-25/p/MLB58587883"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":950},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto(URL,timeout=70000,wait_until="domcontentloaded"); pg.wait_for_timeout(5000)
    print("TITLE:",pg.title()[:110]); print("URL:",pg.url.split("?")[0]); out["url"]=pg.url.split("?")[0]
    for _ in range(10): pg.mouse.wheel(0,3500); pg.wait_for_timeout(900)
    for sel in ['[data-testid="rating-value"]','.ui-review-capability__rating__average','.ui-pdp-review__rating','.ui-review-capability-header__rating']:
        if pg.locator(sel).count(): out["avg"]=pg.locator(sel).first.inner_text().strip(); print("média:",out["avg"]); break
    for sel in ['[data-testid="rating-total"]','.ui-review-capability__rating__label','.ui-pdp-review__amount','.total-opinion']:
        if pg.locator(sel).count(): out["count"]=pg.locator(sel).first.inner_text().strip(); print("total:",out["count"]); break
    for txt in ["Mostrar todas as opiniões","Ver todas as opiniões","Mostrar todos os comentários","Ver mais opiniões"]:
        try:
            l=pg.get_by_text(txt,exact=False).first
            if l.count(): l.click(timeout=6000); pg.wait_for_timeout(4500); print("clicou:",txt); break
        except Exception: pass
    for _ in range(6): pg.mouse.wheel(0,3000); pg.wait_for_timeout(1000)
    cms=pg.eval_on_selector_all(
      '[data-testid="comment-content-component"], .ui-review-capability-comments__comment__content, article.ui-review-capability-comments__comment p',
      "els=>els.map(e=>e.innerText.trim()).filter(t=>t.length>12)")
    seen=[];  [seen.append(c) for c in cms if c not in seen]
    out["comments"]=seen
    print("\n=== comentários:",len(seen),"===")
    for c in seen[:16]: print("  •",c.replace("\n"," ")[:240])
    open("/home/user/.smoke/_ml_pdp.html","w",encoding="utf-8").write(pg.content())
    b.close()
json.dump(out,open("/home/user/.smoke/_ml.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
