<?php
// Reproduz a aritmetica do medidor mensal com o fuso do usuario.
date_default_timezone_set('UTC');
$TZ='America/Sao_Paulo'; // UTC-3

function current_time_mysql($tz){ $d=new DateTime('now',new DateTimeZone($tz)); return $d->format('Y-m-d H:i:s'); }

echo "=== 1. fuso: current_time (local) x gmdate (UTC) ===\n";
foreach(['2026-08-15 14:00','2026-08-31 22:30','2026-08-31 20:00','2026-09-01 01:00'] as $localStr){
  $local=new DateTime($localStr,new DateTimeZone($TZ));
  $gravado=$local->format('Y-m-d H:i:s');            // current_time('mysql')
  $utc=clone $local; $utc->setTimezone(new DateTimeZone('UTC'));
  $filtro=$utc->format('Y-m');                        // gmdate('Y-m')
  $conta = (strpos($gravado,$filtro)===0);
  printf("  local %s -> gravado %s | filtro UTC %s | conta no mes? %s\n",
    $localStr,substr($gravado,0,7),$filtro,$conta?'SIM':'NAO  <-- some do medidor');
}

echo "\n=== 2. custo real por modelo (23 campos do 3523) ===\n";
$cambio=5.45; $campos=23; $in_medio=556;
$modelos=[
 'deepseek-v4-flash'      => ['in'=>0.10,'out'=>0.30,'out_tok'=>200],
 'gemini-3.1-flash-lite'  => ['in'=>0.10,'out'=>0.40,'out_tok'=>200],
 'anthropic/claude-haiku-4.5'=>['in'=>1.00,'out'=>5.00,'out_tok'=>215],
];
foreach($modelos as $nome=>$m){
  $usd=($in_medio*$m['in']+$m['out_tok']*$m['out'])/1e6;
  printf("  %-28s R$ %.4f/campo · R$ %.2f/artigo · R$ %.2f nos 53 artigos\n",
    $nome,$usd*$cambio,$usd*$cambio*$campos,$usd*$cambio*$campos*53);
}

echo "\n=== 3. o card do usuario ===\n";
$tot=771; $in=556; $out=$tot-$in;
printf("  771 tokens = ~%d entrada + ~%d saida\n",$in,$out);
printf("  saida de %d tokens NAO bate no teto de 700 -> nao houve truncamento\n",$out);
printf("  custo informado R$ 0,0073 -> confere com haiku (calc: R$ %.4f)\n",
  (($in*1.0+$out*5.0)/1e6)*$cambio);
