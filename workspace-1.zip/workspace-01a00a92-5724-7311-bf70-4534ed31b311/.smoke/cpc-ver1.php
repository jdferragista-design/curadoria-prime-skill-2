<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";
$h=file_get_contents('/home/user/qcy3523.html');
$a=CPC_Rules::analisar($h);
foreach($a as $x){
  if($x['auto']) continue;
  echo "\n████ ".$x['regra']." (".$x['n']." campos)\n";
  foreach($x['ocorrencias'] as $i=>$o){
    if($i>1) { echo "   … (+".($x['n']-2).")\n"; break; }
    echo "\n  [".($i+1)."] COMO ESTÁ:\n      ".wordwrap($o['trecho'],86,"\n      ")."\n";
    echo "      tokens: ".implode(' · ',$o['tokens']);
    if(!empty($o['tambem'])) echo "   |  tambem: ".implode(',',$o['tambem']);
    echo "\n      CTX: ".wordwrap(mb_substr($o['contexto'],0,240,'UTF-8'),86,"\n           ")."\n";
  }
}
