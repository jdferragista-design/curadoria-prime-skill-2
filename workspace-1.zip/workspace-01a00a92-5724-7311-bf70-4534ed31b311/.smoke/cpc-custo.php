<?php
define('ABSPATH','/fake/wp/');
function esc_url($u){return $u;} function esc_attr($s){return htmlspecialchars($s,ENT_QUOTES);}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES);}
function home_url($p=''){return 'https://curadoriaprime.com'.$p;}
function current_user_can($c){return true;} function get_option($k,$d=array()){return $d;}
function wp_parse_args($a,$d){return array_merge($d,(array)$a);}
function wp_json_encode($d,$f=0){return json_encode($d,$f);} function __($s,$d=null){return $s;} function wp_parse_url($u,$c=-1){return parse_url($u);}
foreach(['plugin','rules','fixer','diff','editor'] as $c) require "/home/user/curadoria-conformidade/includes/class-cpc-$c.php";

$h=file_get_contents('/home/user/qcy3523.html');
$a=CPC_Rules::analisar($h);
$campos=0; $in=0; $out=0;
// overhead do prompt fixo, medido: ~230 tokens
foreach($a as $x){
  if($x['auto']) continue;
  foreach($x['ocorrencias'] as $o){
    $campos++;
    $tin = 230 + (mb_strlen($o['trecho'],'UTF-8')+mb_strlen($o['contexto'],'UTF-8'))/3.6;
    $in += $tin; $out += mb_strlen($o['trecho'],'UTF-8')/3.6*1.15;
  }
}
$cambio=5.45;
$modelos=['gemini-3.1-flash-lite'=>[0.25,1.50],'gpt-5-mini'=>[0.25,2.00],'deepseek-v4-flash'=>[0.064,0.129]];
printf("QCY 3523: %d campos editaveis (antes eram 26 ocorrencias)\n", $campos);
printf("tokens estimados: %d entrada / %d saida  (media %d in por campo)\n\n",$in,$out,$in/$campos);
foreach($modelos as $m=>$p){
  $usd = $in/1e6*$p[0] + $out/1e6*$p[1];
  printf("  %-24s artigo inteiro R$ %5.4f   por campo R$ %6.5f\n",$m,$usd*$cambio,$usd*$cambio/$campos);
}
