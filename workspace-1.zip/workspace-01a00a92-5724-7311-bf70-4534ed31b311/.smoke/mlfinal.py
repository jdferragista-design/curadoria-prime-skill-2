from playwright.sync_api import sync_playwright
import re,json
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
U="https://www.mercadolivre.com.br/noindex/catalog/reviews/MLB4615627273?objectId=MLB4615627273&siteId=MLB&isItem=true&noIndex=true"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":950},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    pg.goto(U,timeout=60000,wait_until="networkidle"); pg.wait_for_timeout(5000)
    t=pg.inner_text("body")
    open("/home/user/.smoke/_mlfinal.txt","w",encoding="utf-8").write(t)
    m=re.search(r'Resumo de opiniões gerado por IA\s*(.{60,900}?)(?:Avaliação \d de 5|Ordenar)',t,re.S)
    if m: out["resumo_ia"]=re.sub(r'\s+',' ',m.group(1)).strip(); print("RESUMO IA:\n ",out["resumo_ia"][:700])
    m=re.search(r'([\d\.]+)\s*avaliações',t); out["total"]=m.group(1) if m else None
    m=re.search(r'Avaliação ([\d,\.]+) de 5\. ([\d\.]+) opiniões',t)
    if m: out["nota"],out["opinioes"]=m.group(1),m.group(2)
    m=re.search(r'([\d\.]+)\s*comentários',t); out["comentarios"]=m.group(1) if m else None
    print("\nnota:",out.get("nota"),"| opiniões:",out.get("opinioes"),"| avaliações:",out.get("total"),"| comentários:",out.get("comentarios"))
    # barras da distribuição
    try:
        bars=pg.eval_on_selector_all('[class*="rating-levels"] li, [class*="rating__level"]',
            "els=>els.map(e=>e.getAttribute('aria-label')||e.innerText)")
        print("barras:",bars[:8]); out["barras"]=bars
    except Exception as e: print("barras err",e)
    b.close()
json.dump(out,open("/home/user/.smoke/_mlmeta.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
