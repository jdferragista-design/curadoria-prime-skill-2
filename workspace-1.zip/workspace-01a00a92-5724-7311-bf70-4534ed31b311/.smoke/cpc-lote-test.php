<?php
$ok=0;$fail=0;
function ok($c,$m){global $ok,$fail; if($c){$ok++;echo "  ok   $m\n";}else{$fail++;echo "  FALHA $m\n";}}
$js=file_get_contents('/home/user/curadoria-conformidade/assets/admin.js');
$ad=file_get_contents('/home/user/curadoria-conformidade/includes/class-cpc-admin.php');
$css=file_get_contents('/home/user/curadoria-conformidade/assets/admin.css');

echo "\n[1] o botao de lote existe e diz o custo antes\n";
ok(strpos($ad,'cpc-ia-lote')!==false,'botao de lote na tela');
ok(strpos($ad,'CPC_IA::estimativa( CPC_Plugin::setting')!==false,'mostra custo estimado ANTES de rodar');
ok(strpos($ad,'Nada é gravado até você salvar')!==false,'deixa claro que nao grava');
ok(strpos($ad,"data-total")!==false,'informa quantos trechos serao processados');
ok(strpos($css,'.cpc-lote')!==false,'tem estilo proprio');

echo "\n[2] comportamento do lote\n";
ok(strpos($js,'function sugerirUm')!==false,'chamada de um campo virou funcao reutilizavel');
ok(strpos($js,'function lote')!==false,'existe motor de lote');
ok(strpos($js,"'' === ta.value.trim()")!==false,'so preenche caixas VAZIAS (respeita o que voce digitou)');
ok(strpos($js,'proximo( i + 1 )')!==false,'sequencial, um por vez (evita 429 do provedor)');
ok(strpos($js,'loteRodando = false')!==false,'da para interromper no meio');
ok(strpos($js,'scrollIntoView')!==false,'acompanha visualmente o campo sendo preenchido');
ok(substr_count($js,'area.textContent = r.data.texto')>=1,'lote tambem espelha no DOM (sobrevive a copia)');

echo "\n[3] o lote nao burla nenhuma trava de gravacao\n";
ok(strpos($ad,"empty( \$_POST['confirmo'] )")!==false,'gravacao ainda exige confirmacao');
ok(strpos($ad,"check_admin_referer( 'cpc_editar_'")!==false,'gravacao ainda exige nonce');
ok(strpos($js,'cpc_editar')===false,'o JS do lote nao chama o handler de gravacao');
ok(strpos($js,"dados.append( 'action', 'cpc_sugerir' )")!==false,'lote so chama cpc_sugerir (leitura)');

echo "\n[4] fluxo de trabalho: quantos cliques\n";
$campos=23;
printf("     antes: %d cliques em 'Sugerir' + %d revisoes + 1 salvar = %d acoes\n",$campos,$campos,$campos*2+1);
printf("     agora: 1 clique em lote + %d revisoes + 1 salvar = %d acoes\n",$campos,$campos+2);
ok(($campos+2) < ($campos*2+1),'o lote reduz o numero de acoes pela metade');

echo "\n".str_repeat('=',52)."\n";
echo $fail? "❌ $fail FALHA(S)\n" : "✅ $ok TESTES PASSARAM\n";
exit($fail?1:0);
