import asyncio,sys
from playwright.async_api import async_playwright
URL='https://curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/?LSCWP_CTRL=NOCACHE'
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        for w in (360,390):
            pg=await br.new_page(viewport={'width':w,'height':900},device_scale_factor=2,is_mobile=True,has_touch=True)
            await pg.goto(URL,wait_until='domcontentloaded',timeout=90000)
            await pg.wait_for_timeout(3500)
            r=await pg.evaluate("""()=>{
              const de=document.documentElement;
              const bad=[];
              const inScroll=el=>{let p=el.parentElement;while(p){const o=getComputedStyle(p).overflowX;if(o==='auto'||o==='scroll')return true;p=p.parentElement;}return false;};
              document.querySelectorAll('body *').forEach(el=>{
                const b=el.getBoundingClientRect();
                if(b.width>0&&b.right>de.clientWidth+2&&!inScroll(el)) bad.push(el.tagName+'.'+(el.className||'').toString().slice(0,40)+' right='+Math.round(b.right));
              });
              return {sw:de.scrollWidth,cw:de.clientWidth,fora:bad.slice(0,8),n:bad.length,
                      words:document.body.innerText.split(/\s+/).length,h2:document.querySelectorAll('h2').length};
            }""")
            print(f"[{'OK ' if r['sw']<=r['cw']+1 else 'ESTOURA'}] @{w}px scrollW={r['sw']} clientW={r['cw']} fora={r['n']} h2={r['h2']} palavras={r['words']}")
            for f in r['fora']: print("    ",f)
            await pg.screenshot(path=f'.smoke/live4541-{w}.png',full_page=False)
            await pg.close()
        await br.close()
asyncio.run(main())
