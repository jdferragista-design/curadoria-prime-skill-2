from playwright.sync_api import sync_playwright
import json,re
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":1366,"height":900},
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
    pg=ctx.new_page()
    # segue o link social do usuário e vê onde para
    pg.goto("https://mercadolivre.com/sec/28LceQ9",timeout=60000,wait_until="domcontentloaded")
    pg.wait_for_timeout(6000)
    print("URL1:",pg.url[:130]); print("TITLE1:",pg.title()[:90])
    pg.mouse.wheel(0,2000); pg.wait_for_timeout(3000)
    open("/home/user/.smoke/_social.html","w",encoding="utf-8").write(pg.content())
    links=pg.eval_on_selector_all('a[href*="MLB"]',"els=>els.slice(0,20).map(e=>({t:(e.innerText||'').trim().slice(0,70),h:e.href.split('?')[0]}))")
    print("links MLB na página social:",len(links))
    for l in links[:12]: print("   -",l["t"][:60],"|",l["h"][:95])
    # tenta clicar no card do produto
    try:
        card=pg.locator('a[href*="MLB"]').first
        if card.count():
            card.click(timeout=8000); pg.wait_for_timeout(6000)
            print("\nApós clique -> URL:",pg.url.split('?')[0]); print("TITLE:",pg.title()[:100])
    except Exception as e: print("clique falhou:",e)
    b.close()
