from playwright.sync_api import sync_playwright
import json,re
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--disable-blink-features=AutomationControlled","--disable-features=IsolateOrigins,site-per-process"])
    ctx=b.new_context(user_agent=UA,locale="pt-BR",viewport={"width":390,"height":844},
        is_mobile=True,has_touch=True,
        extra_http_headers={"Accept-Language":"pt-BR,pt;q=0.9"})
    ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
    pg=ctx.new_page()
    # entra pela home primeiro (cria cookies) e depois navega para o produto
    pg.goto("https://www.mercadolivre.com.br/",timeout=60000,wait_until="domcontentloaded")
    pg.wait_for_timeout(4000)
    print("home:",pg.title()[:60])
    pg.goto("https://www.mercadolivre.com.br/p/MLB58587883",timeout=60000,wait_until="domcontentloaded")
    pg.wait_for_timeout(6000)
    print("PDP title:",pg.title()[:110]); print("PDP url:",pg.url.split("?")[0])
    if "verification" in pg.url:
        print("!! bloqueado")
    else:
        for _ in range(12): pg.mouse.wheel(0,3000); pg.wait_for_timeout(800)
        txt=pg.inner_text("body")
        m=re.search(r'(\d[,\.]\d)\s*\n?\s*\(?([\d\.]+)\s*(?:opini|avalia)',txt)
        print("regex nota:",m.groups() if m else None)
        for sel in ['[data-testid="rating-value"]','.ui-review-capability__rating__average','.ui-pdp-review__rating']:
            if pg.locator(sel).count(): out["avg"]=pg.locator(sel).first.inner_text().strip(); print("média:",out["avg"]); break
        for sel in ['[data-testid="rating-total"]','.ui-review-capability__rating__label','.ui-pdp-review__amount']:
            if pg.locator(sel).count(): out["count"]=pg.locator(sel).first.inner_text().strip(); print("total:",out["count"]); break
        cms=pg.eval_on_selector_all('[data-testid="comment-content-component"], .ui-review-capability-comments__comment__content',
            "els=>els.map(e=>e.innerText.trim()).filter(t=>t.length>12)")
        seen=[]; [seen.append(c) for c in cms if c not in seen]
        out["comments"]=seen
        print("comentários:",len(seen))
        for c in seen[:16]: print("  •",c.replace("\n"," ")[:230])
        open("/home/user/.smoke/_ml_pdp.html","w",encoding="utf-8").write(pg.content())
    b.close()
json.dump(out,open("/home/user/.smoke/_ml.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
