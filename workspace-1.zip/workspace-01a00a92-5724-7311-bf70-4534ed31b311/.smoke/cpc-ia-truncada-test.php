<?php
// Testa o caminho da resposta truncada SEM chamar a rede: reimplementa as
// funcoes puras exatamente como estao em class-cpc-ia.php.
$ok=0;$fail=0;
function ok($c,$m){global $ok,$fail; if($c){$ok++;echo "  ok   $m\n";}else{$fail++;echo "  FALHA $m\n";}}

$src=file_get_contents('/home/user/curadoria-conformidade/includes/class-cpc-ia.php');

// extrai os corpos reais para garantir que o teste segue o codigo
preg_match('/private static function parece_completo\(.*?\n\t\}/s',$src,$m1);
preg_match('/private static function orcamento_saida\(.*?\n\t\}/s',$src,$m2);
eval('class F { '.$m1[0]."\n".$m2[0].' public static function pc($t){return self::parece_completo($t);} public static function os($t){return self::orcamento_saida($t);} }');

echo "\n[1] deteccao de frase cortada\n";
$cortada='Analisamos o fone com base em ficha técnica, comparação de especificações, avaliações verificadas de compradores e análises publicadas. Sem teste físico, não podemos concluir sobre conforto real, eficácia do ANC';
ok(!F::pc($cortada), 'o texto REAL que voce recebeu e reprovado como incompleto');
ok(F::pc('Analisamos o fone com base na ficha técnica do fabricante.'), 'frase terminada em ponto passa');
ok(F::pc('Vale a pena? Depende do uso!'), 'termina em exclamacao passa');
ok(F::pc('<p>Analisamos com base na ficha técnica.</p>'), 'aceita fechamento de tag HTML');
ok(F::pc('{"@type":"Person","name":"Cristiano Martins"}'), 'JSON-LD nao exige ponto final');
ok(!F::pc('e a maioria dos que custam até R$'), 'corte apos cifrao reprovado');
ok(!F::pc('Reescreva usando faixa de preço em vez de'), 'corte apos preposicao reprovado');
ok(F::pc('Faixa usual em agosto/2026: R$ 169 a R$ 186.'), 'preco com data passa');

echo "\n[2] orcamento de saida proporcional\n";
$curto='Testamos por 30 dias.';
$medio='Testamos o fone em uso diário por mais de duas semanas: chamadas no Google Meet e WhatsApp, transporte público, academia, home office e sessões longas de música.';
$longo=str_repeat('bloco de schema bem grande com muitos campos ',60);
ok(F::os($curto)===700, 'trecho curto usa o piso de 700 ('.F::os($curto).')');
// O trecho do 3523 tem ~45 tokens: 700 ja era MUITO mais que suficiente.
// Prova de que o corte foi raciocinio, nao falta de orcamento.
ok(F::os($medio)===700, 'trecho do 3523 cabe folgado no piso ('.F::os($medio).' para ~45 tokens de texto)');
ok(F::os($longo)<=3000, 'trecho enorme respeita o teto de 3000 ('.F::os($longo).')');
$ent=(int)ceil(mb_strlen($medio,'UTF-8')/3.6);
ok(F::os($medio) >= $ent*2, 'sobra folga sobre o tamanho do trecho ('.F::os($medio)." vs entrada $ent)");

echo "\n[3] o codigo pede desligamento de raciocinio e le finish_reason\n";
ok(strpos($src,"'reasoning'   => array( 'enabled' => false )")!==false, "envia reasoning.enabled=false");
ok(strpos($src,"'length' === \$req['finish']")!==false, 'trata finish_reason = length');
ok(strpos($src,'reasoning_tokens')!==false, 'le reasoning_tokens do usage');
ok(strpos($src,"cpc_ia_truncada")!==false, 'tem erro dedicado para truncamento');
ok(preg_match('/if \( \'length\' === \$req\[\'finish\'\] \) \{\s*self::registrar_uso/s',$src)===1,
   'chamada truncada AINDA e cobrada no medidor mensal');
ok(strpos($src,"'' === trim( (string) \$content ) && 'length' !== \$finish_reason")!==false,
   'vazio-por-truncamento nao vira "nao devolveu resposta"');

echo "\n".str_repeat('=',52)."\n";
echo $fail? "❌ $fail FALHA(S)\n" : "✅ $ok TESTES PASSARAM\n";
exit($fail?1:0);
