from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); 
    for w,n in [(800,"desk"),(390,"mob")]:
        pg=b.new_page(viewport={"width":w,"height":900})
        pg.goto("file:///home/user/.smoke/prev.html"); pg.wait_for_timeout(600)
        pg.screenshot(path=f"/home/user/.smoke/ps-{n}.png",full_page=True)
        print(n,pg.evaluate("document.body.scrollWidth"),"scrollW vs",w)
    b.close()
