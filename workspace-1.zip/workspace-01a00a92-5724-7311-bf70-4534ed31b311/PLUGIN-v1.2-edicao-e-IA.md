# Conformidade Editorial v1.2.0 — edição no plugin + IA opcional

Pacote: `/home/user/curadoria-conformidade.zip` (16 arquivos)
Testes: 35 regras ✅ · 25 log ✅ · **21 editor ✅ (novos)** · boot 7 classes ✅

---

## 1. O campo de edição — sim, dá

Cada ocorrência que **exige reescrita sua** virou uma linha de duas colunas na tela de revisão:

```
┌─ COMO ESTÁ ────────────────────┬─ COMO DEVE FICAR ───────────────┐
│ "testamos o fone por 3 semanas"│ [ caixa de texto editável      ]│
│ …contexto ao redor do trecho…  │ [Sugerir com IA] [copiar orig.] │
└────────────────────────────────┴─────────────────────────────────┘
```

Preenche o que quiser, deixa em branco o que não quer mexer, marca a confirmação e salva. Não precisa mais abrir o Gutenberg e caçar o trecho.

**A trava que importa.** A substituição é literal e ancorada. Se o trecho não aparecer **exatamente uma vez** no conteúdo, a troca é **recusada** — não adivinha. Isso cobre dois riscos reais:

- trecho repetido no artigo → trocaria a ocorrência errada
- conteúdo editado desde a varredura → trocaria em cima de texto que já mudou

A recusa vai para o **Relatório de falhas** com o motivo, e o resto do lote é aplicado normalmente.

Há também uma âncora tolerante: se o detector achou `testamos o fone` mas no banco está `testamos <strong>o fone</strong>` ou com `&nbsp;`, ele ainda casa — **desde que continue sendo uma única correspondência**.

Depois de montar o novo conteúdo, ele passa pela mesma `CPC_Diff::validar()` de sempre: bloqueia se perderia imagem, link, mais de 10% do texto visível ou quebraria um JSON-LD válido. E cria revisão antes de gravar.

---

## 2. A IA — dois campos de API, igual ao otimizador de imagem

Portei a arquitetura do `AI Image Optimizer`: **OpenRouter + Cline**, com fallback automático se o primário falhar.

**Configurações → Conformidade:**

| Campo | Observação |
|---|---|
| Ativar | liga/desliga o botão nas telas |
| Provedor primário | OpenRouter ou Cline |
| Fallback | se falhar, tenta o outro |
| Chave OpenRouter | gravada mascarada; em branco = mantém a atual |
| Modelo OpenRouter | padrão `google/gemini-3.1-flash-lite` |
| Chave / Modelo Cline | idem |
| Temperatura | 20/100 — literal, previsível |
| **Teto mensal** | R$ 20 padrão. Ao atingir, o botão para de funcionar |
| Câmbio | centavos por US$ 1, para converter o custo |

**A IA nunca grava.** Ela preenche a caixa de texto e para. Você lê, edita se quiser, e só então aprova. Isso é deliberado: o histórico deste projeto tem acusações falsas demais para dar caneta a um modelo.

O prompt é específico por regra. Em `alegacao_teste`, por exemplo, ele já instrui: *"se o trecho for uma negação (ex.: 'não testamos'), ele está CORRETO — responda [OK]"*, que é exatamente o falso positivo que a gente identificou no artigo do Dia dos Pais.

---

## 3. O custo — medido, não estimado

O plugin registra **cada chamada**: tokens de entrada, saída, custo em US$ (vem do próprio OpenRouter no campo `usage.cost`), convertido para R$. A tela mostra o total do mês e a média por trecho.

Perfil real de uma chamada: **~610 tokens de entrada, ~120 de saída** (mando só o trecho + contexto, não o artigo inteiro).

Projeção sobre **o seu CSV de hoje**:

| Modelo | R$/trecho | **62 trechos manuais** | + os 497 preços |
|---|---|---|---|
| `gemini-3.1-flash-lite` | 0,0018 | **R$ 0,11** | R$ 1,01 |
| `gpt-5-mini` | 0,0021 | R$ 0,13 | R$ 1,20 |
| `gemini-3.7-flash` | 0,0025 | R$ 0,15 | R$ 1,38 |
| `deepseek-v4-flash` | 0,0003 | R$ 0,02 | R$ 0,17 |

**Consertar os 62 achados graves manuais do site inteiro custa cerca de 11 centavos.** Mesmo passando IA nas 559 ocorrências, não chega a R$ 1,50.

Os **92 automáticos** (`schema_agg` 45 + `schema_autor` 38 + `sponsored` 9) continuam **custando zero** — são regex e DOM, nunca chamam IA.

### Por que não mandar o artigo inteiro
Testei os seus HTMLs: o corpo tem 15 a 30 mil tokens. Reescrever artigo inteiro daria ~R$ 0,10–0,13 por artigo (R$ 5 a 7 no site todo) — ainda barato, mas o problema não é preço: é que ninguém revisa um artigo reescrito de ponta a ponta. Trecho a trecho você aprova o que entende.

---

## 4. Ordem sugerida para o teste

1. Instalar o ZIP (sobrescreve a 1.1.0, configurações preservadas)
2. Configurações → colar a chave OpenRouter → modelo `google/gemini-3.1-flash-lite` → teto R$ 20
3. Abrir o **3002 — LG 55AU801** (7 graves: 6 `alegacao_teste` + schema). É o irmão de 55″ do que você já fechou, então dá para comparar a sugestão da IA com a reescrita que você mesmo fez no 50″
4. Clicar em **Sugerir com IA** num trecho só e olhar o custo que aparece embaixo
5. Se aprovar o padrão, seguir nos outros 5 e salvar

Depois disso a tela de Configurações mostra o gasto real acumulado — aí a conta deixa de ser projeção minha.

---

## 5. O que **não** mudou

- Os 10 detectores continuam idênticos. **A v1.1.1 pendente não entrou aqui**: filtro de negação no `alegacao_teste` e aspas curvas no `urgencia_falsa` seguem em aberto. Achei melhor não misturar mudança de detector com mudança de fluxo — se o placar mudar, você não saberia qual dos dois causou.
- O `preco_sem_data` continua barulhento (497 de 651). A calibração para aceitar faixa de preço + data global no topo é a próxima da fila.
