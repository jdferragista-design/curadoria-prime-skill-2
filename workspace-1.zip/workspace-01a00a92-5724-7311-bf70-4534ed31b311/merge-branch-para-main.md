# Promover `arena/019ff772-ai-skill` para `main`

Repo: `github.com/jdferragista-design/Ai-skill`
Diagnóstico feito em 13/08/2026 com clone **completo** e um merge de teste executado localmente.

---

## 1. O que realmente está acontecendo

O aviso do GitHub — *"33 commits ahead, 1 commit behind"* — parece perigoso e não é. Levantei o estado real:

| | `main` | `arena/019ff772-ai-skill` |
|---|---|---|
| Commits | 2 | 34 |
| Arquivos versionados | **2** | **28** |
| Último commit | 12/08 17:54 | 13/08 02:01 |
| Conteúdo | `README.md` + `regras_editoriais_ia_curadoria_prime.md` | tudo: skills, articles, ledger, templates |

**A `main` está praticamente vazia.** Ela tem só o README e o arquivo de regras. Todo o trabalho — as duas skills, os 4 artigos, o LEDGER de preços, os templates — existe exclusivamente na branch.

### Por que diz "1 commit behind"

A `main` tem um commit (`7e6c31c`, "Add files via upload") que a branch não tem no histórico. Ele fez uma coisa só: adicionou `regras_editoriais_ia_curadoria_prime.md`.

Só que a branch **também** adicionou esse mesmo arquivo, por conta própria, no commit `6edd459` ("Align curadoria-review skill with editorial rules v1.0"). Conferi o hash do blob nos dois lados:

```
main:   250f5dfa5ab388b9bd6207dacde579123201c969
branch: 250f5dfa5ab388b9bd6207dacde579123201c969
```

Idênticos, byte a byte. O "1 commit behind" é puramente genealógico: dois caminhos diferentes chegaram ao mesmo arquivo. **Não há divergência de conteúdo em lugar nenhum.**

### Merge de teste — executado, não estimado

Rodei o merge localmente antes de te recomendar qualquer coisa:

```
exit=0
conflitos: nenhum
arquivos após merge: 28
diff entre o merge e a branch: vazio
```

Zero conflitos, e o resultado é **exatamente** a árvore da branch. Nada da `main` sobrevive porque nada da `main` é diferente. Você pode promover sem medo.

---

## 2. Caminho recomendado: Pull Request pela interface

É o caminho certo aqui — não porque seja mais seguro que a linha de comando, mas porque deixa registro. Você ganha uma página permanente descrevendo o que entrou e por quê, e isso importa num repo que é a fonte canônica de regras editoriais.

### Passo a passo

1. Abra `https://github.com/jdferragista-design/Ai-skill`
2. O GitHub deve mostrar uma faixa amarela: *"arena/019ff772-ai-skill had recent pushes"* → clique em **Compare & pull request**.
   Se a faixa não aparecer: aba **Pull requests** → **New pull request** → base: `main`, compare: `arena/019ff772-ai-skill`.
3. Confirme que aparece **"✓ Able to merge"** em verde. Vai aparecer — testei.
4. Título e descrição sugeridos:

```
Promover skills de curadoria editorial para main

Traz para a main todo o conteúdo operacional do projeto, que até
agora existia apenas nesta branch:

- skills/curadoria-review/ — SKILL.md + 7 references + 4 assets
- skills/curadoria-mercado/ — gate de verificação de SKU + LEDGER.csv
- articles/ — 4 artigos de referência já conformes às regras
- regras_editoriais_ia_curadoria_prime.md como fonte canônica

A main continha apenas README + o arquivo de regras. O arquivo de
regras é idêntico nos dois lados (mesmo blob 250f5df), então o
merge não tem conflitos.
```

5. **Create pull request** → **Merge pull request**.
6. Escolha **"Create a merge commit"** (não Squash). Os 34 commits contam a evolução do raciocínio editorial — a criação do gate de mercado, o recuo nas alternativas de tablet, o ledger de preços. Esse histórico é documentação. Squash apagaria tudo isso num commit só.
7. **NÃO** clique em "Delete branch" ainda. Veja a seção 4.

---

## 3. Alternativa: linha de comando

Se preferir terminal, é este o comando — e ele reproduz exatamente o que testei:

```bash
git clone https://github.com/jdferragista-design/Ai-skill.git
cd Ai-skill

git checkout main
git pull

git merge --no-ff origin/arena/019ff772-ai-skill \
  -m "Promover skills de curadoria editorial para main"

# confira antes de enviar — deve listar 28 arquivos
git ls-files | wc -l

git push origin main
```

O `--no-ff` força um commit de merge explícito, deixando visível na árvore que houve uma promoção de branch.

**Não use `git clone --depth 1`.** Já caí nessa nesta sessão: o clone raso trunca o histórico para 1 commit e inviabiliza qualquer operação de merge.

---

## 4. Depois do merge — três ajustes que valem a pena

### 4.1 Os dois arquivos sem extensão

Estes dois estão na raiz e não têm extensão nenhuma:

```
modelo-2-Power-Bank-no-Avião
modelo-layout-da-Apple-TV-4K.
```

São HTML de ~60 KB cada. Sem extensão, o GitHub não os renderiza, `glob('*.html')` não os encontra e a trava de conformidade os ignora silenciosamente — que é o pior tipo de falha, a que não avisa. O segundo ainda termina em ponto solto, o que quebra ferramentas em alguns sistemas de arquivos.

```bash
git mv "modelo-2-Power-Bank-no-Avião" \
       skills/curadoria-review/references/modelo-power-bank-aviao.html
git mv "modelo-layout-da-Apple-TV-4K." \
       skills/curadoria-review/references/modelo-layout-apple-tv-4k.html
git commit -m "Mover modelos de layout para references com extensão .html"
```

Aproveitei para tirar os acentos dos nomes — nome de arquivo com acento e espaço é fonte recorrente de dor em pipeline.

### 4.2 Não apague a branch imediatamente

A branch `arena/` é o registro de origem deste trabalho. Depois do merge ela vira redundante em conteúdo, mas ainda serve como âncora. Deixe uma semana; se nada quebrar, aí sim delete — o histórico já estará na `main` de qualquer forma.

### 4.3 Proteja a `main`

Agora que a `main` deixa de ser um esqueleto e passa a ser a fonte canônica das regras editoriais, vale ligar a proteção: **Settings → Branches → Add rule** → `main` → marque *"Require a pull request before merging"*.

O motivo é concreto: as regras nesse repo são o que impede um artigo com alegação falsa de teste de ser publicado. Alteração acidental nelas tem custo real — CDC art. 37, penalização de spam do Google. Vale a fricção de um PR.

---

## 5. Ordem em relação às outras pendências

Faça o merge **antes** de começar a fusão descrita em `avaliacao-ai-skill-vs-kit.md`. O motivo é prático: aquele plano propõe adicionar `tools/` e `audit/` ao repo. Se você adicionar isso na branch, cria um segundo ciclo de promoção. Se a `main` já estiver completa, `tools/` entra direto por PR próprio, com histórico limpo.

Sequência:

1. **Merge da branch para a `main`** ← este documento
2. Renomear os dois arquivos sem extensão (4.1)
3. Proteger a `main` (4.3)
4. Aí sim, abrir o PR de `tools/` com os scripts corrigidos
