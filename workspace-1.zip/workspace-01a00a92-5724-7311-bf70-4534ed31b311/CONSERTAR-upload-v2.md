# Conserto do upload da v2 — 3 passos no navegador

## O que aconteceu

Os arquivos subiram **íntegros** (md5 `95b5bf72…`, idêntico ao que gerei aqui) no
commit `c46aa6c`, merged pelo PR #3. `main` agora é `2f4c1f2`, 41 arquivos.

Mas foram para a **raiz**, não para `tools/`. O resultado:

```
/corrigir_artigos-PATCHED.py     ← v2 (correta, mas ninguém executa esse caminho)
/corrigir_artigos-v2.patch       ← o diff, que não é código
/tools/corrigir_artigos.py       ← v1 INTACTA — é esta que roda
```

Confirmado: `tools/corrigir_artigos.py` tem **zero** ocorrências de `context=edit`
e ainda tem `check_hostname = False` / `CERT_NONE` nas linhas 74-75. É a v1.

**O risco agora é maior do que antes do upload.** Antes havia uma versão só, e ela
era sabidamente perigosa. Agora existem duas, a correta está num caminho que
ninguém invoca, e o comando do prompt — `python3 tools/corrigir_artigos.py --aplicar` —
continua executando exatamente a versão que produz +355 `<br />` no post 2943.
Um upload que parece ter resolvido, e não resolveu, é pior que nenhum upload.

---

## Os 3 passos

Deixei o arquivo **já com o nome final** em `upload-para-tools/corrigir_artigos.py`.
Não precisa renomear nada.

### 1. Substituir `tools/corrigir_artigos.py`

No GitHub: abra `tools/corrigir_artigos.py` → ícone de lápis (**Edit this file**) →
selecione tudo (`Ctrl+A`) → cole o conteúdo de `upload-para-tools/corrigir_artigos.py` →
**Commit changes**.

> Use *Edit this file*, **não** *Add files via upload*. Foi o upload que criou o
> problema da vez passada (os `lote-*`) e o desta vez. O editor grava no caminho
> exato do arquivo aberto; o upload grava onde o navegador acha que deve.

A `main` está protegida pelo ruleset `20804816` — o GitHub vai obrigar branch + PR.
É o comportamento esperado; siga o fluxo e faça o merge.

### 2. Apagar os dois arquivos da raiz

- `corrigir_artigos-PATCHED.py` → abrir → menu `⋯` → **Delete file**
- `corrigir_artigos-v2.patch` → idem

O `.patch` nunca deveria estar versionado (é artefato de revisão, não código), e
manter a `-PATCHED.py` na raiz garante que alguém rode a versão errada daqui a
duas semanas.

### 3. Conferir antes de executar qualquer coisa

Abra `tools/corrigir_artigos.py` no GitHub e verifique:

- [ ] cabeçalho diz **`v2 — CORREÇÕES CRÍTICAS`**
- [ ] busca por `context=edit` → **9 ocorrências**
- [ ] busca por `CERT_NONE` → aparece só dentro de `if _TLS_INSEGURO:`
- [ ] existem `def salvar_backup` e `def verificar_gravacao`
- [ ] a raiz **não** tem mais `corrigir_artigos-PATCHED.py` nem `.patch`

Se algum item falhar, pare e me diga qual.

---

## Depois disso, a sequência de execução não mudou

```bash
export WP_USER="..."
export WP_APP_PASSWORD="xxxx xxxx xxxx xxxx"   # senha de APLICAÇÃO, com os espaços

python3 tools/corrigir_artigos.py --dry-run --id 2943
```

Na saída, a linha que importa é:

```
📥 1 artigo(s) carregado(s) — fonte: content.raw
```

**Se disser `content.rendered`, pare** — a credencial não pegou, e é justamente
o cenário que a v2 recusa. Só depois de ver `raw`:

```bash
python3 tools/corrigir_artigos.py --aplicar --id 2943   # UM artigo
```

Confira o 2943 no navegador (grids e flex intactos). Só então o lote dos 15.

---

## Ainda pendente, sem relação com isto

- `articles/volta-às-aulas-2026-versão- antiga.html` — acento, espaço no meio do
  nome e "versão antiga" no que está versionado. Renomear ou remover quando sobrar
  tempo; não bloqueia nada.
- A desduplicação de `regras_editoriais_ia_curadoria_prime.md` ↔
  `skills/curadoria-review/references/regras-editoriais.md` segue adiada, como
  combinado, para depois das correções.
