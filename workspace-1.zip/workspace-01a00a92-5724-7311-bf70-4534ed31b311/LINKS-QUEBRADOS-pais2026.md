# Auditoria de links e preços — Dia dos Pais 2026

Verificado em 15/08/2026. **Corrigido após revisão do usuário.**

---

## ✅ Os 10 links de afiliado funcionam

Não há link quebrado no artigo. Meu diagnóstico anterior estava errado —
ver "Erro de análise" no fim deste arquivo.

### Mercado Livre (4 links, todos corretos)

Todos passam por `mercadolivre.com.br/social/6620250626180940`, que é a
**etiqueta de afiliado do Cristiano** (confirmada no painel do ML, campo
"Etiqueta em uso"). O produto de destino vai no parâmetro `ref=`, que é
diferente em cada link.

| Produto | Link | Destino confirmado | MLB |
|---|---|---|---|
| Galaxy Watch7 44mm | `meli.la/1LuqqHm` | Samsung Galaxy Watch7 44mm BT Galaxy AI Verde ✅ | MLB38058572 |
| Anker 737 PowerCore 24K | `meli.la/2uyvRWS` | Power Bank 24000mAh 140W Anker 737 Original ✅ | MLB25830218 |
| Soundcore Liberty 4 NC | `meli.la/2BweosK` | Soundcore Liberty 4 NC ANC 98,5% ✅ | MLB27021442 |
| JBL Wave Buds 2 | `meli.la/2JLLpU1` | JBL Wave Buds 2 preto ✅ | MLB43285968 |

O Apple Pencil Pro não tem link de ML — o artigo explica que não há anúncio
nacional confiável. Correto.

### Amazon (6 links, todos corretos)

Chegam ao produto certo com a tag `martins73-20` preservada.

| Produto | ASIN |
|---|---|
| Apple Pencil Pro | `B0D3J71RM7` |
| Galaxy Watch7 44mm | `B0D96V7WRB` |
| Anker 25K/165W (A1695, o "irmão") | `B0DMDJBCDP` |
| Soundcore Liberty 4 NC | `B0BZV8HLX3` |
| JBL Wave Buds 2 | `B0DHL63KWK` |

Observação de robustez (não é defeito): 4 deles usam `link.amazon`, que
redireciona por `amzlinks.in` — um encurtador de terceiros. Funciona hoje,
mas o destino final não está sob seu controle. Se quiser eliminar o
intermediário: `https://www.amazon.com.br/dp/<ASIN>?tag=martins73-20`.

---

## 🔴 O que realmente precisa de correção: preços

| Produto | No artigo (04/08) | Agora (15/08) | Δ |
|---|---|---|---|
| **Anker 737 (ML)** | R$ 649 c/ cupom | **R$ 628,93** (10× R$ 62,89) | 🔻 −R$ 20 — **ficou melhor** |
| Apple Pencil Pro (AMZ) | R$ 1.349,00 | **R$ 1.286,10** | 🔻 −R$ 62,90 |
| Galaxy Watch7 (AMZ) | R$ 1.399,00 | R$ 1.399,00 | = |
| Anker A1695 (AMZ) | R$ 748,99 | **R$ 759,05** | 🔺 +R$ 10 |
| Liberty 4 NC (AMZ) | R$ 379,05 | **R$ 407,55** | 🔺 +R$ 28,50 |
| JBL Wave Buds 2 (AMZ) | R$ 227,05 | **R$ 242,25** | 🔺 +R$ 15,20 |

O Anker no ML está **R$ 628,93**, com selo "OFERTA DO DIA" e "MAIS VENDIDO
11º", ainda sobre o mesmo preço de referência R$ 1.408. A recomendação
principal do artigo continua válida e ficou até mais barata.

**Estoque:** nada esgotado. Amazon com estoque baixo em dois: Watch7
("somente 8") e Wave Buds 2 ("somente 9").

---

## Pendências do artigo (fora links)

1. 🔴 **Data vencida** — CTAs dizem "ainda dá tempo de chegar antes do dia
   09/08" e "comprando até 04–05/08". Hoje é 15/08. Agrava porque o
   `dateModified` do schema é 15/08 (sinal de frescor + conteúdo vencido).
2. 🟠 **Contradição de teste** — "não testamos estas unidades fisicamente"
   vs. quatro ocorrências de "já testamos" / "testado por nós".
3. 🟡 **Fuso horário errado no schema** — Rank Math emite `+03:00`
   (Moscou); Brasil é `−03:00`. Afeta os 48 artigos → conferir timezone
   do WordPress.
4. 🟡 **Autor divergente** — `@graph` diz `"Cristiano"`, bloco manual diz
   `"Cristiano Martins"`. O plugin corrige automático.
5. 🟡 **Datas conflitantes** — bloco manual diz `dateModified 04/08`,
   `@graph` diz `15/08`.

---

## Erro de análise (registro)

**O que eu afirmei:** que os 4 links do ML iam todos para a mesma vitrine
genérica e não chegavam ao produto.

**Por que errei:** comparei apenas o *caminho* da URL final
(`/social/6620250626180940`), vi que era idêntico nos quatro e concluí que
o destino era o mesmo. O produto está no parâmetro `ref=` — que é distinto
em cada link e que eu havia imprimido na tela e ignorei. Bastava ler o
`og:title` de cada página baixada, o que confirmou quatro produtos
diferentes e corretos.

**Antes disso**, no mesmo artigo, eu já havia afirmado que o link do Anker
apontava para produto errado sem aviso — quando o artigo traz um "Alerta de
modelo cruzado" explícito (A1289 vs A1695), com specs, motivo e preço, além
de rotular o botão como "irmão A1695 · 25K".

**Regra para as próximas auditorias:** verificar destino por **conteúdo da
página** (og:title / título do produto), nunca por semelhança de URL. E ler
a seção inteira do artigo antes de acusar ausência de aviso.

---

## Referência: gerar link de afiliado no ML

Central de Afiliados: https://www.mercadolivre.com.br/afiliados/painel
Passo a passo: https://www.mercadolivre.com.br/l/comece-a-recomendar

Pela **Barra de Afiliados**: abrir a página do produto → Compartilhar →
copiar link ou ID. O painel entrega três coisas: link (`meli.la/…`),
**ID do produto** (ex.: `6DXYHY-VKKN` para o Anker 737) e texto sugerido.

Duas regras do programa que afetam o site:
- só divulgar em **canais declarados na conta** — confirmar que
  `curadoriaprime.com` está registrado;
- **informação desatualizada** é motivo explícito de suspensão, o que
  reforça a urgência dos itens 1 e 2 acima.
