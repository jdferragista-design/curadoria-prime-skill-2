# Prompt para o chat conectado ao repositório

Copie tudo abaixo da linha e cole no chat que tem acesso ao
`github.com/jdferragista-design/Ai-skill`.

---

Você trabalha no repositório `jdferragista-design/Ai-skill`, branch `main`
(atual `266aa9d`, 39 arquivos). Ele é o sistema editorial do site brasileiro
**curadoriaprime.com** — reviews de eletrônicos com links de afiliado Amazon e
Mercado Livre.

Responda sempre em português do Brasil.

## Contexto que você precisa aceitar como dado

O repositório tem **política editorial excelente e execução em débito**. Não faltam
regras: são 728 linhas, 16 seções e um checklist de bloqueio com 24 itens. O que falta
é aplicar o que já está escrito aos artigos publicados.

**Não escreva novas regras que já existem.** Antes de propor qualquer seção nova, use
`grep` no repositório para confirmar que ela realmente não existe. Erros desse tipo já
aconteceram nesta análise.

### O passivo real, medido em 13/08/2026

| Problema | Ocorrências | Artigos |
| --- | --- | --- |
| Alegação de teste físico que nunca ocorreu | 36 | 18 |
| Link de afiliado sem `rel="sponsored"` | 48 | 12 |
| Sem divulgação de afiliado | 10 | 10 |

O arquivo `audit/auditoria-48-artigos.csv` tem 27 linhas porque **lista somente os
artigos com defeito** — os outros 21 dos 48 passaram limpos. A auditoria está completa.
Não existe backlog de auditoria; existe backlog de correção.

Por que é urgente e não cosmético: afirmar "testamos" sobre produto não testado é
publicidade enganosa pelo **art. 37 do CDC**. Link de afiliado sem `rel="sponsored"` é
causa documentada de **ação manual** do Google, e o padrão mais próximo deste site —
review de afiliado com comparação gerada por IA, sem experiência de primeira mão —
sofreu perdas de 40 a 70% de tráfego no update de março de 2026.

### Restrição de layout que vale para todo HTML entregue

O WordPress roda `wpautop` no conteúdo. Ele insere `<br />` que viram **itens de grid e
de flex**, quebrando `grid-template-columns` e `flex-wrap`. Já destruiu o layout do post
4537: o índice de 12 itens virou um grid de 23 células e as 4 badges empilharam.

**Todo HTML destinado ao Editor de código do WordPress deve ser entregue em uma única
linha, sem nenhuma newline.** Sem quebra de linha, o `wpautop` não tem onde agir.

```python
s = re.sub(r'>\s*\n\s*<', '><', html.replace('\r\n', '\n'))
s = re.sub(r'\n+', ' ', s)
s = re.sub(r'[ \t]{2,}', ' ', s).strip()
```

---

## Tarefa 1 — Lote A: as 8 correções que o script resolve sozinho

Estes 8 artigos **não têm nenhuma alegação de teste falsa**. O problema é só `rel` e
divulgação de afiliado — o `tools/corrigir_artigos.py` resolve 100% sem tocar em uma
palavra do texto.

| ID | slug | links sem `sponsored` | sem divulgação |
| --- | --- | --- | --- |
| 3226 | `samsung-hw-b400f-vs-jbl-cinema-sb180-vs-lg-sqc1` | 9 | SIM |
| 3183 | `philips-50pug7019-review` | 6 | SIM |
| 3858 | `fire-tv-stick-4k-wifi-6` | 4 | — |
| 3033 | `good-vision-kit-cameras-wifi-review` | 3 | SIM |
| 2884 | `camera-lampada-360-yoosee-lp8177-review-2026` | 3 | SIM |
| 4254 | `redmi-note-15-pro-vale-a-pena` | 2 | — |
| 3835 | `xiaomi-smart-band-9-active-vale-a-pena` | 2 | — |
| 2943 | `garrafa-termica-quick-flip-stanley-710ml` | 0 | SIM |

Somam **29 dos 48 links defeituosos** e 5 das 10 divulgações ausentes. É a maior redução
de risco por unidade de esforço em todo o projeto.

Execute, nesta ordem, e mostre a saída de cada passo antes de seguir:

```bash
python3 tools/corrigir_artigos.py --dry-run --id 2943
python3 tools/corrigir_artigos.py --dry-run          # os 8, ainda simulando
```

Depois de eu conferir o dry-run, e **somente com `WP_USER` e `WP_APP_PASSWORD`
definidos**, aplicar um a um começando pelo 2943 (o de menor superfície):

```bash
python3 tools/corrigir_artigos.py --aplicar --id 2943
```

Após cada aplicação, revalidar o post publicado:

```bash
curl -s "https://curadoriaprime.com/wp-json/wp/v2/posts/2943" | python3 -c "..."
```

Confirme que os links ganharam `rel` e que **nada mais no HTML mudou**. Se o diff tocar
qualquer coisa além de `rel` e do bloco de divulgação, pare e me mostre.

## Tarefa 2 — post 4541, que é o mais grave individualmente

`/presentes-dia-dos-pais-2026-tech-premium/`. Três problemas simultâneos:

**a) 5 blocos de `aggregateRating` indevidos** (rating externo republicado como se fosse
do site — viola a §2.4 e é o padrão clássico de ação manual por *spammy structured
markup*). Remover os cinco:

| Produto | Nota | ratingCount |
| --- | --- | --- |
| Apple Pencil Pro | 4.6 | 9746 |
| Galaxy Watch7 | 4.9 | 9412 |
| Anker 737 | 4.9 | 878 |
| Soundcore Liberty 4 NC | 4.6 | 26873 |
| JBL Wave Buds 2 | 4.8 | 1364 |

**b) 2 alegações de teste.** Substituições exatas, já definidas:

- `Já testamos o Watch7 na bancada — leia nossa review completa`
  → `Analisamos o Watch7 em detalhe — leia nossa review completa`
- `Já testamos — leia nossa review completa do Liberty 4 NC`
  → `Analisamos ele em detalhe — leia nossa review completa do Liberty 4 NC`
- `Testamos os dois: leia as reviews completas`
  → `Analisamos os dois: leia as reviews completas`

**c) Checklist interno vazando no HTML publicado** — 4.099 caracteres, com 6 tokens
`PEND_`. Remover o comentário inteiro: de `<!--` imediatamente antes de
"Dia dos Pais 2026 = domingo 09/08/2026" até o `-->` depois de
"Bloco Sobre o autor com Person schema aprimorado".

Cuidado crítico ao editar: o artigo contém **tanto a alegação falsa quanto a ressalva
correta** de que não houve teste físico. **Remova a alegação, nunca a ressalva.** É fácil
fazer o inverso por distração, e o inverso é o pior resultado possível.

Entregue o resultado como HTML **sem nenhuma newline** e valide antes de me mandar:

```bash
python3 tools/checar_conformidade.py '4541-corrigido.html' --resumo
```

## Tarefa 3 — os dois artigos que concentram 36% do passivo textual

`3523` (QCY T13 ANC, **7 alegações**, termos: `testamos`, `unboxing`, `usamos o f…`) e
`3002` (LG 55AU801, **6 alegações**, termos: `depois de testar`, `testamos`, `te…`)
somam **13 das 36 alegações**. Estão há 150 e 208 dias sem revisão.

Gere o relatório de trechos e reescreva um a um, com revisão humana:

```bash
python3 tools/corrigir_artigos.py --relatorio-alegacoes --id 3523
```

Vocabulário de substituição já padronizado no `audit/README.md`:

| Em vez de | Escreva |
| --- | --- |
| "testamos" | "analisamos as especificações e cruzamos com relatos publicados por compradores" |
| "unboxing" | "o que vem na caixa" |
| "medimos" | "os dados oficiais indicam" |

Nunca substitua por algo que ainda implique posse do produto.

## Tarefa 4 — instalar a §17 (cadência de revisão)

Só depois das tarefas 1 a 3. Uma fila de revisão construída sobre 36 alegações falsas
mede a coisa errada: primeiro zere o passivo, depois instale o cronômetro.

O texto completo da §17 está no arquivo que estou anexando
(`secao-17-cadencia-revisao.md`). Ela fecha a única lacuna real de política: o repo diz
**como** atualizar (§12, 12 passos) e proíbe mexer em `dateModified` sem motivo (§9.4),
mas **nunca diz quando**. Enquanto isso, `tools/ledger.py` já define `DIAS_FRESCOR = 30`
e imprime "acima de 30 dias o preço não sustenta mais o bloco de compra" — a ferramenta
sabe que o preço morreu, a política editorial nunca é informada. Dos 27 artigos com
defeito, **19 estão acima de 90 dias e 13 passam de 180**.

### Armadilha de aplicação — leia antes de editar

`regras_editoriais_ia_curadoria_prime.md` e
`skills/curadoria-review/references/regras-editoriais.md` são **byte-idênticos**
(md5 `9f75c35bfd94f3998c444584a6dfa340`, 728 linhas cada). São duas cópias da mesma
fonte. Se você editar só uma, o repositório passa a ter duas versões divergentes da
política — que é exatamente o tipo de inconsistência que este projeto existe para
evitar.

Aplique a §17 nos **dois** arquivos, e confirme com `md5sum` que continuam idênticos
depois da edição.

O `skills/curadoria-review/assets/checklist-bloqueio.md` é um terceiro espelho, parcial.
Os 3 itens novos da §17.7 vão na seção "Atualização e SEO" dele também (linha 45).

Sugestão adicional, se você concordar: avalie transformar um dos dois arquivos de regras
em referência ao outro, em vez de manter cópia. Duplicação byte-a-byte é dívida técnica
que vai divergir na primeira edição apressada. Me diga o que acha antes de fazer.

### Código que a §17 pede

1. `tools/ledger.py` — novo subcomando `frescor`: cruza os SKUs do LEDGER com os artigos
   da coluna `artigo` e imprime o estado VERDE/AMARELO/VERMELHO de cada URL. A lógica de
   idade já existe; falta agregar por artigo em vez de por captura.
2. `tools/checar_conformidade.py` — nova checagem `[frescor]`: se o HTML tem `R$` em
   bloco de compra, exigir data de captura de até 90 dias no mesmo bloco.
3. `audit/revisoes.csv` — criar com o cabeçalho
   `data,url,nivel,gatilho,responsavel,o_que_mudou,dateModified_alterado`.
4. `audit/gsc/README.md` — criar a pasta e explicar o export mensal do Search Console.
5. `skills/curadoria-review/assets/fila-atualizacao.md` — acrescentar as colunas
   `estado`, `ultima_revisao`, `proxima_revisao`.

## Tarefa 5 — expandir o LEDGER de 8 para ~25 SKUs

O `skills/curadoria-mercado/assets/historico-precos/LEDGER.csv` tem 30 capturas cobrindo
apenas **8 SKUs**, todos de tablet, em 3 datas (30/07, 02/08, 12/08). Para 48 artigos no
ar, é cobertura de 17%.

Este é o ativo mais valioso do projeto e o menos explorado. É série histórica de preço
brasileiro por variante e por loja — **original research proprietário que nenhum
concorrente afiliado brasileiro publica.** O site não tem unidades para teste físico e a
§2.2 (as 8 evidências) impede corretamente que finja ter. Portanto a diferenciação
realista não é imitar RTings; é esta.

Priorize os SKUs pelos artigos de maior tráfego e maior valor de comissão, cobrindo os
clusters já existentes: TVs (`tv-e-home-theater` é o cluster mais forte do site),
soundbars, fones, smartphones. Uma captura por SKU por loja, com `--url` sempre
preenchido.

Lembre das travas que o `ledger.py` já aplica e que existem por bons motivos: recusa data
futura, captura sem preço, duplicata idêntica e URL de catálogo `/p/MLB…` — catálogo do
Mercado Livre não é anúncio, e o preço exibido pode ser de outro vendedor.

---

## Como quero que você trabalhe

- **Verifique antes de afirmar.** `grep` no repositório vence memória e vence suposição.
- **Um artigo por vez em qualquer coisa que toque o WordPress.** Mostre o diff, espere
  confirmação, aplique, revalide. Nunca em lote.
- **Nunca remova uma ressalva de honestidade** ao remover uma alegação falsa.
- **Não altere `dateModified`** em correção de `rel` ou de link — nada editorial mudou
  (§9.4). Só em revisão substancial.
- **Preserve URL e canonical** sempre (§12.2, passo 1).
- Se uma tarefa exigir credencial que não está no ambiente, **pare e diga** — não
  improvise nem simule sucesso.

## Dois falsos positivos conhecidos do checker — não "corrija" o artigo por causa deles

1. `[honestidade]` exige literalmente `não realizamos testes físicos|não recebemos
   (unidades|produtos)`. A frase real dos artigos — "não testamos esta unidade
   fisicamente" — não casa com o regex. **O regex está errado, o artigo está certo.**
   Relaxe o regex; não reescreva o texto.
2. `[fontes]` acusa ausência de links na seção "Fontes consultadas" em artigos que
   legitimamente não têm a seção ainda (§3.4).

## Estado atual, para você não refazer o que já está feito

- **Post 4537** (`/apple-tv-4k`): conteúdo já corrigido e no ar — 0 alegações,
  0 `aggregateRating`, checker com 0 erros, JSON-LD válido. **Pendente apenas** aplicar a
  versão sem newlines para consertar o layout quebrado pelo `wpautop`.
- **`main` está protegida** por ruleset: PR obrigatório, sem force-push, sem deleção.
  Trabalhe em branch e abra PR.
- A pauta de 90 dias (`audit/pauta-90-dias.csv`, 36 pautas de 18/08 a 18/12) fica
  **atrás** de tudo isso. Publicar conteúdo novo com 36 alegações falsas no ar aumenta a
  superfície de risco antes de reduzi-la. A única exceção defensável são os 6 guias de
  Black Friday a partir de 15/09, que têm data-limite real.

Comece pela Tarefa 1, passo do `--dry-run`, e me mostre a saída antes de aplicar
qualquer coisa.
