# ERRATA ao `PROMPT-repo-execucao.md` — leia ANTES de retomar a Tarefa 1

Três correções ao prompt que você recebeu. A terceira é bloqueante.

---

## 1. O erro de TLS era do seu ambiente, não do site

Você parou com:

```
urllib.error.URLError: <urlopen error TLS/SSL connection has been closed (EOF) (_ssl.c:992)>
```

e concluiu que a API estava inacessível. **Parar foi a decisão certa** — a regra de
não prosseguir quando a verificação remota falha funcionou como devia. Mas o
diagnóstico não se sustenta. Verificado de outro ambiente, no mesmo dia:

```
curl   → http=200 · tls=0 · 2,2 s · 39.374 bytes
urllib → 200 · slug garrafa-termica-quick-flip-stanley-710ml · 32.579 chars
```

`urllib` é a mesma biblioteca que o script usa. A API responde normalmente.
O `EOF` é bloqueio de rede/proxy **do ambiente onde você roda**.

Consequência prática: **não redesenhe o script por causa desse erro.** Se ele
reincidir, confirme com o `curl` acima antes de qualquer conclusão. A v2 já traz
retry com backoff e uma mensagem de erro que manda fazer exatamente essa checagem.

---

## 2. O lote não é de 8 artigos — são 15

O prompt dizia "Lote A: 8 artigos script-only". Errado, e o erro é meu.

Dry-run real, executado no repo limpo:

```
15 artigo(s) · 48 links corrigidos · 10 divulgações inseridas
```

Eu segmentei o lote pelos artigos *sem* alegação de teste físico. Mas o script
corrige `rel` e divulgação em **qualquer** artigo que precise, inclusive nos sete
que também estão na fila de reescrita manual: **3153, 3139, 3545, 2982, 3052,
2888, 2884**.

Lista completa dos 15 tocados: 3226, 3183, 3858, 3033, 2884, 4254, 3835, 2943,
3545, 3153, 3139, 3052, 2982, 2888 (+1).

Isso não impede a execução — só significa que sete artigos receberão a correção
mecânica **antes** da reescrita de texto. Tudo bem, desde que a reescrita
posterior parta do conteúdo já corrigido, e não de uma cópia velha.

---

## 3. 🔴 BLOQUEANTE — a v1 do script destrói o layout. Aplique a v2 primeiro.

### O defeito

`buscar_posts()` lê **sem autenticação**. A API então devolve só
`content.rendered`: o HTML **já processado pelo `wpautop`**, cheio de newlines e
`<br />`. Em seguida `atualizar_post()` faz `POST {"content": <esse mesmo HTML>}`.

O WordPress grava o rendered como se fosse fonte e roda `wpautop` **de novo**,
sobre um HTML que já tinha passado por ele. Medido sobre os posts reais:

| post | `<br>` antes | depois | delta | chars |
|------|-------------:|-------:|------:|------:|
| 2943 Stanley   | 10 | 365 | **+355** | +1.804 |
| 3226 soundbars | 35 | 526 | **+491** | +2.976 |
| 3183 Philips   |  2 | 268 | **+266** | +1.294 |

Amplificação de 26× a 134×. Grids e flex quebram — é exatamente o dano que já
custou duas rodadas de conserto no post 4537, multiplicado por 15.

**E seria irreversível:** sem `?context=edit` autenticado não existe forma de
recuperar o HTML-fonte depois que ele foi sobrescrito pelo rendered.

### A correção

Arquivo pronto e testado: **`corrigir_artigos-PATCHED.py`**
(diff em `corrigir_artigos-v2.patch`, ~276 linhas adicionadas).

Seis mudanças:

| | mudança | por quê |
|---|---|---|
| **A** | GET autenticado com `context=edit` → usa `content.raw` | lê o fonte, não o renderizado |
| **B** | sem `raw`, `--aplicar` **aborta** | nunca mais grava rendered de volta |
| **C** | backup do raw em `backups/` antes de cada POST | reversível |
| **D** | relê o post após gravar, compara `<br>`; se cresceu, **restaura o backup e interrompe o lote** | o dano para no primeiro artigo, não no décimo quinto |
| **E** | TLS volta a ser verificado; `--tls-inseguro` existe mas é incompatível com `--aplicar` | a v1 mandava a senha de aplicação por Basic Auth sem validar o certificado |
| **F** | paginação real (`per_page=25` + `X-WP-TotalPages`) | a v1 pedia `per_page=50` numa página só — com 48 artigos, estava a dois posts de truncar em silêncio |

Dois extras que apareceram na revisão do código:

- **`corrigir_divulgacao()` e o Gutenberg.** Se o post for Gutenberg, inserir
  `<div>` solto no meio de um bloco corrompe o parser e o editor marca o post
  como inválido. A v2 detecta `<!-- wp:` e embrulha o bloco em
  `<!-- wp:html -->…<!-- /wp:html -->`, cortando na fronteira do bloco.
  *Nos 4 posts inspecionados o conteúdo é HTML clássico, então o caminho
  Gutenberg não chega a ser exercitado — mas os 48 não foram todos verificados.*
- **`texto_visivel()` agora remove comentários HTML.** Sem isso, um checklist
  interno comentado (como os 4.099 chars do post 4541) entra na detecção de
  alegações e gera falso positivo.

### Validação já feita

Sintaxe OK. Guardas testadas: sem credencial → mensagem explicativa; 401 →
instrução sobre senha de aplicação (não traceback); `--tls-inseguro --aplicar` →
recusa. Transformação testada offline contra o HTML real de 2943 / 3226 / 3183 / 3858:

```
2943  sp=0 div=1  br 10->10  <a> 12->13  div 43/43->44/44
3226  sp=9 div=1  br 35->35  <a> 10->11  div 54/54->55/55
3183  sp=6 div=1  br  2-> 2  <a>  9->10  div  9/9 ->10/10
3858  sp=4 div=0  br 10->10  <a> 28->28  div 60/60->60/60
afiliados sem sponsored ao final: 0 em todos
```

`<br>` estável, `<div>` balanceado, nenhum link de afiliado sem `sponsored`.

### Como proceder

1. Substitua `tools/corrigir_artigos.py` pelo conteúdo de `corrigir_artigos-PATCHED.py`
   (branch + PR — a `main` está protegida pelo ruleset `20804816`).
2. Exporte `WP_USER` e `WP_APP_PASSWORD`. **A v2 exige credencial até no
   `--dry-run`**, porque sem auth não há `raw`.
3. `--dry-run --id 2943` primeiro. Confirme na saída: `fonte: content.raw`.
   Se aparecer `content.rendered`, **pare** — a credencial não pegou.
4. `--aplicar --id 2943`. Um artigo só. Confira o post no navegador.
5. Só então o lote dos 15.

Se em qualquer ponto a verificação pós-gravação disparar, o script já restaurou
o backup e parou sozinho. Não force com `--sem-verificacao`.

---

## 4. Sobre a desduplicação dos arquivos de regras — você está certo

Você recusou mexer na duplicação entre `regras_editoriais_ia_curadoria_prime.md` e
`skills/curadoria-review/references/regras-editoriais.md` (md5 idêntico
`9f75c35bfd94f3998c444584a6dfa340`, 728 linhas) antes das correções, pedindo
estratégia explícita de referência única primeiro.

Concordo, e a chamada é melhor que a minha. Reestruturar arquivo de regras no
meio de uma limpeza é trocar o pneu com o carro andando. **Fica para depois do
lote dos 15 e da reescrita manual.** Há ainda um terceiro espelho parcial em
`skills/curadoria-review/assets/checklist-bloqueio.md` (linha 45) a considerar
quando chegar a hora. Até lá: qualquer edição de regra vai nos **dois** arquivos.
