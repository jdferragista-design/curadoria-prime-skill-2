# 🔴 Achado — `aggregateRating` de terceiros em 32 artigos

Data: 13/08/2026 · descoberto ao auditar o post 2943 depois da remediação bem-sucedida.

---

## Resumo

| Problema | Alcance | Corrige |
|---|---|---|
| `aggregateRating` / `reviewCount` de terceiros no JSON-LD | **32 de 48** artigos (44 ocorrências) | script |
| `author.name` inconsistente no schema | **48** artigos (86 ocorrências, 5 variantes) | script |
| Alegação de teste na `description` do schema | **2** artigos (2943, 3523) | manual |
| JSON-LD malformado (não faz parse) | **2** artigos (3014, 3181) | manual |

---

## 1. O problema principal

O JSON-LD **manual** (dentro do conteúdo do post, logo após "Fontes Consultadas")
declara, no `Product` do nosso site:

```json
"aggregateRating": { "ratingValue": "4.8", "reviewCount": "17000" }
```

O `4.8 / 17.000` é da **Amazon**. Declarado assim, sem atribuição, afirma ao Google
que a coleta é nossa. É o que a **§2.4** proíbe e é a categoria de rich snippet que o
Google mais penaliza por dado não verificável.

Duas escalas convivendo denunciam a origem:

- **`/5`** — 4.6, 4.7, 4.8, 4.9 → copiadas do varejo
- **`/10`** — 8.0, 8.5, 9.2, 9.4 → nota editorial própria (legítima)

Casos extremos: `3548` declara **207.851** avaliações; `2982`, **132.756**.

### Decisão

**Remover** `aggregateRating`, `reviewCount` e `ratingCount`.
**Preservar** o bloco `review` com a nossa nota `/10` e `author: Curadoria Prime` —
essa é uma avaliação editorial própria e verdadeira.

Custo: perde a estrela no resultado de busca desses posts.
Ganho: elimina o risco de ação manual por structured data enganoso.

---

## 2. Autoria — 5 identidades para a mesma pessoa

| Ocorrências | `author.name` |
|---|---|
| 48 | `Cristiano` |
| 17 | `Cristian` |
| 10 | `Cristiano Martins` |
| 6 | `Curadoria Prime` |
| 4 | `Equipe Curadoria Prime` |

Fragmenta o sinal de autor para E-E-A-T. No 2943, o schema dizia
"Equipe Curadoria Prime" enquanto a assinatura visível dizia "Cristiano Martins".

**Padronizado para `Cristiano Martins`** em todo `@type: Person`.
`@type: Organization` (a marca, em `review.author`) **não** é tocado — ali
"Curadoria Prime" está correto.

---

## 3. Alegação de teste dentro do schema

Estas **não** eram detectadas: `listar_alegacoes` lê o texto visível, e
`texto_visivel()` apaga `<script>`. É pior que no corpo — a `description` é o que
alimenta o snippet do Google.

| post | campo | trecho |
|---|---|---|
| **3523** | description | "**Testamos por 30 dias**: ANC de 28dB, bateria de 30h…" |
| **3523** | description | "**Testamos** som, bateria, chamadas e cancelamento de ruído em 3…" |
| **2943** | description | "Review completo com **teste de isolamento** (24h+ com gelo)" |

CDC art. 37. O `3523` já era o pior da lista (7 alegações no corpo).
**Reescrita manual** — o script apenas reporta.

---

## 4. JSON-LD malformado — `3014` e `3181`

Não fazem parse como JSON. O script **pula e reporta**, deliberadamente:
reescrever JSON quebrado por regex é a mesma classe de erro que trouxe o `wpautop`
para cá. Corrigir à mão no editor.

---

## O que mudou no `corrigir_artigos.py`

Novas funções: `_blocos_jsonld`, `_limpar_rating`, `corrigir_schema`, `alegacoes_schema`.
Nova constante `AUTOR_CANONICO`. Nova flag `--pular-schema`.

Garantias mantidas: lê `content.raw`, backup antes de gravar, relê e compara `<br>`,
restaura sozinho se houver reprocessamento.

Verificado em simulação sobre os 48 HTML públicos: **`<br>` não mudou em nenhum**.

### Rodar

```bash
cd ~/Downloads/curadoria-prime-repo
export WP_USER="seu_login" WP_APP_PASSWORD="xxxx xxxx xxxx xxxx"

# 1) simular em um post já conhecido
python3 tools/corrigir_artigos.py --dry-run --id 2943

# 2) aplicar nesse post e conferir no Rich Results Test
python3 tools/corrigir_artigos.py --aplicar --id 2943

# 3) simular no lote
python3 tools/corrigir_artigos.py --dry-run

# 4) aplicar no lote
python3 tools/corrigir_artigos.py --aplicar
```

Conferir depois em <https://search.google.com/test/rich-results>:
o `Product` deve aparecer **sem** estrela agregada e **com** o bloco `review`.

---

## Nota de método

Este achado só apareceu porque o artigo foi auditado **depois** de corrigido,
com o `checar_conformidade.py` rodando contra o HTML **publicado** — não contra
o arquivo local. O `corrigir_artigos.py` reportou sucesso e estava certo: ele fez
o que se propunha. O bloqueio estava numa camada que ele não olhava.

**Rodar o checker contra o HTML no ar depois de cada lote**, não só antes.
