# Diagnóstico — Ai-image-optimizer-alt

Repo analisado: `github.com/jdferragista-design/Ai-image-optimizer-alt`, commit `643ffc8` ("Add files via upload", 1 commit).

---

## 🔴 O plugin, como está no GitHub, não ativa

O bootstrap procura os arquivos em subpastas:

```php
require_once AIIOA_DIR . 'includes/class-aiioa-plugin.php';
...
wp_enqueue_style( 'aiioa-admin', AIIOA_URL . 'assets/admin.css', ... );
```

Mas no repo os 13 arquivos estão **todos soltos na raiz**. Não existe `includes/` nem `assets/`.

Resultado ao ativar: `Fatal error: Failed opening required '.../includes/class-aiioa-plugin.php'` — tela branca.

### Causa

Foi o **upload web do GitHub**. É a mesma armadilha já registrada no `curadoria-prime-skill`: arrastar arquivos para a interface web achata a árvore de diretórios e descarta arquivos com ponto no nome (por isso também não há `.gitignore` no repo).

O código está correto. **A embalagem é que se perdeu.**

---

## ✅ Corrigido no workspace

Árvore remontada conforme o que o código espera:

```
ai-image-optimizer-alt/
├── ai-image-optimizer-alt.php      ← bootstrap (cabeçalho do plugin)
├── uninstall.php
├── readme.txt
├── README.md
├── includes/
│   ├── class-aiioa-plugin.php          247 linhas — singleton, settings, filtros de saída
│   ├── class-aiioa-article.php         448 — parser de <img> do conteúdo
│   ├── class-aiioa-openrouter.php      553 — OpenRouter + Cline + fallback
│   ├── class-aiioa-optimizer.php       310 — JPEG/PNG/WebP + backup + restore
│   ├── class-aiioa-admin.php           454 — Mídia → IA / Config → IA para Imagens
│   └── class-aiioa-article-admin.php   486 — Mídia → IA para Artigos + metabox
└── assets/
    ├── admin.css
    ├── admin.js
    └── article.js
```

### Validação executada

| Teste | Resultado |
|---|---|
| `php -l` nos 8 arquivos PHP | sem erros de sintaxe |
| `node --check` nos 2 JS | ok |
| Boot com stubs do WP | **BOOTSTRAP OK** |
| Classes carregadas | 6 de 6 |
| `AIIOA_Plugin::settings()` | 14 chaves, `qwen/qwen3.7-flash`, `pt-BR` |
| Hooks registrados | 5 filtros + 14 actions |

Entregável: **`/home/user/ai-image-optimizer-alt.zip`** (47 KB) — instalável direto em Plugins → Adicionar → Enviar plugin.

---

## O que o plugin faz bem (padrões a reaproveitar)

Revisão de segurança do que li:

- **`check_ajax_referer`** nos 10 endpoints AJAX
- **`current_user_can`** em duas camadas: `upload_files` / `manage_options` para a tela, e `edit_post` por objeto dentro do handler
- **Chave de API fora do banco** via constante do `wp-config.php`, com a constante prevalecendo sobre a opção
- **Backup antes de escrever** na imagem, com restore que recria as miniaturas
- **Nada é aplicado sozinho**: a IA só gera sugestão; gravar exige clique humano
- **Fallback entre provedores** com o resultado dizendo qual provedor e modelo responderam
- `uninstall.php` só apaga dados se o usuário marcou a opção

Esse último ponto é o mais relevante para o que vem a seguir: **o plugin foi desenhado com revisão humana obrigatória** — exatamente a postura que a política editorial do site exige.

---

## Por que isso importa para a Curadoria Prime

O `corrigir_artigos.py` e este plugin resolvem o mesmo problema por caminhos opostos:

| | `corrigir_artigos.py` | plugin WP |
|---|---|---|
| Onde roda | máquina local, Python | dentro do WP |
| Acesso | REST API com senha de aplicativo | direto no banco |
| Interface | linha de comando | painel do WP |
| Quando age | quando você lembra de rodar | pode agir no salvamento |
| Quem vê o resultado | terminal | editor, na tela do post |

O script é bom para **lote retroativo** (os 48 artigos). O plugin é bom para **não deixar entrar problema novo**.

A lacuna real hoje: cada post corrigido depende de mim gerar o HTML e você colar no editor de código. Isso não escala para 29 posts de schema.
