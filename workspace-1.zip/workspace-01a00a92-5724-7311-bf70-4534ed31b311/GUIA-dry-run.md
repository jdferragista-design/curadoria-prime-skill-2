# Guia — rodar o corretor de artigos (dry-run)

`tools/corrigir_artigos.py` v2 · post de teste: **2943**
Objetivo desta etapa: **simular** a correção em 1 artigo, conferir o resultado e só depois gravar.

---

## 0. O que este script corrige

Automático (mecânico, seguro):

1. `rel="sponsored"` ausente em link de afiliado → adiciona o `rel` completo
2. Divulgação de afiliado ausente → insere o bloco padrão no topo

**Não** corrige sozinho (muda o sentido do texto, exige reescrita humana):

3. Alegação falsa de teste físico ("testamos", "testei", "unboxing") → apenas **lista** os trechos

Escopo total medido no dry-run anterior: **15 artigos · 48 links · 10 divulgações**.

---

## 1. Pegar a senha de aplicativo

No WordPress: **Usuários → Perfil →** role até **"Senhas de aplicativo"** → dê um nome
(ex.: `remediacao-artigos`) → **Adicionar nova**.

| Variável | O que é | Cuidado |
|---|---|---|
| `WP_USER` | O **login** (`user_login`) | Não é o e-mail nem o apelido de exibição |
| `WP_APP_PASSWORD` | A **senha de aplicativo** | Não é a senha de entrar no site |

Três detalhes que derrubam gente:

- O WP mostra a senha **uma única vez**, no formato `AbCd 1234 EfGh 5678`. Copie na hora.
- **Os espaços fazem parte da senha.** Cole exatamente como veio.
- Por causa dos espaços, as **aspas são obrigatórias**.

O usuário precisa ter permissão de **edição** nos posts, senão a API devolve 403.

---

## 2. Os comandos

> **Antes:** se a pasta veio do ZIP com o nome `curadoria-prime-repo (1)`, **renomeie**.
> Os parênteses e o espaço são sintaxe do bash e quebram todo comando:
>
> ```bash
> cd ~/Downloads
> mv "curadoria-prime-repo (1)" curadoria-prime-repo
> ```
>
> **Rode sempre da raiz do repo, não de dentro de `tools/`.** A pasta `backups/` é um
> caminho relativo (linha 91: `Path(os.environ.get("WP_BACKUP_DIR", "backups"))`), então
> ela nasce onde você estiver. Da raiz vai para o lugar certo; de dentro de `tools/`
> viraria `tools/backups/`.

Dois comandos, **na mesma janela de terminal**, nesta ordem:

```bash
cd ~/Downloads/curadoria-prime-repo

export WP_USER="seu_login" WP_APP_PASSWORD="AbCd 1234 EfGh 5678"

python3 tools/corrigir_artigos.py --dry-run --id 2943
```

O que cada coisa faz:

- **`export`** — guarda o login numa variável de ambiente da sessão. Não imprime nada; é normal.
  Serve para a senha **não** ficar escrita dentro do `.py` (que está num repositório Git)
  nem aparecer no comando que roda o script.
- **`--dry-run`** — simulação. Lê, calcula o que mudaria, imprime e **não grava nada**.
  Pode rodar quantas vezes quiser.
- **`--id 2943`** — só o post 2943. Um artigo só, para conferir com calma antes do lote.

> ⚠️ O `export` vale **só naquela janela**. Fechou o terminal, tem que exportar de novo.
> Isso é proposital: a senha não fica gravada em disco.

---

## 3. A linha que você tem que conferir

Logo no início da saída aparece:

```
📥 1 artigo(s) carregado(s) — fonte: content.raw
```

| Se aparecer | Significa | O que fazer |
|---|---|---|
| `fonte: content.raw` | ✅ Autenticou. Está lendo o **fonte** do post. | Seguir |
| `fonte: content.rendered` | 🔴 Login não pegou. | **Parar.** Revisar `WP_USER` e a senha |
| `HTTP 401` / `HTTP 403` | Credencial rejeitada ou sem permissão de edição | Conferir login e gerar nova senha de aplicativo |

**Por que a v2 exige senha até no dry-run** — a API devolve o conteúdo de duas formas:

- `content.rendered` — HTML **já processado** pelo WP (o `wpautop` já rodou, já injetou `<br>`/`<p>`).
  É o que sai **sem login**.
- `content.raw` — o HTML **fonte**, como está no editor. Só sai com `?context=edit`,
  que **exige autenticação**.

A **v1 lia o rendered e gravava de volta**, então o WP rodava o `wpautop` **de novo** por cima
de HTML já processado. Medido em posts reais:

| post | `<br>` antes | `<br>` depois |
|---|---|---|
| 2943 | 10 | **365** |
| 3226 | 35 | **526** |
| 3183 | 2 | **268** |

Grid e flex quebram, e como o fonte nunca chegou a ser lido, **não havia como voltar atrás**.
Simular em cima do rendered daria um resultado mentiroso — daí a exigência de credencial
também no dry-run.

---

## 4. Guardas da v2 (o que impede um novo estrago)

| | Guarda |
|---|---|
| A | Lê `content.raw` via `context=edit`, nunca o renderizado |
| B | Sem `raw` disponível, `--aplicar` **aborta** |
| C | Salva o raw original em `backups/` **antes** de gravar |
| D | Depois de gravar, relê e compara a contagem de `<br>`; se cresceu, **restaura o backup e para o lote** |
| E | TLS verificado (a v1 mandava a senha sem validar certificado). `--tls-inseguro` existe, mas nesse modo o `--aplicar` é recusado |
| F | Paginação até o fim (a v1 pedia 50 numa página só, com 48 artigos — a dois posts de truncar em silêncio) |

---

## 5. Sequência completa

```bash
# 1) simular em 1 artigo
python3 tools/corrigir_artigos.py --dry-run --id 2943

# 2) conferir "fonte: content.raw" e ler o diff

# 3) gravar só esse artigo
python3 tools/corrigir_artigos.py --aplicar --id 2943

# 4) abrir o post no navegador e conferir visualmente
#    (layout, grid, tabelas, espaçamento — é aqui que o bug da v1 apareceria)

# 5) só então o lote dos 15
python3 tools/corrigir_artigos.py --dry-run
python3 tools/corrigir_artigos.py --aplicar

# 6) listar as alegações que exigem reescrita humana
python3 tools/corrigir_artigos.py --relatorio-alegacoes
```

> 🔴 **Nunca** rode `--aplicar` com a **v1** do script. A escrita da v2 ainda **não foi validada
> em produção** — por isso o artigo único primeiro, com conferência visual, antes do lote.

---

## 6. Depois de aplicar

Revalidar o que está no repositório:

```bash
cd ~/Downloads/curadoria-prime-repo
python3 tools/checar_conformidade.py 'articles/*.html' --resumo
python3 tools/ledger.py validar
```

Pendências que **não** são resolvidas por este script:

- **36 alegações de teste** em 18 artigos → reescrita manual.
  Começar por `3523` (QCY T13, 7 alegações) e `3002` (LG 55AU801, 6) — 13 das 36.
- Posts no ar que ainda precisam de passada: **4537** (apple-tv-4k) e **4541** (presentes-dia-dos-pais-2026).

---

## 7. Se der errado

| Sintoma | Causa provável |
|---|---|
| `❌ Defina WP_USER e WP_APP_PASSWORD no ambiente` | O `export` não rodou, ou você trocou de janela de terminal |
| `HTTP 401` | Login errado (usou e-mail?) ou senha de aplicativo digitada sem os espaços |
| `HTTP 403` | Usuário sem permissão de edição nos posts |
| `fonte: content.rendered` mesmo com credencial | Senha de aplicativo revogada, ou plugin de segurança bloqueando Basic Auth / a REST API |
| Layout quebrado depois do `--aplicar` | A guarda D deve ter restaurado sozinha. Confira `backups/` e me avise |
| `bash: erro de sintaxe próximo ao token inesperado '('` | O caminho tem parênteses/espaço (`curadoria-prime-repo (1)`). Renomeie a pasta — seção 2 |
| `cd: Arquivo ou diretório inexistente` | Caminho errado. Na sua máquina o repo está em `~/Downloads/curadoria-prime-repo` |
| `backups/` apareceu dentro de `tools/` | Você rodou de dentro de `tools/`. Rode da raiz do repo |

Cole aqui a **saída** do dry-run que eu analiso o diff junto com você.
