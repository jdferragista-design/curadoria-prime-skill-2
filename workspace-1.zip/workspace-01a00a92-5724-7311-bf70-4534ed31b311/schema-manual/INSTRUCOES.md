# Reconstrução manual do JSON-LD — posts 3014 e 3181

Estes dois posts têm JSON-LD que **não faz parse**. O script se recusa a tocar
neles de propósito: remendar JSON quebrado por regex foi exatamente o atalho que
colocou o `wpautop` no site. Reconstruídos à mão a partir do HTML publicado.

Consequência de estarem quebrados: **o Google não lê nada** desses blocos hoje.
Nem o Product, nem o FAQ, nem o breadcrumb. O texto continua no HTML, então o
`aggregateRating` inventado permanece como afirmação factual na página, mas sem
nenhum benefício de rich result em troca.

---

## 3181 — `/lg-au801-50-review`

**Causa:** wpautop. O bloco inteiro virou HTML com `<br />` entre cada linha:

```
<br />
{<br />
  "@context": "https://schema.org",<br />
```

É a assinatura do bug da v1 do corretor — este post foi vítima antes da v2
existir. O conteúdo estava íntegro: removidos os `<br />`, o JSON parseia limpo.

**Correção:** `<br />` removidos + `aggregateRating` (4.6 / 815 avaliações) removido.
O `review` 8.4/10 foi preservado.

**Arquivo:** `3181-COLAR-NO-WP.html`

---

## 3014 — `/purificador-agua-electrolux-pe12g`

**Causa:** erro estrutural. O `FAQPage` nunca fecha — faltam o `]` do
`mainEntity` e o `}` do próprio FAQPage, nas linhas 95–97:

```
 95      }          <- fecha a última Question
 96      ,          <- deveria ser  ] },
 97      {          <- BreadcrumbList começa aqui...
```

Resultado: o `BreadcrumbList` ficou **dentro do array de perguntas do FAQ**, e o
documento termina com dois níveis ainda abertos.

**Correção:** fechamento inserido, o que devolve os quatro nós ao nível certo do
`@graph` (`Article`, `Product`, `FAQPage`, `BreadcrumbList`) +
`aggregateRating` (4.7 / 27.198 avaliações) removido. O `review` 8.5/10 foi
preservado.

**Arquivo:** `3014-COLAR-NO-WP.html`

---

## Como aplicar

1. WordPress → editar o post → bloco **HTML personalizado** que contém o
   `<script type="application/ld+json">`.
2. Substituir **o bloco inteiro**, incluindo as tags `<script>` e `</script>`,
   pelo conteúdo do arquivo correspondente.
3. Atualizar.
4. Validar em <https://search.google.com/test/rich-results>.

### O que esperar na validação

- `Product` detectado, **sem** estrela agregada, **com** o bloco `review`.
- No 3014, `FAQPage` e `BreadcrumbList` devem aparecer **pela primeira vez** —
  hoje não são detectados.

### Cuidado com o editor

Se o WordPress reinserir `<br />` dentro do `<script>` ao salvar, é o mesmo
wpautop que quebrou o 3181. Nesse caso, use o bloco **HTML personalizado** do
Gutenberg (não o parágrafo) ou insira o schema pelo plugin de SEO, e confira o
código-fonte publicado depois de salvar.

---

## Verificação depois de aplicar

```bash
for id in 3014 3181; do
  slug=$( [ $id = 3014 ] && echo purificador-agua-electrolux-pe12g \
                          || echo lg-au801-50-review )
  echo "== $id =="
  curl -s "https://curadoriaprime.com/$slug/" | grep -c aggregateRating
done
```

Esperado: `0` nos dois.
