# 3181 · LG AU801 50" — correção de urgência falsa e de preço

Você apontou o selo de urgência. Ao checar o post inteiro, o selo é o **menor**
dos três problemas do bloco.

---

## 1. Urgência fabricada — remover

| Trecho | Problema |
|---|---|
| `⏰ Preço verificado há 2 horas` | Nenhum processo revalida preço de hora em hora. O carimbo é falso por construção — e, pior, **congelado**: quem ler daqui a seis meses continuará vendo "há 2 horas". |
| `Estoque limitado` | Você não tem visibilidade do estoque de Amazon nem de Mercado Livre. Escassez inventada. |

Base: CDC art. 37, §1º (publicidade enganosa por informação falsa) e as políticas
de spam do Google para páginas de afiliado.

**Substituto:** data fixa (`13/08/2026`) + "confira o valor no site da loja antes
de comprar". Data fixa envelhece com honestidade; "há 2 horas" mente sozinha.

---

## 2. O preço está errado — este é o problema grave

Os valores que **você mesmo coletou hoje**:

| Loja | Preço real |
|---|---|
| Amazon | **R$ 2.088,10** |
| Mercado Livre (Pix, TNT Info) | **R$ 1.973** |

O artigo afirma **R$ 1.941**. Ninguém consegue comprar por esse valor em nenhuma
das duas lojas. O post promete um preço que não existe, e o leitor descobre isso
só depois de clicar no link de afiliado.

### As 6 ocorrências (todas precisam mudar)

| # | Onde | Texto atual |
|---|---|---|
| 1 | Introdução | "O preço está em torno de **R$ 1.941**, entre a Philips 7019 (R$ 1.894) e a Samsung U8600F (R$ 2.154)" |
| 2 | Abertura da análise | "A LG AU801 50″ custa **R$ 1.941**, posicionando-se entre…" |
| 3 | Box de CTA | "Preço de referência: ~**R$ 1.941**" |
| 4 | Tabela de specs | "Preço médio ~**R$ 1.941**" |
| 5 | Tabela comparativa | "Preço **R$ 1.941** / R$ 2.154 / R$ 1.894" |
| 6 | Box final | "~**R$ 1.941** 🔥 Comprar no Mercado Livre" |

Sugestão de redação para 1, 2, 4 e 5: **"R$ 1.973 a R$ 2.088 (agosto/2026)"** ou
"a partir de R$ 1.973". Para 3 e 6, use o bloco pronto do arquivo
`3181-bloco-preco-CORRIGIDO.html`.

### Efeito dominó na conclusão

O post conclui: *"A Philips 7019 vence em preço (**R$ 47 mais barata**)"*.

Esse R$ 47 é `1.941 − 1.894`. Com o preço real da LG (R$ 1.973), a diferença
passa a ser **R$ 79** — e contra o preço da Amazon, R$ 194. A frase precisa ser
recalculada, senão a comparação que sustenta a recomendação fica errada.

⚠️ Confira também se R$ 1.894 (Philips) e R$ 2.154 (Samsung) ainda valem. Se
foram coletados na mesma leva do R$ 1.941, provavelmente também estão defasados,
e a tabela comparativa inteira perde o sentido.

---

## 3. O print da Amazon derruba o `reviewCount`

O anúncio que você colou mostra:

```
4,6 de 5 estrelas   (50)
```

O JSON-LD do post afirmava `ratingValue 4.6` · `reviewCount 815`.

**A nota bate. A contagem está inflada em 16×.** É a prova documental de que os
`reviewCount` do site foram inventados — e valida a decisão de remover
`aggregateRating` dos 48 posts. Guarde esse print.

---

## 4. Bônus: o `AggregateOffer` declarava o preço dos concorrentes

O schema do 3181 trazia:

```json
"offers": { "lowPrice": "1894", "highPrice": "2154" }
```

R$ 1.894 é a **Philips**. R$ 2.154 é a **Samsung**. Nenhum dos dois é a LG deste
post — alguém copiou a faixa da tabela comparativa para dentro da oferta do
produto. Declarar preço de outro produto como oferta deste é erro de dados
estruturados e pode gerar aviso no Merchant/Search Console.

Já corrigido em `3181-COLAR-NO-WP.html`:

```json
"offers": { "lowPrice": "1973", "highPrice": "2088", "offerCount": "2" }
```

---

## 5. O padrão nos outros 47 posts

Varri os 48 HTML publicados atrás dos mesmos gatilhos:

| Padrão | Ocorrências | Posts |
|---|---|---|
| "verificado há X horas" | 2 | **3181**, **3809** |
| "verificado em DATA" | 1 | 3336 |
| "Estoque limitado" | 4 | **4397** (2×), **3181**, **3809** |
| "Últimas unidades" | 1 | **4541** |
| "tempo limitado" / "aproveite já" | 0 | — |

**Está contido: 5 posts.** Não é um vício sistêmico do site — é um padrão que
apareceu em alguns modelos. O `3336` usa data fixa, que é a forma correta; só
confirme se a data ainda é recente.

### Ação sugerida

1. `3181` — aplicar o bloco pronto + corrigir as 6 ocorrências de preço.
2. `3809` e `4397` — mesmo tratamento (têm "há X horas" e/ou "estoque limitado").
3. `4541` — remover "últimas unidades".
4. `3336` — só revalidar a data.

---

## 6. Recomendação estrutural

O erro de raiz não é o selo: é **preço fixo escrito no corpo do texto**. Ele
nasce correto e apodrece sozinho, sem ninguém perceber, em todos os posts.

Três saídas, da mais barata à mais robusta:

1. **Faixa + mês** — "R$ 1.973 a R$ 2.088 (agosto/2026)". Custo zero, envelhece
   visivelmente, e o leitor sabe o quanto confiar.
2. **Tirar o preço do corpo** e deixá-lo só no box de CTA, num único lugar por
   post. Atualizar passa a ser uma edição, não seis.
3. **Checagem automatizada** — um script que lê os preços do post e avisa quando
   passam de X dias. Encaixa na cadência da §17 (`DIAS_FRESCOR=30`).

Se quiser, escrevo o script do item 3 — ele reaproveita o carregamento via
`content.raw` que o `corrigir_artigos.py` já faz.
