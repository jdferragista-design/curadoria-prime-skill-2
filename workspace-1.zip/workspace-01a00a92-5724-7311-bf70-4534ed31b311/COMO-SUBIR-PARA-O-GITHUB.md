# Como subir `tools/` e `audit/` para o Ai-skill

Está tudo pronto em **`/home/user/ai-skill-merge/`**, na estrutura exata que o
repositório espera. É só arrastar.

---

## O que foi montado

```
ai-skill-merge/
├── .gitignore
├── tools/
│   ├── README.md                  ← explica os 5 scripts e o fluxo
│   ├── gerar_artigo.py            ← corrigido: schema opt-in, author Person
│   ├── checar_conformidade.py     ← a trava, 16 checagens, exit 1
│   ├── ledger.py                  ← NOVO
│   ├── corrigir_artigos.py
│   ├── publicar_wp.py
│   └── exemplo-produto.json       ← contrato de entrada documentado
└── audit/
    ├── README.md                  ← os números da auditoria e a ordem de correção
    ├── auditoria-48-artigos.csv
    └── pauta-90-dias.csv
```

11 arquivos, 120 KB. Python 3 puro, zero dependência externa.

**Não incluí `skills/`.** Ela já existe no repo, e uma segunda cópia se
desincronizaria em semanas — é exatamente o problema que a fusão quer resolver.
O `ledger.py` aponta para `../skills/curadoria-mercado/assets/historico-precos/LEDGER.csv`,
caminho que resolve corretamente assim que a pasta estiver dentro do repositório.

---

## O `ledger.py`, em uma linha

É a peça que faltava. O `LEDGER.csv` era editado à mão, e arquivo editado à mão
acumula erro silencioso. Agora ele tem porteiro.

O subcomando que mais protege é o `frase`: você pergunta o que pode afirmar sobre
um SKU, e ele responde com base em quantas capturas reais existem.

```
$ python3 ledger.py frase --sku galaxy-tab-s10-fe --variante wifi-128

📊 galaxy-tab-s10-fe / wifi-128
   8 captura(s) que sustentam afirmação; 0 de catálogo.

   ✅ PODE ESCREVER:
      "Faixa observada pela Curadoria entre 30/07/2026 e 12/08/2026: R$ 2.711 a R$ 4.415."
      "Na captura mais recente (12/08/2026): R$ 3.195 na Amazon."

   🚫 NUNCA ESCREVER:
      "menor preço da internet" · "o mais barato" · "imperdível"

   🕐 Captura mais recente: 1 dia(s) atrás. Dentro da validade.
```

Uma captura só autoriza "nesta data, R$ X". Duas autorizam "subiu"/"caiu". Três ou
mais autorizam "faixa observada". Acima de 30 dias, ele avisa que o preço não
sustenta mais o bloco de compra.

E recusa na entrada: data no futuro, captura sem preço, duplicata exata, e URL de
catálogo `/p/MLB…` marcada como anúncio de vendedor.

### Ele já encontrou coisas no ledger atual

Rodei `validar` contra as 30 capturas que estão no repo:

- **linha 9** — segunda captura do mesmo dia/loja (R$ 3.127,07 → R$ 3.195,06).
  Legítimo, o preço mudou durante o dia. Ajustei o script para tratar isso como
  alerta e não erro. No artigo, cite só a mais recente do dia.
- **linhas 11 e 29** — o preço "de" quase não supera o preço real. Desconto de
  fachada; não vale destacar no texto.
- **linha 17** — captura sem URL, não auditável.

Nenhum erro bloqueante. O ledger está saudável.

---

## Subir pela interface web

Caminho mais simples, não exige git instalado.

1. Abra `https://github.com/jdferragista-design/Ai-skill`
2. **Importante:** troque para a branch certa no seletor à esquerda.
   - Se você **já fez** o merge de `merge-branch-para-main.md` → use `main`
   - Se **ainda não fez** → use `arena/019ff772-ai-skill`
3. **Add file** → **Upload files**
4. Arraste as pastas `tools` e `audit` inteiras (não os arquivos soltos — arrastar
   a pasta preserva a estrutura)
5. Em "Commit changes", use:

```
Adicionar tools/ e audit/ — regras editoriais como código executável

tools/ implementa mecanicamente o regras_editoriais_ia_curadoria_prime.md:

- checar_conformidade.py — trava com 16 checagens, exit 1 se reprovar
- gerar_artigo.py — schema opt-in (§7.3), author Person (§2.6),
  sem aggregateRating externo (§2.4)
- ledger.py — porteiro do LEDGER.csv; o subcomando 'frase' informa
  o que o histórico de capturas autoriza afirmar
- corrigir_artigos.py, publicar_wp.py

audit/ registra o estado real: 27 dos 48 artigos publicados têm
problema (37 alegações de teste não realizado, 48 links sem
rel="sponsored", 10 sem divulgação).

Sem dependências externas.
```

6. **Commit changes**

## Ou por linha de comando

```bash
git clone https://github.com/jdferragista-design/Ai-skill.git
cd Ai-skill
git checkout main          # ou arena/019ff772-ai-skill, se ainda não mesclou

cp -r /caminho/para/ai-skill-merge/tools .
cp -r /caminho/para/ai-skill-merge/audit .
cp /caminho/para/ai-skill-merge/.gitignore .

git add tools audit .gitignore
git commit -m "Adicionar tools/ e audit/ — regras editoriais como código executável"
git push
```

---

## Confira que funcionou

Depois do upload, na raiz do repositório:

```bash
python3 tools/ledger.py validar
python3 tools/checar_conformidade.py 'articles/*.html' --resumo
```

O primeiro deve listar 30 capturas com 4 alertas e nenhum erro. O segundo deve
dar 0 erros em 3 dos 4 artigos (`preview-tablets.html` acusa falta de assinatura,
o que é correto — é um preview).

Se o `ledger.py` reclamar que não achou o arquivo, é sinal de que `tools/` não
ficou na raiz do repo, e sim aninhada em outra pasta.

---

## Depois disto

De `merge-branch-para-main.md`, ainda em aberto:

1. Merge da branch para a `main` — **faça antes deste upload, se possível**
2. Renomear os dois arquivos sem extensão na raiz (`modelo-2-Power-Bank-no-Avião`
   e `modelo-layout-da-Apple-TV-4K.`) para `.html` dentro de
   `skills/curadoria-review/references/`
3. Proteger a `main` exigindo pull request

E de `avaliacao-ai-skill-vs-kit.md`, restam 6 das 9 checagens novas para o
checker — implementei 3 nesta sessão (`aggregateRating` externo, `author` não-Person,
`reviewRating` opcional). Faltam: CTA para catálogo `/p/MLB…`, R$ no botão sem
linha no LEDGER, alegação de saúde em wearable, `[VERIFICAÇÃO HUMANA NECESSÁRIA]`
no HTML final, "compradores verificados" sem selo, nota sem escala, ano do título
sem mudança substancial, `rel` sem `nofollow`.

Uma observação sobre o `prompt-mestre.md`: ele continua em `/home/user` e **não**
foi incluído no upload de propósito. Depois da fusão, quem manda são as regras do
repo — ele deixa de ser fonte de regra e vira, no máximo, um gerador de JSON.
Manter duas fontes de regra é como o projeto acumula contradição.
