# ✅ `main` protegida — confirmado via API

```
main  266aa9d  | protected: True

Ruleset "Proteger main" (id 20804816) · enforcement: active
Target: ~DEFAULT_BRANCH
Rules:
  • deletion            → não pode apagar
  • non_fast_forward    → não pode force push
  • pull_request        → required_approving_review_count: 0
```

Exatamente a configuração combinada. Frente de infraestrutura encerrada.

---

# Posts 4537 e 4541 — diagnóstico

Puxei os dois pela WP REST API e analisei o HTML publicado.

## Post 4537 — Apple TV 4K
`curadoriaprime.com/apple-tv-4k/` · modificado 11/08 · 60 KB

**2 defeitos.**

### 1. 🔴 `"Testamos a fundo"` no primeiro parágrafo

```
Afinal, a Apple TV 4K vale a pena em 2026? Testamos a fundo a 3ª geração
(chip A15 Bionic, 4K Dolby Vision + HDR10+, Dolby Atmos): analisamos
especificações oficiais da Apple, preços reais de 10/08/2026...
```

O agravante: **o próprio artigo desmente essa frase** mais abaixo, no box de
metodologia — *"não testamos esta unidade fisicamente"*. Um leitor que compare os
dois trechos vê a contradição. Um fiscal do Procon também.

**Substituir por:**

```
Afinal, a Apple TV 4K vale a pena em 2026? Analisamos a fundo a 3ª geração
(chip A15 Bionic, 4K Dolby Vision + HDR10+, Dolby Atmos): cruzamos
especificações oficiais da Apple, preços reais de 10/08/2026...
```

Uma palavra: `Testamos` → `Analisamos`. E `analisamos` → `cruzamos` logo depois,
para não repetir. Nada mais muda.

### 2. 🟠 `aggregateRating` de terceiros no JSON-LD

```json
"aggregateRating": { "@type": "AggregateRating",
  "ratingValue": "4.7", "bestRating": "5", "ratingCount": "384" }
```

Nota da loja, não sua. É a regra §2.4 do próprio repositório, e é a mesma coisa
que acabamos de remover dos modelos. **Apagar o bloco inteiro** — ele fica entre
`"description"` e `"offers"`.

---

## Post 4541 — Dia dos Pais 2026
`curadoriaprime.com/presentes-dia-dos-pais-2026-tech-premium/` · modificado 07/08 · 78 KB

**3 defeitos, um deles que eu não esperava encontrar.**

### 1. 🔴 Três alegações de teste físico

O box de metodologia diz *"não testamos estas unidades fisicamente"*. E aí, no
corpo do texto:

| onde | frase |
|---|---|
| card Watch7 | **"Já testamos o Watch7 na bancada"** |
| card Liberty 4 NC | **"Já testamos"** |
| FAQ comparativo | **"Testamos os dois"** |

"Na bancada" é a mais grave — descreve um procedimento específico. As três
contradizem o próprio disclaimer do artigo, o que é pior do que a alegação
isolada: mostra que o label de metodologia não é confiável.

**Substituir por:**

| de | para |
|---|---|
| `Já testamos o Watch7 na bancada — leia nossa review completa` | `Analisamos o Watch7 em detalhe — leia nossa review completa` |
| `Já testamos — leia nossa review completa do Liberty 4 NC` | `Analisamos ele em detalhe — leia nossa review completa do Liberty 4 NC` |
| `Testamos os dois: leia as reviews completas` | `Analisamos os dois: leia as reviews completas` |

### 2. 🟠 Cinco blocos `aggregateRating`

Um por produto do ListItem:

| produto | nota importada |
|---|---|
| Apple Pencil Pro | 4.6 / 9.746 avaliações |
| Galaxy Watch7 44mm | 4.9 / 9.412 |
| Anker 737 | 4.9 / 878 |
| Soundcore Liberty 4 NC | 4.6 / 26.873 |
| JBL Wave Buds 2 | 4.8 / 1.364 |

Mesmo procedimento: apagar os 5 blocos. Cada um fica entre `"description"` e
`"offers"` dentro do respectivo `ListItem`.

### 3. 🟡 Bloco de anotações internas publicado no HTML

Isto eu não esperava. Há um comentário HTML de **4.099 caracteres** dentro do
post no ar. Invisível na tela, mas presente no código-fonte que qualquer pessoa
lê com Ctrl+U — e que o Google rastreia.

O que está exposto lá:

- **6 tokens `PEND_`** não preenchidos (`PEND_PRECO_<PROD>`, `PEND_QUOTE_<PROD>`,
  `PEND_NOME_<PROD>`…) — ou seja, o artigo foi publicado com pendências abertas
- A anotação **"aluc. interceptada no raio-X"** e **"anterior 2DBDe98 descartada:
  abria anúncio Pencil — erro de geração na fonte"**
- Estratégia comercial: *"produtos em ordem decrescente de preço"*
- Dados pessoais seus: *"16 mil+ viagens Uber+99, 4,97★ Uber / 5,0★ 99"*,
  `@martinscs08`
- Nomes de arquivos internos: `CROSSCHECK-PERPLEX-DIA-DOS-PAIS.md`,
  `LINKS-DE-VENDA-AFILIADOS.md`

Um concorrente que abra o código-fonte tem seu processo editorial inteiro. E a
palavra "alucinação" ao lado do nome de um produto é péssima em qualquer
contexto.

**Apagar o comentário inteiro.** Começa em `<!--` logo antes de "Dia dos Pais
2026 = domingo 09/08/2026" e vai até `-->` depois de "Bloco Sobre o autor com
Person schema aprimorado". No editor do WordPress, veja pelo modo **Editor de
código** (⋮ → Editor de código) — em bloco HTML ele nem aparece.

> Vale rodar o mesmo teste nos outros artigos. Se esse comentário veio do
> template, provavelmente não está só aqui.

---

## O que está certo nos dois

Para não passar a impressão de que está tudo ruim:

| | 4537 | 4541 |
|---|---|---|
| Links de afiliado | 6 | 12 |
| Com `rel="sponsored"` | ✅ 6/6 | ✅ 12/12 |
| Com `nofollow` | ✅ 6/6 | ✅ 12/12 |
| Divulgação de comissão | ✅ | ✅ |
| Box de metodologia honesto | ✅ | ✅ |

`rel` e divulgação — os dois itens que geram ação manual do Google — estão
**100% corretos**. O problema é só de alegação e de schema.

---

## Ordem sugerida

1. **4537** — 2 edições, 5 minutos. É o mais simples e é a página de produto
2. **4541** — as 3 frases, depois os 5 blocos de schema, depois o comentário
3. Validar os dois em **validator.schema.org** colando a URL
4. Rodar o `grep` do comentário interno no resto do site

Nenhuma das mudanças altera layout, links ou preços. É texto e JSON-LD.

Depois disso a fila fica limpa para os **12 artigos P0** da auditoria — que somam
37 alegações falsas e 48 links sem `sponsored`, esses sim com problema de `rel`.
