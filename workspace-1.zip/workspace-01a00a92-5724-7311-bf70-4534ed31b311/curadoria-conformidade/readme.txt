=== Curadoria Prime — Conformidade ===
Contributors: curadoriaprime
Tags: seo, afiliados, schema, conformidade, editorial
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.5
License: GPLv2 or later

Auditor de conformidade editorial: detecta 10 problemas de risco em posts de
afiliado, mostra o diff antes/depois e só grava depois da aprovação humana.

== Description ==

Varre os posts e aponta o que pode gerar ação manual do Google:

* Alegação de teste físico não sustentada (texto e JSON-LD)
* Urgência falsa ("estoque limitado", "verificado há N horas")
* aggregateRating inventado no schema
* Autor de schema fora do padrão editorial
* JSON-LD malformado (inclusive a aspa reta de polegadas)
* Link de afiliado sem rel="sponsored"
* Falta do bloco de divulgação de afiliado
* Imagem presa no placeholder de lazy-load
* Preço sem data de verificação

Cinco dessas regras têm correção automática. As que exigem reescrita editorial
— alegação de teste e urgência falsa — são apenas sinalizadas, nunca reescritas
pelo plugin.

Nada é gravado sem clique humano: toda correção passa por preview com diff,
checkbox de confirmação, nonce, verificação de capability por post e uma trava
que aborta a gravação se o resultado perder imagens, links, texto ou schema.

== Changelog ==

= 1.2.5 =
* Corrigido: a sugestão da IA sumia ao copiar a página. O texto era escrito só
  em textarea.value, que não altera o conteúdo do nó no DOM — quem copiava a
  tela levava o campo "como deve ficar" em branco, mesmo com a sugestão visível
  no navegador. Agora o valor é espelhado no nó e num atributo data-sugerido.
* Corrigido: o total do mês parecia travado (ou encolhendo) porque era exibido
  com duas casas. R$ 0,0080 e R$ 0,0097 viravam os dois "R$ 0,01". Abaixo de
  R$ 0,10 o medidor passa a mostrar quatro casas.
* A nota de custo agora informa quantos tokens foram gastos com raciocínio,
  quando o modelo cobrar por isso.

= 1.2.5 =
* Novo: botão "Sugerir para todos os N trechos". Um clique preenche todas as
  caixas vazias, uma por vez, com o custo estimado mostrado antes de rodar.
  Dá para interromper no meio, e o que já veio fica. Campos já digitados são
  respeitados. Nada é gravado até você clicar em salvar.
* Corrigido: a tela dizia "os itens acima precisam da sua reescrita no editor"
  quando um artigo só tinha itens manuais. Texto de antes da v1.2.0, quando o
  campo de edição ainda não existia — e que mandava o usuário fazer à mão um
  trabalho que o plugin já faz. A gravação sempre acontece na própria tela.
* Corrigido: a sugestão da IA sumia ao copiar a página. O texto era escrito só
  em textarea.value, que não altera o nó no DOM — quem copiava a tela levava o
  campo "como deve ficar" em branco, mesmo com a sugestão visível na tela.
* Corrigido: o total do mês parecia travado porque era exibido com duas casas.
  R$ 0,0080 e R$ 0,0097 viravam os dois "R$ 0,01". Abaixo de R$ 0,10 agora
  mostra quatro casas.
* Botão individual e lote passam a compartilhar a mesma implementação.
* A nota de custo informa os tokens gastos com raciocínio, quando houver.

= 1.2.4 =
* Corrigido: o medidor mensal filtrava por UTC e o carimbo era gravado em hora
  local. Em São Paulo, chamadas feitas entre 21h e 23h59 do último dia do mês
  eram cobradas e sumiam da contagem — o teto de gasto mentia a favor do gasto.
* Nova tabela comparativa de custo por modelo na tela de configuração, com
  estimativa para um artigo e para o site inteiro. Trocar de flash-lite para
  claude-haiku-4.5 multiplica a conta dos 53 artigos por ~11,5 (R$ 0,94 → R$
  10,84) e nada avisava antes.

= 1.2.3 =
* Corrigido: resposta da IA cortada no meio da frase era entregue como se
  estivesse pronta. Modelos de raciocínio (deepseek-v4, o-series, qwen-thinking)
  gastam o orçamento de saída "pensando", e esses tokens contam como saída: um
  campo do post 3523 pagou 698 tokens e recebeu 59 de texto visível.
* O plugin agora pede reasoning.enabled=false — a tarefa é reescrever um
  parágrafo, não raciocinar em cadeia.
* Passa a ler finish_reason e reasoning_tokens. Truncamento vira erro explícito
  dizendo quantos tokens foram gastos raciocinando, em vez de preencher o campo
  com meia frase.
* max_tokens deixa de ser fixo em 700 e acompanha o tamanho do trecho
  (piso 700, teto 3.000).
* Rede de segurança: texto de reescrita que não termina em pontuação final é
  descartado, mesmo que o provedor diga que terminou bem.
* Chamada truncada continua sendo contabilizada no medidor mensal — ela foi
  cobrada, e o teto de gasto não pode mentir.

= 1.2.2 =
* Contexto nunca mais corta palavra ao meio: o recorte alinha na fronteira da
  palavra e marca com reticências quando há texto antes/depois.
* Uma frase que infringe duas regras agora é UM campo editável só. Antes virava
  dois campos com o mesmo texto: o primeiro gravava e o segundo era recusado
  com "não encontrei este trecho exato" — mensagem correta e enganosa ao mesmo
  tempo. O campo vai para a regra mais grave e mostra as duas regras.
* A regra que cedeu a frase continua no relatório e nas estatísticas; o card
  aponta onde o trecho é editado. Contagens do CSV e do painel não mudam.
* Toda ocorrência passa a ter sempre tokens[] e tambem[].
* Placar no post 3523: 23 campos, 23 gravam, 0 recusas.

= 1.2.1 =
* Correção crítica: o contexto mostrado no painel podia ser de outro parágrafo. preg_match_all devolve offset em bytes e mb_substr conta caracteres — em texto com acentos e emoji a janela deslizava (1.316 posições no fim de um artigo real).
* A unidade de edição passou a ser a FRASE, não o token. "Testamos" sozinho aparecia 9 vezes no post e toda gravação era recusada por ambiguidade; a frase é única.
* Duas detecções na mesma frase agora viram um único campo, com os tokens realçados.
* Âncora tolerante corrigida: aceitava tag de no máximo 120 caracteres e reprovava em <a style="..."> reais; agora aceita tags de qualquer tamanho e entidades HTML (&#8220;).
* Descrição de schema repetida em meta/og/JSON-LD passa a ser trocada em todas as cópias.
* Novos testes de regressão: .smoke/cpc-offset-test.php (20 asserções).

= 1.2.0 =
* Edição trecho a trecho na própria tela de revisão: o texto original de um lado, a caixa editável do outro. Não precisa mais abrir o Gutenberg para reescrever.
* Botão opcional "Sugerir com IA" por trecho, com dois provedores (OpenRouter e Cline) e fallback automático — mesma arquitetura do AI Image Optimizer.
* Medidor de custo: tokens e reais por chamada, total do mês e teto mensal de gasto que desliga a IA ao ser atingido.
* Substituição ancorada e literal: se o trecho não for encontrado exatamente uma vez, a troca é recusada em vez de adivinhar qual ocorrência alterar.
* Três novos tipos no relatório de falhas: edicao_recusada, edicao_bloqueada e ia_falhou.
* A IA nunca grava: ela só preenche a caixa. Toda gravação continua passando por confirmação e pela trava CPC_Diff::validar().


= 1.1.0 =
* Relatório de falhas: registra tudo que o plugin tenta corrigir e não consegue,
  com diagnóstico e ação recomendada por tipo. Exportável em CSV.
* Trava de segurança e erro de gravação não morrem mais num wp_die: viram
  registro consultável.
* "Detector acusa, corretor não resolve" sinaliza divergência entre análise e
  correção — candidato a bug do plugin.

= 1.0.0 =
* Versão inicial: 10 detectores, 5 correções automáticas, painel, CSV e metabox.
