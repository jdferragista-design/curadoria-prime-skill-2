/* global CPC */
( function () {
	'use strict';

	function postId() {
		var f = document.querySelector( 'input[name="post_id"]' );
		return f ? f.value : 0;
	}

	/** Uma chamada de sugestão para um <textarea>. Resolve sempre. */
	function sugerirUm( area ) {
		var dados = new FormData();
		dados.append( 'action', 'cpc_sugerir' );
		dados.append( 'nonce', CPC.nonce );
		dados.append( 'post_id', postId() );
		dados.append( 'regra', area.getAttribute( 'data-regra' ) || '' );
		dados.append( 'trecho', area.getAttribute( 'data-original' ) || '' );
		dados.append( 'contexto', area.getAttribute( 'data-contexto' ) || '' );
		dados.append( 'titulo', area.getAttribute( 'data-titulo' ) || '' );

		return fetch( CPC.ajax, { method: 'POST', body: dados, credentials: 'same-origin' } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( r ) {
				var caixa  = area.closest( '.cpc-edit' );
				var status = caixa ? caixa.querySelector( '.cpc-ia-status' ) : null;

				if ( ! r || ! r.success ) {
					if ( status ) {
						status.className   = 'cpc-ia-status cpc-ia-erro';
						status.textContent = ( r && r.data && r.data.msg ) ? r.data.msg : CPC.i18n.erro;
					}
					return false;
				}

				area.value       = r.data.texto;
				area.textContent = r.data.texto;
				area.setAttribute( 'data-sugerido', r.data.texto );
				area.style.height = 'auto';
				area.style.height = ( area.scrollHeight + 4 ) + 'px';

				if ( status ) {
					var nota = r.data.modelo + ' · ' + r.data.tokens + ' tokens';
					if ( r.data.raciocinio > 0 ) {
						nota += ' (' + r.data.raciocinio + ' de raciocínio)';
					}
					nota += ' · R$ ' + r.data.custo;
					if ( r.data.fallback ) {
						nota += ' · fallback: ' + r.data.provedor;
					}
					nota += ' · mês: R$ ' + r.data.mes;
					status.className   = 'cpc-ia-status cpc-ia-ok';
					status.textContent = nota;
				}
				return true;
			} )
			.catch( function () { return false; } );
	}

	var loteRodando = false;

	/**
	 * Preenche todas as caixas VAZIAS, uma por vez.
	 *
	 * Sequencial de propósito: 23 chamadas simultâneas tomam 429 do provedor e
	 * o usuário perde o lote inteiro. Respeita texto já digitado e pode ser
	 * interrompido no meio sem perder o que já veio.
	 */
	function lote( botao ) {
		var status = document.querySelector( '.cpc-lote-status' );

		if ( loteRodando ) {
			loteRodando = false;
			return;
		}

		var vazias = [];
		Array.prototype.forEach.call( document.querySelectorAll( '.cpc-ta' ), function ( ta ) {
			if ( '' === ta.value.trim() ) {
				vazias.push( ta );
			}
		} );

		if ( ! vazias.length ) {
			if ( status ) {
				status.textContent = CPC.i18n.loteFim.replace( '%1$d', 0 ).replace( '%2$d', 0 );
			}
			return;
		}

		loteRodando = true;
		var rotulo  = botao.textContent;
		var feitos  = 0;
		var falhas  = 0;
		botao.textContent = CPC.i18n.parar;

		var proximo = function ( i ) {
			if ( ! loteRodando || i >= vazias.length ) {
				loteRodando       = false;
				botao.textContent = rotulo;
				if ( status ) {
					var m = CPC.i18n.loteFim.replace( '%1$d', feitos ).replace( '%2$d', vazias.length );
					if ( falhas ) {
						m += ' ' + CPC.i18n.loteErro.replace( '%d', falhas );
					}
					status.textContent = m;
					status.className   = 'cpc-lote-status' + ( falhas ? ' cpc-ia-erro' : ' cpc-ia-ok' );
				}
				return;
			}

			if ( status ) {
				status.className   = 'cpc-lote-status';
				status.textContent = CPC.i18n.loteAnda
					.replace( '%1$d', i + 1 )
					.replace( '%2$d', vazias.length );
			}
			vazias[ i ].scrollIntoView( { block: 'center', behavior: 'smooth' } );

			sugerirUm( vazias[ i ] ).then( function ( ok ) {
				if ( ok ) {
					feitos++;
				} else {
					falhas++;
				}
				proximo( i + 1 );
			} );
		};

		proximo( 0 );
	}

	document.addEventListener( 'click', function ( ev ) {
		var alvo = ev.target;

		// ── copiar original para a caixa ──
		if ( alvo.classList.contains( 'cpc-copiar' ) ) {
			ev.preventDefault();
			var bloco = alvo.closest( '.cpc-edit' );
			var ta    = bloco ? bloco.querySelector( '.cpc-ta' ) : null;
			if ( ta ) {
				ta.value = ta.getAttribute( 'data-original' ) || '';
				ta.focus();
			}
			return;
		}

		// ── sugerir em lote ──
		if ( alvo.classList.contains( 'cpc-ia-lote' ) ) {
			ev.preventDefault();
			lote( alvo );
			return;
		}

		// ── sugerir com IA (um trecho) ──
		if ( ! alvo.classList.contains( 'cpc-ia-btn' ) ) {
			return;
		}
		ev.preventDefault();

		var caixa  = alvo.closest( '.cpc-edit' );
		var area   = caixa.querySelector( '.cpc-ta' );
		var status = caixa.querySelector( '.cpc-ia-status' );
		var rotulo = alvo.textContent;

		alvo.disabled      = true;
		alvo.textContent   = CPC.i18n.pensando;
		status.textContent = '';
		status.className   = 'cpc-ia-status';

		// Mesmo caminho do lote: uma implementação só, senão o próximo
		// conserto entra num botão e esquece o outro.
		sugerirUm( area ).then( function () {
			alvo.disabled    = false;
			alvo.textContent = rotulo;
		} );
	} );

	// Aviso ao sair com edição não salva: o trabalho de reescrita é caro.
	var sujo = false;
	document.addEventListener( 'input', function ( ev ) {
		if ( ev.target.classList && ev.target.classList.contains( 'cpc-ta' ) ) {
			sujo = true;
		}
	} );
	document.addEventListener( 'submit', function () { sujo = false; } );
	window.addEventListener( 'beforeunload', function ( ev ) {
		if ( sujo ) {
			ev.preventDefault();
			ev.returnValue = '';
		}
	} );
}() );
