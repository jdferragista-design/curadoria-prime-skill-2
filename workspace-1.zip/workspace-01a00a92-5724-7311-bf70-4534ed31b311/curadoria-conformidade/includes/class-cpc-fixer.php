<?php
/**
 * Correções automáticas.
 *
 * REGRA DE OURO: só entra aqui o que é determinístico e reversível. Alegação de
 * teste e urgência falsa NÃO são corrigidas automaticamente — trocar "testamos"
 * por "analisamos" muda o sentido da frase e exige leitura humana. O plugin
 * marca, mostra o trecho e deixa a reescrita para o editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Fixer {

	/** Regras que o plugin sabe aplicar sozinho. */
	public static function regras_automaticas() {
		return array( 'schema_agg', 'schema_autor', 'sponsored', 'divulgacao', 'img_lazy' );
	}

	/**
	 * Incidentes da última execução de aplicar(): o que a correção tentou e não
	 * conseguiu. Preenchido em memória; quem persiste é o handler, e só quando a
	 * ação parte de um clique real (a pré-visualização não polui o relatório).
	 *
	 * @var array<int,array{tipo:string,detalhe:string,regra:string}>
	 */
	private static $incidentes = array();

	private static function incidente( $tipo, $detalhe = '', $regra = '' ) {
		self::$incidentes[] = array(
			'tipo'    => $tipo,
			'detalhe' => $detalhe,
			'regra'   => $regra,
		);
	}

	/** Incidentes acumulados na última chamada de aplicar(). */
	public static function incidentes() {
		return self::$incidentes;
	}

	/**
	 * Aplica as regras pedidas e devolve o novo HTML + o que mudou.
	 * Nunca grava: quem grava é o handler, depois da aprovação.
	 */
	public static function aplicar( $html, $regras ) {
		$log              = array();
		self::$incidentes = array();

		if ( in_array( 'img_lazy', $regras, true ) ) {
			list( $html, $n ) = self::corrigir_lazy( $html );
			if ( $n ) {
				$log[] = sprintf( '%d imagem(ns) com placeholder restaurada(s)', $n );
			} else {
				self::incidente( 'regra_sem_efeito', 'Nenhuma imagem tinha data-src utilizável.', 'img_lazy' );
			}
		}
		if ( in_array( 'sponsored', $regras, true ) ) {
			list( $html, $n ) = self::corrigir_sponsored( $html );
			if ( $n ) {
				$log[] = sprintf( '%d link(s) de afiliado receberam rel="%s"', $n, CPC_Rules::REL_CORRETO );
			} else {
				self::incidente( 'regra_sem_efeito', 'Nenhum link de afiliado sem rel="sponsored" foi encontrado.', 'sponsored' );
			}
		}
		if ( in_array( 'schema_agg', $regras, true ) || in_array( 'schema_autor', $regras, true ) ) {
			list( $html, $a, $b ) = self::corrigir_schema(
				$html,
				in_array( 'schema_agg', $regras, true ),
				in_array( 'schema_autor', $regras, true )
			);
			if ( $a ) {
				$log[] = sprintf( '%d aggregateRating removido(s)', $a );
			}
			if ( $b ) {
				$log[] = sprintf( '%d autor(es) padronizado(s) para %s', $b, CPC_Rules::autor_canonico() );
			}
			if ( ! $a && ! $b ) {
				self::incidente( 'regra_sem_efeito', 'Nenhum bloco de schema precisou de alteração.', 'schema' );
			}
		}
		if ( in_array( 'divulgacao', $regras, true ) ) {
			list( $html, $n ) = self::inserir_divulgacao( $html );
			if ( $n ) {
				$log[] = 'bloco de divulgação inserido antes do primeiro link de afiliado';
			}
		}

		return array( $html, $log );
	}

	/**
	 * Promove data-src para src e remove os atributos do lazy-load.
	 * Sem isso o placeholder base64 fica gravado e a imagem some.
	 */
	private static function corrigir_lazy( $html ) {
		$n = 0;
		$novo = preg_replace_callback(
			'/<img\b[^>]*>/i',
			function ( $m ) use ( &$n ) {
				$tag = $m[0];
				if ( ! preg_match( '/\bdata-src\s*=\s*(["\'])(.*?)\1/i', $tag, $d ) ) {
					// Sem data-src não há URL para restaurar; um src base64 sozinho
					// não tem conserto automático — fica para o relatório.
					if ( preg_match( '/\bsrc\s*=\s*(["\'])\s*data:/i', $tag ) ) {
						self::incidente(
							'img_sem_url',
							'Imagem com placeholder base64 e sem data-src: ' . mb_substr( $tag, 0, 160, 'UTF-8' ),
							'img_lazy'
						);
					}
					return $tag;
				}
				$real = $d[2];
				if ( '' === trim( $real ) || 0 === stripos( $real, 'data:' ) ) {
					self::incidente(
						'img_sem_url',
						'O data-src desta imagem também é um placeholder, não uma URL: ' . mb_substr( $tag, 0, 160, 'UTF-8' ),
						'img_lazy'
					);
					return $tag;
				}
				$antes = $tag;
				if ( preg_match( '/\bsrc\s*=\s*(["\']).*?\1/i', $tag ) ) {
					$tag = preg_replace( '/\bsrc\s*=\s*(["\']).*?\1/i', 'src="' . esc_url( $real ) . '"', $tag, 1 );
				} else {
					$tag = rtrim( substr( $tag, 0, -1 ) ) . ' src="' . esc_url( $real ) . '">';
				}
				if ( preg_match( '/\bdata-srcset\s*=\s*(["\'])(.*?)\1/i', $antes, $ss ) && trim( $ss[2] ) ) {
					if ( preg_match( '/\bsrcset\s*=\s*(["\']).*?\1/i', $tag ) ) {
						$tag = preg_replace( '/\bsrcset\s*=\s*(["\']).*?\1/i', 'srcset="' . esc_attr( $ss[2] ) . '"', $tag, 1 );
					} else {
						$tag = rtrim( substr( $tag, 0, -1 ) ) . ' srcset="' . esc_attr( $ss[2] ) . '">';
					}
				}
				foreach ( array( 'data-lazyloaded', 'data-src', 'data-srcset', 'data-sizes' ) as $attr ) {
					$tag = preg_replace( '/\s' . $attr . '\s*=\s*(["\']).*?\1/i', '', $tag );
				}
				$n++;
				return $tag;
			},
			$html
		);
		return array( null === $novo ? $html : $novo, $n );
	}

	private static function corrigir_sponsored( $html ) {
		$n = 0;
		$novo = preg_replace_callback(
			'/<a\b[^>]*>/i',
			function ( $m ) use ( &$n ) {
				$tag = $m[0];
				if ( ! preg_match( '/href\s*=\s*["\']([^"\']*)["\']/i', $tag, $h ) ) {
					return $tag;
				}
				if ( ! CPC_Rules::e_afiliado( $h[1] ) ) {
					return $tag;
				}
				if ( preg_match( '/\brel\s*=\s*["\'][^"\']*sponsored/i', $tag ) ) {
					return $tag;
				}
				$n++;
				if ( preg_match( '/\brel\s*=\s*["\'][^"\']*["\']/i', $tag ) ) {
					return preg_replace( '/\brel\s*=\s*["\'][^"\']*["\']/i', 'rel="' . CPC_Rules::REL_CORRETO . '"', $tag, 1 );
				}
				return rtrim( substr( $tag, 0, -1 ) ) . ' rel="' . CPC_Rules::REL_CORRETO . '">';
			},
			$html
		);
		return array( null === $novo ? $html : $novo, $n );
	}

	/**
	 * Schema: parseia, muta o objeto, redumpa. Nunca por regex — bloco que não
	 * faz parse é deixado exatamente como está.
	 */
	private static function corrigir_schema( $html, $fazer_agg, $fazer_autor ) {
		$n_agg = 0;
		$n_aut = 0;
		$blocos = CPC_Rules::blocos_jsonld( $html );
		// De trás para frente: preserva os offsets dos blocos anteriores.
		foreach ( array_reverse( $blocos ) as $i => $b ) {
			$limpo = CPC_Rules::limpar_jsonld( $b['bruto'] );
			$dados = json_decode( $limpo, true );
			if ( ! is_array( $dados ) ) {
				$msg = 'Bloco de schema ignorado (' . json_last_error_msg() . '): '
					. mb_substr( trim( $limpo ), 0, 160, 'UTF-8' );
				if ( false !== strpos( $limpo, '"' ) && preg_match( '/\d\s*"\s*[A-Za-zÀ-ú]/', $limpo ) ) {
					$msg .= ' — suspeita de aspa reta de polegadas sem escape.';
				}
				self::incidente( 'schema_ilegivel', $msg, 'schema' );
				continue;
			}
			$c = array( 'agg' => 0, 'autor' => 0 );
			$dados = self::mutar( $dados, $fazer_agg, $fazer_autor, $c );
			if ( ! $c['agg'] && ! $c['autor'] ) {
				continue;
			}
			$json = wp_json_encode( $dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
			if ( false === $json ) {
				self::incidente(
					'schema_encode_falhou',
					'wp_json_encode falhou (' . json_last_error_msg() . '). O bloco foi deixado intacto.',
					'schema'
				);
				continue;
			}
			$html   = substr( $html, 0, $b['inicio'] ) . "\n" . $json . "\n" . substr( $html, $b['inicio'] + $b['tam'] );
			$n_agg += $c['agg'];
			$n_aut += $c['autor'];
		}
		return array( $html, $n_agg, $n_aut );
	}

	private static function mutar( $no, $fazer_agg, $fazer_autor, &$c ) {
		if ( ! is_array( $no ) ) {
			return $no;
		}
		if ( $fazer_agg && isset( $no['aggregateRating'] ) ) {
			unset( $no['aggregateRating'] );
			$c['agg']++;
		}
		if ( $fazer_agg ) {
			foreach ( array( 'reviewCount', 'ratingCount' ) as $k ) {
				if ( isset( $no[ $k ] ) && ! isset( $no['@type'] ) ) {
					unset( $no[ $k ] );
				}
			}
		}
		if ( $fazer_autor && isset( $no['@type'] ) && 'Person' === $no['@type'] && isset( $no['name'] ) ) {
			if ( CPC_Rules::autor_canonico() !== $no['name'] ) {
				$no['name'] = CPC_Rules::autor_canonico();
				$c['autor']++;
			}
		}
		foreach ( $no as $k => $v ) {
			if ( is_array( $v ) ) {
				$no[ $k ] = self::mutar( $v, $fazer_agg, $fazer_autor, $c );
			}
		}
		return $no;
	}

	public static function bloco_divulgacao() {
		$url = home_url( '/transparencia-curadoria-prime/' );
		return '<div style="background:#f8f8ff;border:1px solid #e2e2f0;border-radius:12px;'
			. 'padding:16px 20px;margin:24px 0;font-size:.92em;color:#7c7c9a;line-height:1.6">'
			. '🔍 <strong>Transparência:</strong> este artigo contém links de afiliado. '
			. 'Se você comprar por eles, podemos receber uma comissão <strong>sem custo adicional '
			. 'para você</strong>. Isso não influencia nossa análise — nossa nota é baseada em '
			. 'pesquisa técnica e dados de compradores verificados. '
			. '<a href="' . esc_url( $url ) . '">Entenda nossa metodologia</a>.'
			. '</div>';
	}

	/**
	 * Insere a divulgação antes do primeiro link de afiliado, respeitando a
	 * fronteira do bloco Gutenberg: HTML solto no meio de um bloco faz o editor
	 * marcar o post como inválido.
	 */
	private static function inserir_divulgacao( $html ) {
		// Guarda de idempotência: sem isto, aplicar a correção duas vezes
		// empilha um segundo bloco de divulgação no artigo.
		$txt = mb_strtolower( CPC_Rules::texto_visivel( $html ), 'UTF-8' );
		foreach ( array( 'link de afiliado', 'links de afiliado', 'comissão', 'comissao' ) as $k ) {
			if ( false !== mb_strpos( $txt, $k, 0, 'UTF-8' ) ) {
				return array( $html, 0 );
			}
		}

		$pos = null;
		if ( preg_match_all( '/<a\b[^>]*>/i', $html, $mm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $mm[0] as $hit ) {
				if ( preg_match( '/href\s*=\s*["\']([^"\']*)["\']/i', $hit[0], $h ) && CPC_Rules::e_afiliado( $h[1] ) ) {
					$pos = $hit[1];
					break;
				}
			}
		}
		if ( null === $pos ) {
			self::incidente(
				'divulgacao_sem_ancora',
				'Não há link de afiliado neste post para ancorar o bloco de divulgação.',
				'divulgacao'
			);
			return array( $html, 0 );
		}

		$gutenberg = (bool) preg_match( '/<!--\s*\/?wp:/', $html );
		$bloco     = $gutenberg
			? "\n<!-- wp:html -->\n" . self::bloco_divulgacao() . "\n<!-- /wp:html -->\n"
			: "\n" . self::bloco_divulgacao() . "\n";

		if ( $gutenberg ) {
			// Recua até o fim do bloco anterior para não partir um bloco ao meio.
			$corte = strrpos( substr( $html, 0, $pos ), '<!-- /wp:' );
			if ( false !== $corte ) {
				$fim = strpos( $html, '-->', $corte );
				if ( false !== $fim ) {
					$pos = $fim + 3;
				}
			} else {
				$pos = 0;
			}
		} else {
			// Recua até o início do parágrafo que contém o link.
			$corte = strrpos( substr( $html, 0, $pos ), '<p' );
			if ( false !== $corte ) {
				$pos = $corte;
			}
		}

		return array( substr( $html, 0, $pos ) . $bloco . substr( $html, $pos ), 1 );
	}
}
