<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( is_admin() ) {
			new CPC_Admin();
		}
	}

	public static function activate() {
		add_option( 'cpc_settings', self::defaults() );
	}

	public static function deactivate() {
		CPC_Scanner::limpar_cache();
	}

	public static function defaults() {
		return array_merge(
			array(
				'autor_canonico'   => 'Cristiano Martins',
				'post_types'       => array( 'post' ),
				'guarda_publicar'  => 0,
				'dominios_extra'   => '',
			),
			class_exists( 'CPC_IA' ) ? CPC_IA::defaults() : array()
		);
	}

	public static function settings() {
		$v = get_option( 'cpc_settings', array() );
		return wp_parse_args( is_array( $v ) ? $v : array(), self::defaults() );
	}

	public static function setting( $chave ) {
		$s = self::settings();
		return isset( $s[ $chave ] ) ? $s[ $chave ] : null;
	}

	/**
	 * O plugin grava HTML com <script type="application/ld+json">. Sem a
	 * capability unfiltered_html o WordPress remove o script na gravação e o
	 * "conserto" viraria uma perda de schema silenciosa.
	 */
	public static function pode_gravar_html() {
		return current_user_can( 'unfiltered_html' );
	}
}
