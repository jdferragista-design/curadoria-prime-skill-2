<?php
/**
 * Varredura do acervo, com cache em post meta.
 *
 * Analisar 48 artigos a cada carregamento da tela seria lento e inútil: o
 * resultado só muda quando o post muda. O cache guarda o hash do conteúdo e é
 * descartado sozinho quando o post é editado.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Scanner {

	const META = '_cpc_resultado';

	public static function post_types() {
		$t = CPC_Plugin::setting( 'post_types' );
		return is_array( $t ) && $t ? $t : array( 'post' );
	}

	/** Analisa um post, usando cache quando o conteúdo não mudou. */
	public static function analisar_post( $post_id, $forcar = false ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return null;
		}
		$hash = md5( $post->post_content );

		if ( ! $forcar ) {
			$cache = get_post_meta( $post_id, self::META, true );
			if ( is_array( $cache ) && isset( $cache['hash'] ) && $cache['hash'] === $hash ) {
				return $cache;
			}
		}

		// Um post problemático não pode derrubar a varredura inteira: ele é
		// registrado no relatório e a fila continua.
		try {
			$achados = CPC_Rules::analisar( $post->post_content );
		} catch ( Throwable $e ) {
			CPC_Log::registrar( 'analise_falhou', $post_id, $e->getMessage() );
			return null;
		}

		$total   = 0;
		$altas   = 0;
		$auto    = array();
		foreach ( $achados as $a ) {
			$total += $a['n'];
			if ( 'alta' === $a['gravidade'] ) {
				$altas += $a['n'];
			}
			if ( $a['auto'] ) {
				$auto[] = $a['regra'];
			}
		}

		$res = array(
			'hash'     => $hash,
			'post_id'  => $post_id,
			'titulo'   => get_the_title( $post_id ),
			'achados'  => $achados,
			'total'    => $total,
			'altas'    => $altas,
			'auto'     => $auto,
			'em'       => current_time( 'mysql' ),
		);

		update_post_meta( $post_id, self::META, $res );
		return $res;
	}

	/** Varre todo o acervo. */
	public static function varrer( $forcar = false ) {
		$ids = get_posts(
			array(
				'post_type'        => self::post_types(),
				'post_status'      => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'numberposts'      => -1,
				'fields'           => 'ids',
				'suppress_filters' => true,
			)
		);

		$linhas = array();
		foreach ( $ids as $id ) {
			$r = self::analisar_post( $id, $forcar );
			if ( $r ) {
				$linhas[] = $r;
			}
		}

		usort(
			$linhas,
			function ( $a, $b ) {
				if ( $a['altas'] !== $b['altas'] ) {
					return $b['altas'] - $a['altas'];
				}
				return $b['total'] - $a['total'];
			}
		);
		return $linhas;
	}

	public static function resumo( $linhas ) {
		$r = array(
			'posts'        => count( $linhas ),
			'limpos'       => 0,
			'com_problema' => 0,
			'ocorrencias'  => 0,
			'por_regra'    => array(),
		);
		foreach ( $linhas as $l ) {
			if ( $l['total'] > 0 ) {
				$r['com_problema']++;
			} else {
				$r['limpos']++;
			}
			$r['ocorrencias'] += $l['total'];
			foreach ( $l['achados'] as $a ) {
				if ( ! isset( $r['por_regra'][ $a['regra'] ] ) ) {
					$r['por_regra'][ $a['regra'] ] = array( 'posts' => 0, 'n' => 0, 'auto' => $a['auto'] );
				}
				$r['por_regra'][ $a['regra'] ]['posts']++;
				$r['por_regra'][ $a['regra'] ]['n'] += $a['n'];
			}
		}
		arsort( $r['por_regra'] );
		return $r;
	}

	public static function limpar_cache() {
		delete_post_meta_by_key( self::META );
	}

	public static function csv( $linhas ) {
		$rot = CPC_Rules::rotulos();
		$out = "post_id,titulo,url,total,graves," . implode( ',', array_keys( $rot ) ) . "\n";
		foreach ( $linhas as $l ) {
			$por = array();
			foreach ( $l['achados'] as $a ) {
				$por[ $a['regra'] ] = $a['n'];
			}
			$cols = array();
			foreach ( array_keys( $rot ) as $r ) {
				$cols[] = isset( $por[ $r ] ) ? $por[ $r ] : 0;
			}
			$out .= sprintf(
				"%d,\"%s\",%s,%d,%d,%s\n",
				$l['post_id'],
				str_replace( '"', '""', $l['titulo'] ),
				get_permalink( $l['post_id'] ),
				$l['total'],
				$l['altas'],
				implode( ',', $cols )
			);
		}
		return $out;
	}
}
