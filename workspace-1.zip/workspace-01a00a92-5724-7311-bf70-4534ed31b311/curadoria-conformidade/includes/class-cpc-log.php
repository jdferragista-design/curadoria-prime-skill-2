<?php
/**
 * Registro de incidentes.
 *
 * Tudo que o plugin tenta fazer e NÃO consegue fica gravado aqui: gravação
 * recusada pela trava, bloco de schema ilegível, imagem sem URL para restaurar,
 * regra pedida que não teve efeito. São exatamente os casos que precisam de
 * correção manual depois — sem este registro eles somem num wp_die e ninguém
 * lembra quais posts ficaram para trás.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Log {

	const OPCAO = 'cpc_incidentes';
	const LIMITE = 300;

	/**
	 * Cada tipo traz o diagnóstico e a ação recomendada. É o que transforma o
	 * log num plano de trabalho em vez de um despejo de erros.
	 */
	public static function tipos() {
		return array(
			'trava_seguranca' => array(
				'rotulo'    => 'Gravação recusada pela trava',
				'gravidade' => 'alta',
				'o_que_e'   => 'A correção geraria perda de conteúdo (imagem, link, texto ou schema) e foi abortada antes de gravar.',
				'o_que_faz' => 'Não repita o clique: o HTML de origem tem algo fora do padrão. Abra o post, compare com o diff e corrija à mão.',
			),
			'erro_gravacao' => array(
				'rotulo'    => 'Erro do WordPress ao gravar',
				'gravidade' => 'alta',
				'o_que_e'   => 'A trava passou, mas wp_update_post devolveu erro.',
				'o_que_faz' => 'Normalmente é permissão, plugin de segurança ou limite do servidor. Verifique a mensagem exata na coluna detalhe.',
			),
			'schema_ilegivel' => array(
				'rotulo'    => 'Bloco de schema não faz parse',
				'gravidade' => 'alta',
				'o_que_e'   => 'O JSON-LD está malformado, então o corretor não encostou nele — reescrever por regex quebraria o bloco.',
				'o_que_faz' => 'Conserte o JSON à mão. Causa mais comum no site: aspa reta de polegadas (50" LG) sem escape, muitas vezes vinda do título SEO do Rank Math.',
			),
			'schema_encode_falhou' => array(
				'rotulo'    => 'Falha ao regravar o schema',
				'gravidade' => 'alta',
				'o_que_e'   => 'O bloco fez parse, foi corrigido em memória, mas wp_json_encode não conseguiu serializar de volta.',
				'o_que_faz' => 'Quase sempre é byte inválido de UTF-8 no conteúdo. O bloco foi deixado intacto.',
			),
			'schema_sem_permissao' => array(
				'rotulo'    => 'Correção de schema bloqueada por permissão',
				'gravidade' => 'media',
				'o_que_e'   => 'O usuário não tem unfiltered_html: o WordPress removeria o <script ld+json> inteiro ao salvar.',
				'o_que_faz' => 'Aplique com um administrador, ou peça a capability. As demais regras rodaram normalmente.',
			),
			'edicao_recusada' => array(
				'rotulo'    => 'Reescrita não pôde ser localizada',
				'gravidade' => 'media',
				'o_que_e'   => 'Você reescreveu um trecho, mas ele não foi encontrado uma única vez no conteúdo: ou o texto mudou desde a varredura, ou o mesmo trecho aparece repetido no artigo.',
				'o_que_faz' => 'O plugin se recusa a adivinhar qual ocorrência trocar. Varra o post de novo; se o trecho for repetido, edite-o direto no editor do WordPress.',
			),
			'edicao_bloqueada' => array(
				'rotulo'    => 'Reescrita barrada pela trava de segurança',
				'gravidade' => 'alta',
				'o_que_e'   => 'O resultado da sua reescrita perderia imagens, links, mais de 10% do texto visível ou quebraria um JSON-LD hoje válido.',
				'o_que_faz' => 'Nada foi gravado. Reveja o texto digitado — normalmente é uma tag HTML fechada incorretamente ou um bloco colado por engano.',
			),
			'ia_falhou' => array(
				'rotulo'    => 'Sugestão de IA falhou',
				'gravidade' => 'baixa',
				'o_que_e'   => 'A chamada ao provedor de IA não retornou texto utilizável: chave inválida, crédito esgotado, modelo indisponível, timeout ou teto de gasto atingido.',
				'o_que_faz' => 'Nada foi gravado e nada foi cobrado além da tentativa. Confira chave, modelo e saldo em Configurações. A reescrita manual continua disponível.',
			),
			'img_sem_url' => array(
				'rotulo'    => 'Imagem em placeholder sem URL de origem',
				'gravidade' => 'media',
				'o_que_e'   => 'A tag tem src base64 mas nenhum data-src com a URL real, então não há o que restaurar automaticamente.',
				'o_que_faz' => 'Reinsira a imagem pela biblioteca de mídia. O arquivo original pode ter sido perdido.',
			),
			'divulgacao_sem_ancora' => array(
				'rotulo'    => 'Sem ponto de inserção para a divulgação',
				'gravidade' => 'baixa',
				'o_que_e'   => 'A regra foi pedida mas não há link de afiliado no post para ancorar o bloco.',
				'o_que_faz' => 'Nada a fazer, provavelmente o post não é de afiliado.',
			),
			'regra_sem_efeito' => array(
				'rotulo'    => 'Detector acusa, corretor não resolve',
				'gravidade' => 'media',
				'o_que_e'   => 'A análise apontou o problema neste post, mas a correção automática não alterou nada — detector e corretor discordam.',
				'o_que_faz' => 'É candidato a bug do plugin, não do artigo. Anote o post e a regra: provavelmente o HTML tem uma variação que o corretor não cobre. Corrija à mão por enquanto.',
			),
			'analise_falhou' => array(
				'rotulo'    => 'Erro ao analisar o post',
				'gravidade' => 'alta',
				'o_que_e'   => 'A varredura lançou exceção neste post e ele ficou de fora do relatório.',
				'o_que_faz' => 'Veja a mensagem no detalhe. Post muito grande ou com encoding quebrado são as causas típicas.',
			),
		);
	}

	public static function rotulo( $tipo ) {
		$t = self::tipos();
		return isset( $t[ $tipo ] ) ? $t[ $tipo ]['rotulo'] : $tipo;
	}

	public static function gravidade( $tipo ) {
		$t = self::tipos();
		return isset( $t[ $tipo ] ) ? $t[ $tipo ]['gravidade'] : 'media';
	}

	/**
	 * Grava um incidente. Nunca lança: log que quebra o fluxo é pior que log
	 * ausente.
	 */
	public static function registrar( $tipo, $post_id = 0, $detalhe = '', $regra = '' ) {
		$itens = self::tudo();

		array_unshift(
			$itens,
			array(
				'em'      => function_exists( 'current_time' ) ? current_time( 'mysql' ) : gmdate( 'Y-m-d H:i:s' ),
				'tipo'    => (string) $tipo,
				'post_id' => (int) $post_id,
				'regra'   => (string) $regra,
				'detalhe' => mb_substr( (string) $detalhe, 0, 500, 'UTF-8' ),
				'por'     => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
			)
		);

		if ( count( $itens ) > self::LIMITE ) {
			$itens = array_slice( $itens, 0, self::LIMITE );
		}

		update_option( self::OPCAO, $itens, false );
	}

	/** Registra vários incidentes do mesmo tipo de uma vez. */
	public static function registrar_lote( $tipo, $post_id, $detalhes, $regra = '' ) {
		foreach ( (array) $detalhes as $d ) {
			self::registrar( $tipo, $post_id, $d, $regra );
		}
	}

	public static function tudo() {
		$itens = get_option( self::OPCAO, array() );
		return is_array( $itens ) ? $itens : array();
	}

	/** Agrupa por tipo, para a visão de "o que mais está falhando". */
	public static function por_tipo() {
		$out = array();
		foreach ( self::tudo() as $i ) {
			$t = $i['tipo'];
			if ( ! isset( $out[ $t ] ) ) {
				$out[ $t ] = array( 'n' => 0, 'posts' => array(), 'ultimo' => $i['em'] );
			}
			$out[ $t ]['n']++;
			if ( $i['post_id'] ) {
				$out[ $t ]['posts'][ $i['post_id'] ] = true;
			}
		}
		foreach ( $out as $t => $d ) {
			$out[ $t ]['posts'] = array_keys( $d['posts'] );
		}
		uasort( $out, function ( $a, $b ) {
			return $b['n'] - $a['n'];
		} );
		return $out;
	}

	public static function limpar() {
		delete_option( self::OPCAO );
	}

	public static function csv() {
		$out = "\xEF\xBB\xBF" . "quando,tipo,gravidade,post_id,regra,detalhe\n";
		foreach ( self::tudo() as $i ) {
			$out .= sprintf(
				"%s,%s,%s,%d,%s,\"%s\"\n",
				$i['em'],
				self::rotulo( $i['tipo'] ),
				self::gravidade( $i['tipo'] ),
				$i['post_id'],
				$i['regra'],
				str_replace( '"', '""', $i['detalhe'] )
			);
		}
		return $out;
	}
}
