<?php
/**
 * Detectores de conformidade.
 *
 * Porte direto das regras validadas em corrigir_artigos.py v3, com uma
 * diferença importante: aqui a análise roda sobre post_content vindo do banco,
 * que já é a FONTE. O script em Python precisava de context=edit para não
 * trabalhar em cima do content.rendered — dentro do WordPress esse risco
 * simplesmente não existe.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Rules {

	const REL_CORRETO = 'sponsored noopener noreferrer nofollow';

	public static function autor_canonico() {
		$a = CPC_Plugin::setting( 'autor_canonico' );
		return $a ? $a : 'Cristiano Martins';
	}

	/**
	 * O script em Python só conhecia amazon/mercadolivre. Shopee, Magalu e
	 * AliExpress passavam batido — links de afiliado sem rel="sponsored" são
	 * motivo documentado de ação manual, então entram aqui.
	 */
	public static function dominios_afiliado() {
		$base = array(
			'amazon.com.br', 'amzn.to', 'link.amazon', 'a.co',
			'mercadolivre.com', 'meli.la', 'mercadolivre.com.br',
			'shopee.com.br', 'magazineluiza.com.br', 'magazinevoce.com.br',
			'aliexpress.com', 'americanas.com.br', 'casasbahia.com.br',
			'kabum.com.br', 'shopee.com',
		);
		$extra = (string) CPC_Plugin::setting( 'dominios_extra' );
		if ( $extra ) {
			foreach ( preg_split( '/[\s,]+/', $extra ) as $d ) {
				$d = trim( $d );
				if ( $d ) {
					$base[] = $d;
				}
			}
		}
		return array_values( array_unique( $base ) );
	}

	public static function padroes_teste() {
		return array(
			'/\btestamos\b/iu',
			'/\btestei\b/iu',
			'/\bem nossos testes\b/iu',
			'/\bnos nossos testes\b/iu',
			'/\busei (?:o|a|por)\b/iu',
			'/\busamos (?:o|a|por) \w+ (?:durante|por)\b/iu',
			'/\bdepois de (?:usar|testar)\b/iu',
			'/\bnossa unidade\b/iu',
			'/\bunboxing\b/iu',
			'/\bsentimos na m[ãa]o\b/iu',
			'/\bna nossa bancada\b/iu',
			'/\bmedimos\b/iu',
			'/\bteste de bancada\b/iu',
			'/\btestado(?:s|a|as)? por n[óo]s\b/iu',
			'/\bcolocamos [àa] prova\b/iu',
			'/\bap[óo]s \d+ dias de uso\b/iu',
		);
	}

	/**
	 * Urgência falsa: escassez ou recência que o site não consegue sustentar.
	 * "Preço verificado há 2 horas" é falso no minuto seguinte à publicação.
	 */
	public static function padroes_urgencia() {
		return array(
			'/\bverificad[oa]s? h[áa] \d+\s*(?:hora|minuto|dia)/iu',
			'/\batualizad[oa] h[áa] \d+\s*(?:hora|minuto)/iu',
			'/\bh[áa] (?:poucos? )?(?:minutos|instantes)\b/iu',
			'/\bestoque limitado\b/iu',
			'/\b[úu]ltimas? unidades?\b/iu',
			'/\brestam (?:apenas )?\d+/iu',
			'/\b(?:apenas|s[óo]) \d+ (?:unidades?|pe[çc]as?) (?:em estoque|restantes)/iu',
			'/\boferta (?:expira|termina|acaba)/iu',
			'/\bpor tempo limitado\b/iu',
			'/\bcorra,? (?:antes|que)/iu',
			'/\bpre[çc]o pode (?:mudar|subir) a qualquer momento\b/iu',
			'/\b[úu]ltima chance\b/iu',
			'/\bs[óo] hoje\b/iu',
		);
	}

	private static function negacoes() {
		return '/\b(n[ãa]o|sem|nunca|jamais)\b[\s\w,]{0,25}$/iu';
	}

	/** Texto visível: sem script, style e comentários de bloco. */
	public static function texto_visivel( $html ) {
		$h = preg_replace( '/<script.*?<\/script>/is', ' ', $html );
		$h = preg_replace( '/<style.*?<\/style>/is', ' ', $h );
		$h = preg_replace( '/<!--.*?-->/s', ' ', $h );
		$h = preg_replace( '/<[^>]+>/', ' ', $h );
		$h = html_entity_decode( (string) $h, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$h = str_replace( "\xc2\xa0", ' ', $h );
		return trim( preg_replace( '/\s+/u', ' ', $h ) );
	}

	public static function e_afiliado( $href ) {
		$achou = false;
		foreach ( self::dominios_afiliado() as $d ) {
			if ( false !== stripos( $href, $d ) ) {
				$achou = true;
				break;
			}
		}
		if ( ! $achou ) {
			return false;
		}
		return ! self::e_home_da_loja( $href );
	}

	/**
	 * Link para a HOME da loja (ex.: bloco "Fontes consultadas" citando
	 * https://www.amazon.com.br/) não é link de afiliado: não monetiza e não
	 * deve receber rel="sponsored". Só o caminho vazio conta como home.
	 */
	public static function e_home_da_loja( $href ) {
		$p = wp_parse_url( $href );
		if ( ! is_array( $p ) || ! empty( $p['query'] ) ) {
			return false;
		}
		$caminho = isset( $p['path'] ) ? trim( $p['path'], '/' ) : '';
		return '' === $caminho;
	}

	/** Blocos JSON-LD com posição, para reescrita cirúrgica. */
	public static function blocos_jsonld( $html ) {
		$out = array();
		if ( ! preg_match_all(
			'/<script[^>]*type\s*=\s*["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is',
			$html, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER
		) ) {
			return $out;
		}
		foreach ( $m as $set ) {
			$out[] = array(
				'bruto'  => $set[1][0],
				'inicio' => $set[1][1],
				'tam'    => strlen( $set[1][0] ),
			);
		}
		return $out;
	}

	/**
	 * wpautop injeta <br /> dentro do script. Limpar antes de tentar o parse,
	 * senão um schema perfeitamente válido é reportado como quebrado.
	 */
	public static function limpar_jsonld( $bruto ) {
		$t = preg_replace( '/<br\s*\/?>/i', '', $bruto );
		$t = html_entity_decode( (string) $t, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return trim( $t );
	}

	/**
	 * preg_match_all com PREG_OFFSET_CAPTURE devolve offset em BYTES.
	 * mb_substr conta CARACTERES. Misturar os dois desloca a janela em
	 * 1 posição por byte extra de acento/emoji acumulado desde o início do
	 * texto — no QCY, 1.316 posições no fim do artigo, o que fazia o painel
	 * mostrar o contexto de outro parágrafo.
	 */
	private static function b2c( $txt, $bytes ) {
		return mb_strlen( substr( $txt, 0, $bytes ), 'UTF-8' );
	}

	/** Alinha um offset de byte para o início de um caractere UTF-8. */
	private static function alinhar( $txt, $i ) {
		$n = strlen( $txt );
		if ( $i <= 0 ) {
			return 0;
		}
		if ( $i >= $n ) {
			return $n;
		}
		while ( $i < $n && ( ord( $txt[ $i ] ) & 0xC0 ) === 0x80 ) {
			$i++;
		}
		return $i;
	}

	/** $ini/$fim em bytes. Devolve a janela ao redor, em caracteres. */
	private static function contexto( $txt, $ini, $fim, $margem = 90 ) {
		$ic = self::b2c( $txt, $ini );
		$fc = self::b2c( $txt, $fim );
		$a  = max( 0, $ic - $margem );
		$z  = min( mb_strlen( $txt, 'UTF-8' ), $fc + $margem );

		// Recortar por contagem cega parte palavra ao meio ("-benefício em
		// ANC"), o que faz o painel parecer defeituoso. Recua até o espaço
		// anterior e avança até o próximo.
		if ( $a > 0 ) {
			$esp = mb_strrpos( mb_substr( $txt, 0, $a, 'UTF-8' ), ' ', 0, 'UTF-8' );
			$a   = ( false === $esp ) ? 0 : $esp + 1;
		}
		$total = mb_strlen( $txt, 'UTF-8' );
		if ( $z < $total ) {
			$resto = mb_strpos( $txt, ' ', $z, 'UTF-8' );
			$z     = ( false === $resto ) ? $total : $resto;
		}

		$s = mb_substr( $txt, $a, $z - $a, 'UTF-8' );
		$s = trim( preg_replace( '/\s+/u', ' ', $s ) );

		// Reticências dizem ao leitor que o recorte continua — sem elas o
		// contexto parece um trecho truncado por bug.
		if ( $a > 0 ) {
			$s = '… ' . $s;
		}
		if ( $z < $total ) {
			$s .= ' …';
		}
		return $s;
	}

	/**
	 * Expande a ocorrência até os limites da frase.
	 *
	 * O detector casa um token ("Testamos", "R$ 169"). Esse token não serve
	 * como unidade de edição: aparece 9 vezes no post, então a gravação é
	 * sempre recusada por ambiguidade, e é curto demais para a IA reescrever
	 * com sentido. A frase inteira é única quase sempre e é o que o editor
	 * realmente quer trocar.
	 *
	 * $ini/$fim em bytes. Devolve a frase, já com espaços normalizados.
	 */
	private static function sentenca( $txt, $ini, $fim, $max = 340 ) {
		$ja = self::alinhar( $txt, max( 0, $ini - $max ) );
		$jb = self::alinhar( $txt, min( strlen( $txt ), $fim + $max ) );

		// Início: último fim de frase antes da ocorrência. Exige espaço depois
		// do ponto para não cortar dentro de "R$ 1.299" ou "8.5".
		$antes = substr( $txt, $ja, $ini - $ja );
		$ini_s = $ja;
		if ( preg_match_all( '/(?:[.!?…;]|\s[|•▪]|\s[–—]\s)\s+/u', $antes, $m, PREG_OFFSET_CAPTURE ) ) {
			$ult   = end( $m[0] );
			$ini_s = $ja + $ult[1] + strlen( $ult[0] );
		}

		// Fim: primeiro fim de frase depois da ocorrência.
		$depois = substr( $txt, $fim, $jb - $fim );
		$fim_s  = $jb;
		if ( preg_match( '/(?:[.!?…;]|\s[|•▪]|\s[–—]\s)(?:\s|$)/u', $depois, $m2, PREG_OFFSET_CAPTURE ) ) {
			$fim_s = $fim + $m2[0][1] + strlen( rtrim( $m2[0][0] ) );
		}

		$s = substr( $txt, $ini_s, $fim_s - $ini_s );
		$s = trim( preg_replace( '/\s+/u', ' ', $s ) );

		// Frase absurdamente longa (tabela inteira sem pontuação): não vira
		// campo de edição gigante — cai para a janela ao redor do token.
		if ( '' === $s || mb_strlen( $s, 'UTF-8' ) > 600 ) {
			return self::contexto( $txt, $ini, $fim, 120 );
		}
		return $s;
	}

	/**
	 * Roda todos os detectores. Retorna array de achados por regra.
	 */
	public static function analisar( $html ) {
		$achados = array();

		// ── 1. Alegação de teste físico (texto visível) ──────────────────
		$txt   = self::texto_visivel( $html );
		$ocorr = array();
		foreach ( self::padroes_teste() as $pad ) {
			if ( ! preg_match_all( $pad, $txt, $mm, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}
			foreach ( $mm[0] as $hit ) {
				$ini   = $hit[1];
				$antes = substr( $txt, max( 0, $ini - 45 ), min( 45, $ini ) );
				if ( preg_match( self::negacoes(), $antes ) ) {
					continue; // "não testamos" é declaração honesta
				}
				$janela = substr( $txt, max( 0, $ini - 130 ), 130 );
				if ( substr_count( $janela, '“' ) > substr_count( $janela, '”' ) ) {
					continue; // dentro de citação de terceiro
				}
				$fim     = $ini + strlen( $hit[0] );
				$ocorr[] = array(
					'trecho'   => self::sentenca( $txt, $ini, $fim ),
					'token'    => $hit[0],
					'contexto' => self::contexto( $txt, $ini, $fim, 220 ),
				);
			}
		}
		$ocorr = self::dedup( $ocorr );
		if ( $ocorr ) {
			$achados[] = self::achado( 'alegacao_teste', 'Alegação de teste físico', 'alta', false, $ocorr,
				'O site não testa os produtos fisicamente. Reescrever para metodologia documental: o que foi consultado e o que não dá para concluir sem o aparelho.' );
		}

		// ── 2. Alegação de teste dentro do schema ────────────────────────
		$ocorr = array();
		foreach ( self::blocos_jsonld( $html ) as $b ) {
			if ( ! preg_match_all( '/"(description|headline|name)"\s*:\s*"([^"]{0,500})"/', $b['bruto'], $cs, PREG_SET_ORDER ) ) {
				continue;
			}
			foreach ( $cs as $c ) {
				foreach ( self::padroes_teste() as $pad ) {
					if ( preg_match( $pad, $c[2], $hit ) ) {
						// O editável é o valor inteiro do campo: "Testamos"
						// sozinho aparece no corpo também e a troca seria
						// ambígua. Aqui a string do schema é única.
						$ocorr[] = array(
							'trecho'   => $c[2],
							'token'    => $hit[0],
							'contexto' => $c[1] . ' (schema)',
						);
						break;
					}
				}
			}
		}
		if ( $ocorr ) {
			$achados[] = self::achado( 'alegacao_schema', 'Alegação de teste no schema', 'alta', false, $ocorr,
				'Pior que no corpo: é o texto que vai para o snippet do Google.' );
		}

		// ── 3. Urgência falsa ────────────────────────────────────────────
		$ocorr = array();
		foreach ( self::padroes_urgencia() as $pad ) {
			if ( ! preg_match_all( $pad, $txt, $mm, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}
			foreach ( $mm[0] as $hit ) {
				$fim     = $hit[1] + strlen( $hit[0] );
				$ocorr[] = array(
					'trecho'   => self::sentenca( $txt, $hit[1], $fim ),
					'token'    => $hit[0],
					'contexto' => self::contexto( $txt, $hit[1], $fim, 220 ),
				);
			}
		}
		$ocorr = self::dedup( $ocorr );
		if ( $ocorr ) {
			$achados[] = self::achado( 'urgencia_falsa', 'Urgência ou escassez falsa', 'alta', false, $ocorr,
				'Escassez que o site não verifica. Trocar por data neutra de verificação.' );
		}

		// ── 4. Schema: aggregateRating de terceiros ──────────────────────
		// ── 5. Schema: autor divergente ──────────────────────────────────
		// ── 6. Schema: JSON malformado ───────────────────────────────────
		$agg = array();
		$aut = array();
		$mal = array();
		foreach ( self::blocos_jsonld( $html ) as $i => $b ) {
			$limpo = self::limpar_jsonld( $b['bruto'] );
			$dados = json_decode( $limpo, true );
			if ( null === $dados && JSON_ERROR_NONE !== json_last_error() ) {
				$motivo = json_last_error_msg();
				if ( preg_match( '/\d"(?!\s*[,:\}\]])/', $limpo ) ) {
					$motivo .= ' — provável aspa reta de polegadas dentro da string (50"). Usar "50 polegadas" ou &#8243;.';
				}
				$mal[] = array(
					'trecho'   => 'bloco #' . ( $i + 1 ),
					'contexto' => $motivo,
				);
				continue;
			}
			if ( ! is_array( $dados ) ) {
				continue;
			}
			$c = array( 'agg' => array(), 'autor' => array() );
			self::vistoriar_schema( $dados, $c );
			foreach ( $c['agg'] as $d ) {
				$agg[] = array( 'trecho' => 'bloco #' . ( $i + 1 ), 'contexto' => $d );
			}
			foreach ( $c['autor'] as $d ) {
				$aut[] = array( 'trecho' => 'bloco #' . ( $i + 1 ), 'contexto' => $d );
			}
		}
		if ( $agg ) {
			$achados[] = self::achado( 'schema_agg', 'aggregateRating de terceiros', 'alta', true, $agg,
				'Nota de avaliações da loja apresentada como se fosse do site. Remover aggregateRating/reviewCount/ratingCount e preservar o review /10 do editor.' );
		}
		if ( $aut ) {
			$achados[] = self::achado( 'schema_autor', 'Autor divergente no schema', 'media', true, $aut,
				'Padronizar para ' . self::autor_canonico() . ' em @type: Person.' );
		}
		if ( $mal ) {
			$achados[] = self::achado( 'schema_malformado', 'JSON-LD não faz parse', 'alta', false, $mal,
				'Bloco quebrado é ignorado pelo Google. Não é corrigido automaticamente: reescrever JSON quebrado por regex é como o problema entrou.' );
		}

		// ── 7. Links de afiliado sem rel="sponsored" ─────────────────────
		$ocorr = array();
		if ( preg_match_all( '/<a\b[^>]*>/i', $html, $mm ) ) {
			foreach ( $mm[0] as $tag ) {
				if ( ! preg_match( '/href\s*=\s*["\']([^"\']*)["\']/i', $tag, $h ) ) {
					continue;
				}
				if ( ! self::e_afiliado( $h[1] ) ) {
					continue;
				}
				if ( preg_match( '/\brel\s*=\s*["\'][^"\']*sponsored/i', $tag ) ) {
					continue;
				}
				$ocorr[] = array( 'trecho' => $h[1], 'contexto' => mb_substr( $tag, 0, 200, 'UTF-8' ) );
			}
		}
		if ( $ocorr ) {
			$achados[] = self::achado( 'sponsored', 'Link de afiliado sem rel="sponsored"', 'alta', true, $ocorr,
				'Ausência de sponsored em link de afiliado é motivo documentado de ação manual.' );
		}

		// ── 8. Divulgação de afiliado ausente ────────────────────────────
		$tem_afiliado = false;
		if ( preg_match_all( '/href\s*=\s*["\']([^"\']*)["\']/i', $html, $mm ) ) {
			foreach ( $mm[1] as $href ) {
				if ( self::e_afiliado( $href ) ) {
					$tem_afiliado = true;
					break;
				}
			}
		}
		if ( $tem_afiliado ) {
			$baixo = mb_strtolower( $txt, 'UTF-8' );
			$tem   = false;
			foreach ( array( 'link de afiliado', 'links de afiliado', 'comissão', 'comissao' ) as $k ) {
				if ( false !== mb_strpos( $baixo, $k, 0, 'UTF-8' ) ) {
					$tem = true;
					break;
				}
			}
			if ( ! $tem ) {
				$achados[] = self::achado( 'divulgacao', 'Divulgação de afiliado ausente', 'alta', true,
					array( array( 'trecho' => 'nenhuma menção a comissão', 'contexto' => 'O artigo tem link de afiliado e não avisa o leitor.' ) ),
					'Exigência da FTC e do Google. O bloco é inserido antes do primeiro link de afiliado.' );
			}
		}

		// ── 9. Imagem com lazy-load residual ─────────────────────────────
		$ocorr = array();
		if ( preg_match_all( '/<img\b[^>]*>/i', $html, $mm ) ) {
			foreach ( $mm[0] as $tag ) {
				$b64  = (bool) preg_match( '/src\s*=\s*["\']data:image/i', $tag );
				$dsrc = (bool) preg_match( '/\bdata-src\s*=/i', $tag );
				$lazy = (bool) preg_match( '/\bdata-lazyloaded\s*=/i', $tag );
				if ( $b64 || $dsrc || $lazy ) {
					$ocorr[] = array(
						'trecho'   => $b64 ? 'src base64 (placeholder)' : ( $dsrc ? 'URL real presa em data-src' : 'data-lazyloaded residual' ),
						'contexto' => mb_substr( preg_replace( '/data:image\/[^"\']{0,40}[^"\']*/', 'data:image/…', $tag ), 0, 200, 'UTF-8' ),
					);
				}
			}
		}
		if ( $ocorr ) {
			$achados[] = self::achado( 'img_lazy', 'Imagem com placeholder de lazy-load salvo no banco', 'alta', true, $ocorr,
				'O placeholder base64 foi gravado no conteúdo: a imagem nunca aparece. Promover data-src para src.' );
		}

		// ── 10. Preço sem data de verificação ────────────────────────────
		$ocorr = array();
		if ( preg_match_all( '/R\$\s?\d{1,3}(?:\.\d{3})*(?:,\d{2})?/u', $txt, $mm, PREG_OFFSET_CAPTURE ) ) {
			$vistos = array();
			foreach ( $mm[0] as $hit ) {
				$jan = substr( $txt, max( 0, $hit[1] - 170 ), 340 );
				if ( preg_match( '/\d{1,2}\/\d{1,2}\/\d{2,4}|\b(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-zç]*\.?\s*\/?\s*(?:de\s*)?20\d\d|atualizado|verificado em|consultado em/iu', $jan ) ) {
					continue;
				}
				if ( isset( $vistos[ $hit[0] ] ) ) {
					continue;
				}
				$vistos[ $hit[0] ] = 1;
				$fim               = $hit[1] + strlen( $hit[0] );
				$ocorr[]           = array(
					'trecho'   => self::sentenca( $txt, $hit[1], $fim ),
					'token'    => $hit[0],
					'contexto' => self::contexto( $txt, $hit[1], $fim, 220 ),
				);
			}
		}
		$ocorr = self::dedup( $ocorr );
		if ( $ocorr ) {
			$achados[] = self::achado( 'preco_sem_data', 'Preço sem data de verificação', 'media', false, $ocorr,
				'Preço fixo sem data apodrece sozinho. Acrescentar a data ao lado do valor.' );
		}

		return self::fundir_entre_regras( $achados );
	}

	/**
	 * Uma frase só pode ser editada UMA vez.
	 *
	 * "O ANC do T13 supera qualquer earbud na mesma faixa de preço que
	 * testamos — e a maioria dos que custam até R$ 280." dispara
	 * alegacao_teste E preco_sem_data. Viravam dois campos com o MESMO texto
	 * original: o editor corrige nos dois, o primeiro grava e o segundo é
	 * recusado com "não encontrei este trecho" — porque o primeiro acabou de
	 * reescrevê-lo. A recusa é correta e a mensagem é enganosa.
	 *
	 * A frase fica no achado mais grave e deixa de ser CAMPO EDITÁVEL nos
	 * demais, carregando os tokens das duas regras para o editor ver que
	 * precisa resolver ambos.
	 *
	 * O achado que cedeu a frase CONTINUA no relatório e ['n'] segue contando
	 * a detecção: quem lê estatística (scanner, CSV, painel) não pode ver uma
	 * regra sumir do artigo só porque outra regra ficou com o campo de texto.
	 * As frases cedidas ficam em ['movidas'] => [ ['trecho'=>…, 'para'=>regra] ].
	 */
	private static function fundir_entre_regras( $achados ) {
		$peso  = array( 'alta' => 3, 'media' => 2, 'baixa' => 1 );
		$dono  = array();

		// Manuais primeiro, mais grave ganha a frase.
		$ordem = array();
		foreach ( $achados as $i => $a ) {
			if ( ! $a['auto'] ) {
				$ordem[ $i ] = isset( $peso[ $a['gravidade'] ] ) ? $peso[ $a['gravidade'] ] : 0;
			}
		}
		arsort( $ordem );

		foreach ( array_keys( $ordem ) as $i ) {
			$mantidas = array();
			$movidas  = array();
			foreach ( $achados[ $i ]['ocorrencias'] as $o ) {
				$k = $o['trecho'];
				if ( isset( $dono[ $k ] ) ) {
					// Já é campo de outra regra: doa os tokens e deixa de ser campo aqui.
					list( $ai, $oi ) = $dono[ $k ];
					foreach ( ( isset( $o['tokens'] ) ? $o['tokens'] : array() ) as $t ) {
						if ( ! in_array( $t, $achados[ $ai ]['ocorrencias'][ $oi ]['tokens'], true ) ) {
							$achados[ $ai ]['ocorrencias'][ $oi ]['tokens'][] = $t;
						}
					}
					$achados[ $ai ]['ocorrencias'][ $oi ]['tambem'][] = $achados[ $i ]['regra'];
					$movidas[] = array(
						'trecho' => $o['trecho'],
						'para'   => $achados[ $ai ]['regra'],
					);
					continue;
				}
				$dono[ $k ] = array( $i, count( $mantidas ) );
				$mantidas[] = $o;
			}
			$achados[ $i ]['ocorrencias'] = $mantidas;
			$achados[ $i ]['movidas']     = $movidas;
			// ['n'] NÃO muda: a detecção continua existindo, só mudou de campo.
		}

		return $achados;
	}

	/**
	 * Duas ocorrências na mesma frase viram um campo só.
	 *
	 * "Testamos o fone ... por menos de R$ 250" casava 2 vezes e virava dois
	 * campos com o MESMO texto editável — o editor preencheria os dois, o
	 * primeiro gravaria e o segundo seria recusado por "não encontrei".
	 */
	private static function dedup( $ocorr ) {
		$out    = array();
		$vistos = array();
		foreach ( $ocorr as $o ) {
			$k = $o['trecho'];
			if ( isset( $vistos[ $k ] ) ) {
				$i = $vistos[ $k ];
				if ( isset( $o['token'] ) && ! in_array( $o['token'], (array) $out[ $i ]['tokens'], true ) ) {
					$out[ $i ]['tokens'][] = $o['token'];
				}
				continue;
			}
			$o['tokens']  = isset( $o['token'] ) ? array( $o['token'] ) : array();
			$vistos[ $k ] = count( $out );
			$out[]        = $o;
		}
		return $out;
	}

	private static function achado( $regra, $titulo, $gravidade, $auto, $ocorrencias, $nota = '' ) {
		// Normaliza aqui, num ponto só: nem todo detector passa por dedup(),
		// e consumidor que fizesse foreach em ['tokens'] fatalava nos que não
		// passavam (alegacao_schema, sponsored, img_lazy…).
		foreach ( $ocorrencias as $i => $o ) {
			if ( ! isset( $o['tokens'] ) ) {
				$ocorrencias[ $i ]['tokens'] = isset( $o['token'] ) ? array( $o['token'] ) : array();
			}
			if ( ! isset( $o['tambem'] ) ) {
				$ocorrencias[ $i ]['tambem'] = array();
			}
		}

		return array(
			'regra'       => $regra,
			'titulo'      => $titulo,
			'gravidade'   => $gravidade,
			'auto'        => (bool) $auto,
			'n'           => count( $ocorrencias ),
			'ocorrencias' => array_slice( $ocorrencias, 0, 25 ),
			'movidas'     => array(),
			'nota'        => $nota,
		);
	}

	/** Percorre o schema procurando rating de terceiros e autor divergente. */
	private static function vistoriar_schema( $no, &$c, $caminho = '' ) {
		if ( ! is_array( $no ) ) {
			return;
		}
		if ( isset( $no['aggregateRating'] ) ) {
			$r  = $no['aggregateRating'];
			$vl = is_array( $r ) && isset( $r['ratingValue'] ) ? $r['ratingValue'] : '?';
			$qt = is_array( $r ) && isset( $r['reviewCount'] ) ? $r['reviewCount'] : ( is_array( $r ) && isset( $r['ratingCount'] ) ? $r['ratingCount'] : '?' );
			$c['agg'][] = trim( $caminho . ' aggregateRating ' . $vl . ' de ' . $qt . ' avaliações' );
		}
		if ( isset( $no['@type'] ) && 'Person' === $no['@type'] && isset( $no['name'] ) ) {
			if ( self::autor_canonico() !== $no['name'] ) {
				$c['autor'][] = trim( $caminho . ' author: "' . $no['name'] . '"' );
			}
		}
		foreach ( $no as $k => $v ) {
			if ( is_array( $v ) ) {
				self::vistoriar_schema( $v, $c, is_string( $k ) ? $caminho . ' ' . $k : $caminho );
			}
		}
	}

	public static function rotulos() {
		return array(
			'alegacao_teste'    => 'Alegação de teste',
			'alegacao_schema'   => 'Teste no schema',
			'urgencia_falsa'    => 'Urgência falsa',
			'schema_agg'        => 'aggregateRating',
			'schema_autor'      => 'Autor do schema',
			'schema_malformado' => 'Schema quebrado',
			'sponsored'         => 'Sem sponsored',
			'divulgacao'        => 'Sem divulgação',
			'img_lazy'          => 'Imagem quebrada',
			'preco_sem_data'    => 'Preço sem data',
		);
	}
}
