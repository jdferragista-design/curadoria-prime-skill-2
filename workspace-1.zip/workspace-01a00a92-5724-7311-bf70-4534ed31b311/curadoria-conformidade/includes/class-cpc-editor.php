<?php
/**
 * Edição trecho a trecho dentro do próprio plugin.
 *
 * O fluxo antigo mandava o editor abrir o post no Gutenberg, caçar o trecho e
 * reescrever à mão. Aqui cada ocorrência vira um campo: o texto original de um
 * lado, a caixa editável do outro, com um botão opcional de sugestão por IA.
 *
 * A substituição é literal e ancorada: procura o trecho exato no post_content
 * e troca só ele. Se o trecho aparecer mais de uma vez ou nenhuma, a operação
 * é recusada em vez de adivinhar — trocar a ocorrência errada em um artigo
 * publicado é pior do que não trocar nada.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Editor {

	/**
	 * Troca UM trecho no conteúdo. Devolve [novo_html, erro].
	 */
	public static function substituir( $html, $original, $novo, $todas = false ) {
		$original = (string) $original;
		$novo     = (string) $novo;

		if ( '' === trim( $original ) ) {
			return array( $html, __( 'Trecho original vazio.', 'curadoria-conformidade' ) );
		}
		if ( $original === $novo ) {
			return array( $html, __( 'O texto não mudou.', 'curadoria-conformidade' ) );
		}

		$n = substr_count( $html, $original );

		if ( 1 === $n ) {
			return array( str_replace( $original, $novo, $html ), '' );
		}

		// Strings de schema/meta são repetidas de propósito: a mesma
		// description vive em <meta>, og:description e no JSON-LD. Trocar
		// só uma deixaria o snippet inconsistente, então aqui trocar todas
		// é o comportamento correto — e é sempre opt-in de quem chama.
		if ( $todas && $n > 1 ) {
			return array( str_replace( $original, $novo, $html ), '' );
		}

		if ( 0 === $n ) {
			// O detector trabalha sobre o texto visível; o conteúdo pode ter
			// tags no meio do trecho. Tenta uma âncora tolerante a espaços.
			$alvo = self::localizar_flexivel( $html, $original );
			if ( null === $alvo ) {
				return array(
					$html,
					__( 'Não encontrei este trecho exato no conteúdo do post. Ele pode ter sido editado desde a última varredura, ou estar quebrado por tags HTML. Use "abrir no editor".', 'curadoria-conformidade' ),
				);
			}
			return array( substr_replace( $html, $novo, $alvo[0], $alvo[1] ), '' );
		}

		return array(
			$html,
			sprintf(
				/* translators: %d: número de ocorrências */
				__( 'Este trecho aparece %d vezes no post. Para não trocar a ocorrência errada, edite-o no editor do WordPress.', 'curadoria-conformidade' ),
				$n
			),
		);
	}

	/**
	 * Casa o trecho ignorando diferenças de espaço em branco e entidades
	 * simples. Só aceita se houver exatamente uma correspondência.
	 */
	private static function localizar_flexivel( $html, $trecho ) {
		$partes = preg_split( '/\s+/u', trim( $trecho ), -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $partes ) {
			return null;
		}

		// Junta entre as palavras: espaço, &nbsp;, e QUALQUER sequência de
		// tags. O limite de 120 caracteres por tag reprovava o artigo real,
		// onde <a style="color: #667eea; font-weight: 600;" href="..."> passa
		// de 200. Sem limite superior, mas sem permitir texto solto no meio.
		$juncao = '(?:\s|&nbsp;|&#160;|<[^>]*>)*';

		$escapadas = array();
		foreach ( $partes as $p ) {
			// A palavra pode estar entidificada no banco (&#8220;) ou ter
			// tag no meio dela (pa<strong>lavra</strong>): casa caractere a
			// caractere, tolerando tags entre eles.
			$chars = preg_split( '//u', $p, -1, PREG_SPLIT_NO_EMPTY );
			$exp   = array();
			foreach ( $chars as $ch ) {
				$alt = array( preg_quote( $ch, '/' ) );
				$ent = htmlentities( $ch, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				if ( $ent !== $ch ) {
					$alt[] = preg_quote( $ent, '/' );
				}
				$num = 'a' === $ch ? '' : mb_ord( $ch, 'UTF-8' );
				if ( $num ) {
					$alt[] = '&#' . $num . ';';
				}
				$exp[] = '(?:' . implode( '|', $alt ) . ')';
			}
			$escapadas[] = implode( '(?:<[^>]*>)*', $exp );
		}

		$padrao = '/' . implode( $juncao, $escapadas ) . '/u';

		if ( ! preg_match_all( $padrao, $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return null;
		}
		if ( 1 !== count( $m[0] ) ) {
			return null;
		}
		return array( $m[0][0][1], strlen( $m[0][0][0] ) );
	}

	/**
	 * Aplica um lote de substituições vindas do formulário.
	 * $edicoes = [ ['original'=>..., 'novo'=>..., 'regra'=>...], ... ]
	 * Devolve [novo_html, aplicadas[], recusadas[]].
	 */
	public static function aplicar_lote( $html, $edicoes ) {
		$aplicadas = array();
		$recusadas = array();

		foreach ( $edicoes as $e ) {
			$original = isset( $e['original'] ) ? $e['original'] : '';
			$novo     = isset( $e['novo'] ) ? $e['novo'] : '';
			$regra    = isset( $e['regra'] ) ? $e['regra'] : '';

			if ( '' === trim( $novo ) || $original === $novo ) {
				continue; // Campo não mexido: não é erro, é ausência de edição.
			}

			// A description do schema é intencionalmente repetida em <meta>,
			// og:description e JSON-LD. Corrigir só uma cópia deixaria o
			// snippet do Google divergindo do resto da página.
			$todas = ( 'alegacao_schema' === $regra );

			list( $html, $erro ) = self::substituir( $html, $original, $novo, $todas );
			if ( $erro ) {
				$recusadas[] = array( 'regra' => $regra, 'trecho' => $original, 'erro' => $erro );
			} else {
				$aplicadas[] = array( 'regra' => $regra, 'de' => $original, 'para' => $novo );
			}
		}

		return array( $html, $aplicadas, $recusadas );
	}
}
