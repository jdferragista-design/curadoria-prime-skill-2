<?php
/**
 * Telas do painel e handlers.
 *
 * Segurança, no mesmo padrão do plugin de imagens:
 *   - nonce em toda ação que escreve
 *   - current_user_can( 'edit_post', $id ) por objeto, não só na tela
 *   - nada é gravado sem o formulário de aprovação ter sido enviado
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Admin {

	private $hook_painel = '';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_cpc_aplicar', array( $this, 'handler_aplicar' ) );
		add_action( 'admin_post_cpc_varrer', array( $this, 'handler_varrer' ) );
		add_action( 'admin_post_cpc_csv', array( $this, 'handler_csv' ) );
		add_action( 'admin_post_cpc_salvar_config', array( $this, 'handler_config' ) );
		add_action( 'admin_post_cpc_falhas_csv', array( $this, 'handler_falhas_csv' ) );
		add_action( 'admin_post_cpc_falhas_limpar', array( $this, 'handler_falhas_limpar' ) );
		add_action( 'admin_post_cpc_editar', array( $this, 'handler_editar' ) );
		add_action( 'admin_post_cpc_uso_limpar', array( $this, 'handler_uso_limpar' ) );
		add_action( 'wp_ajax_cpc_sugerir', array( $this, 'ajax_sugerir' ) );
		add_action( 'add_meta_boxes', array( $this, 'metabox' ) );
	}

	public function menu() {
		$this->hook_painel = add_menu_page(
			__( 'Conformidade Editorial', 'curadoria-conformidade' ),
			__( 'Conformidade', 'curadoria-conformidade' ),
			'edit_others_posts',
			'cpc-painel',
			array( $this, 'tela' ),
			'dashicons-shield-alt',
			26
		);
		$n_falhas = count( CPC_Log::tudo() );
		add_submenu_page(
			'cpc-painel',
			__( 'Relatório de falhas', 'curadoria-conformidade' ),
			$n_falhas
				? sprintf( __( 'Falhas %s', 'curadoria-conformidade' ), '<span class="update-plugins count-' . (int) $n_falhas . '"><span class="update-count">' . (int) $n_falhas . '</span></span>' )
				: __( 'Falhas', 'curadoria-conformidade' ),
			'edit_others_posts',
			'cpc-falhas',
			array( $this, 'tela_falhas' )
		);
		add_submenu_page(
			'cpc-painel',
			__( 'Configurações', 'curadoria-conformidade' ),
			__( 'Configurações', 'curadoria-conformidade' ),
			'manage_options',
			'cpc-config',
			array( $this, 'tela_config' )
		);
	}

	public function assets( $hook ) {
		if ( false === strpos( $hook, 'cpc-' ) && 'post.php' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'cpc-admin', CPC_URL . 'assets/admin.css', array(), CPC_VERSION );
		wp_enqueue_script( 'cpc-admin', CPC_URL . 'assets/admin.js', array(), CPC_VERSION, true );
		wp_localize_script(
			'cpc-admin',
			'CPC',
			array(
				'ajax'    => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'cpc_sugerir' ),
				'ia'      => CPC_IA::pronta() ? 1 : 0,
				'i18n'    => array(
					'pensando' => __( 'consultando a IA…', 'curadoria-conformidade' ),
					'sugerir'  => __( 'Sugerir com IA', 'curadoria-conformidade' ),
					'erro'     => __( 'Falhou', 'curadoria-conformidade' ),
					'restaura' => __( 'restaurar original', 'curadoria-conformidade' ),
					'lote'     => __( 'Sugerir para todos os %d trechos', 'curadoria-conformidade' ),
					'loteAnda' => __( 'sugerindo %1$d de %2$d…', 'curadoria-conformidade' ),
					'loteFim'  => __( '%1$d de %2$d preenchidos. Revise e salve.', 'curadoria-conformidade' ),
					'loteErro' => __( '%d falharam — os campos vazios continuam seus.', 'curadoria-conformidade' ),
					'parar'    => __( 'parar', 'curadoria-conformidade' ),
				),
			)
		);
	}

	// ───────────────────────── tela principal ─────────────────────────

	public function tela() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		$post_id = isset( $_GET['post_id'] ) ? absint( $_GET['post_id'] ) : 0;
		if ( $post_id ) {
			$this->tela_post( $post_id );
			return;
		}
		$this->tela_lista();
	}

	private function tela_lista() {
		$linhas = CPC_Scanner::varrer( false );
		$resumo = CPC_Scanner::resumo( $linhas );
		$rot    = CPC_Rules::rotulos();
		?>
		<div class="wrap cpc">
			<h1><?php esc_html_e( 'Conformidade Editorial', 'curadoria-conformidade' ); ?></h1>

			<?php if ( isset( $_GET['ok'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>
					<?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['ok'] ) ) ); ?>
				</p></div>
			<?php endif; ?>

			<?php if ( isset( $_GET['erro'] ) ) : ?>
				<div class="notice notice-error is-dismissible"><p>
					<?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['erro'] ) ) ); ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=cpc-falhas' ) ); ?>"><?php esc_html_e( 'Ver relatório de falhas', 'curadoria-conformidade' ); ?></a>
				</p></div>
			<?php endif; ?>

			<?php
			$cpc_inc = CPC_Log::tudo();
			if ( $cpc_inc ) :
				?>
				<div class="notice notice-warning is-dismissible"><p>
					<?php
					printf(
						/* translators: %d: número de incidentes */
						esc_html__( '%d ocorrência(s) no relatório de falhas — coisas que o plugin não conseguiu corrigir sozinho.', 'curadoria-conformidade' ),
						count( $cpc_inc )
					);
					?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=cpc-falhas' ) ); ?>"><?php esc_html_e( 'Abrir relatório', 'curadoria-conformidade' ); ?></a>
				</p></div>
			<?php endif; ?>

			<?php if ( ! CPC_Plugin::pode_gravar_html() ) : ?>
				<div class="notice notice-warning"><p>
					<strong><?php esc_html_e( 'Atenção:', 'curadoria-conformidade' ); ?></strong>
					<?php esc_html_e( 'seu usuário não tem a permissão unfiltered_html. O WordPress removeria os blocos de schema ao gravar. Correções de schema estão desativadas.', 'curadoria-conformidade' ); ?>
				</p></div>
			<?php endif; ?>

			<div class="cpc-cards">
				<div class="cpc-card"><span class="cpc-num"><?php echo (int) $resumo['posts']; ?></span><span class="cpc-lbl"><?php esc_html_e( 'artigos', 'curadoria-conformidade' ); ?></span></div>
				<div class="cpc-card cpc-ok"><span class="cpc-num"><?php echo (int) $resumo['limpos']; ?></span><span class="cpc-lbl"><?php esc_html_e( 'sem problema', 'curadoria-conformidade' ); ?></span></div>
				<div class="cpc-card cpc-bad"><span class="cpc-num"><?php echo (int) $resumo['com_problema']; ?></span><span class="cpc-lbl"><?php esc_html_e( 'com problema', 'curadoria-conformidade' ); ?></span></div>
				<div class="cpc-card"><span class="cpc-num"><?php echo (int) $resumo['ocorrencias']; ?></span><span class="cpc-lbl"><?php esc_html_e( 'ocorrências', 'curadoria-conformidade' ); ?></span></div>
			</div>

			<p class="cpc-acoes">
				<?php $this->botao( 'cpc_varrer', __( 'Reanalisar tudo', 'curadoria-conformidade' ), 'button' ); ?>
				<?php $this->botao( 'cpc_csv', __( 'Baixar CSV', 'curadoria-conformidade' ), 'button' ); ?>
			</p>

			<?php if ( $resumo['por_regra'] ) : ?>
			<h2><?php esc_html_e( 'Por tipo de problema', 'curadoria-conformidade' ); ?></h2>
			<table class="widefat striped cpc-regras">
				<thead><tr>
					<th><?php esc_html_e( 'Problema', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Artigos', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Ocorrências', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Correção', 'curadoria-conformidade' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $resumo['por_regra'] as $regra => $d ) : ?>
					<tr>
						<td><strong><?php echo esc_html( isset( $rot[ $regra ] ) ? $rot[ $regra ] : $regra ); ?></strong></td>
						<td><?php echo (int) $d['posts']; ?></td>
						<td><?php echo (int) $d['n']; ?></td>
						<td><?php echo $d['auto']
							? '<span class="cpc-tag cpc-tag-auto">' . esc_html__( 'automática', 'curadoria-conformidade' ) . '</span>'
							: '<span class="cpc-tag cpc-tag-manual">' . esc_html__( 'reescrita humana', 'curadoria-conformidade' ) . '</span>'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Artigos', 'curadoria-conformidade' ); ?></h2>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Artigo', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Graves', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Total', 'curadoria-conformidade' ); ?></th>
					<th><?php esc_html_e( 'Problemas', 'curadoria-conformidade' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $linhas as $l ) : ?>
					<tr class="<?php echo $l['total'] ? '' : 'cpc-linha-ok'; ?>">
						<td>
							<strong><?php echo esc_html( $l['titulo'] ); ?></strong>
							<div class="row-actions"><span>#<?php echo (int) $l['post_id']; ?> ·
								<a href="<?php echo esc_url( get_edit_post_link( $l['post_id'] ) ); ?>"><?php esc_html_e( 'editar', 'curadoria-conformidade' ); ?></a> ·
								<a href="<?php echo esc_url( get_permalink( $l['post_id'] ) ); ?>" target="_blank"><?php esc_html_e( 'ver', 'curadoria-conformidade' ); ?></a>
							</span></div>
						</td>
						<td><?php echo $l['altas'] ? '<span class="cpc-badge cpc-badge-alta">' . (int) $l['altas'] . '</span>' : '—'; ?></td>
						<td><?php echo (int) $l['total']; ?></td>
						<td>
							<?php foreach ( $l['achados'] as $a ) : ?>
								<span class="cpc-chip cpc-chip-<?php echo esc_attr( $a['gravidade'] ); ?>"><?php
									echo esc_html( isset( $rot[ $a['regra'] ] ) ? $rot[ $a['regra'] ] : $a['regra'] );
								?> <b><?php echo (int) $a['n']; ?></b></span>
							<?php endforeach; ?>
							<?php if ( ! $l['achados'] ) : ?><span class="cpc-ok-txt">✓</span><?php endif; ?>
						</td>
						<td>
							<?php if ( $l['total'] ) : ?>
								<a class="button button-primary" href="<?php echo esc_url( add_query_arg( array( 'page' => 'cpc-painel', 'post_id' => $l['post_id'] ), admin_url( 'admin.php' ) ) ); ?>">
									<?php esc_html_e( 'Revisar', 'curadoria-conformidade' ); ?>
								</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	// ───────────────────────── tela do post ─────────────────────────

	private function tela_post( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'Sem permissão para editar este artigo.', 'curadoria-conformidade' ) );
		}
		$res = CPC_Scanner::analisar_post( $post_id, true );
		$rot = CPC_Rules::rotulos();

		$auto = array_values( array_intersect( $res['auto'], CPC_Fixer::regras_automaticas() ) );
		if ( ! CPC_Plugin::pode_gravar_html() ) {
			$auto = array_values( array_diff( $auto, array( 'schema_agg', 'schema_autor' ) ) );
		}

		$preview = null;
		if ( $auto ) {
			list( $novo, $log ) = CPC_Fixer::aplicar( $post->post_content, $auto );
			$erros   = CPC_Diff::validar( $post->post_content, $novo );
			$preview = array( 'novo' => $novo, 'log' => $log, 'erros' => $erros );
		}
		?>
		<div class="wrap cpc">
			<h1>
				<?php esc_html_e( 'Revisar:', 'curadoria-conformidade' ); ?>
				<?php echo esc_html( $res['titulo'] ); ?>
			</h1>
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=cpc-painel' ) ); ?>">&larr; <?php esc_html_e( 'voltar', 'curadoria-conformidade' ); ?></a> ·
				<a href="<?php echo esc_url( get_edit_post_link( $post_id ) ); ?>"><?php esc_html_e( 'abrir no editor', 'curadoria-conformidade' ); ?></a> ·
				<a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" target="_blank"><?php esc_html_e( 'ver publicado', 'curadoria-conformidade' ); ?></a>
			</p>

			<h2><?php esc_html_e( 'O que foi encontrado', 'curadoria-conformidade' ); ?></h2>

			<?php
			$manuais = array();
			foreach ( $res['achados'] as $a ) {
				if ( ! $a['auto'] ) {
					$manuais[] = $a;
				}
			}
			?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cpc-form-editar">
			<input type="hidden" name="action" value="cpc_editar">
			<input type="hidden" name="post_id" value="<?php echo (int) $post_id; ?>">
			<?php wp_nonce_field( 'cpc_editar_' . $post_id ); ?>

			<?php $idx = 0; ?>
			<?php foreach ( $res['achados'] as $a ) : ?>
				<div class="cpc-achado cpc-g-<?php echo esc_attr( $a['gravidade'] ); ?>">
					<h3>
						<?php echo esc_html( isset( $rot[ $a['regra'] ] ) ? $rot[ $a['regra'] ] : $a['regra'] ); ?>
						<span class="cpc-badge"><?php echo (int) $a['n']; ?></span>
						<?php echo $a['auto']
							? '<span class="cpc-tag cpc-tag-auto">' . esc_html__( 'corrige sozinho', 'curadoria-conformidade' ) . '</span>'
							: '<span class="cpc-tag cpc-tag-manual">' . esc_html__( 'exige reescrita sua', 'curadoria-conformidade' ) . '</span>'; ?>
					</h3>
					<?php if ( $a['nota'] ) : ?><p class="cpc-nota"><?php echo esc_html( $a['nota'] ); ?></p><?php endif; ?>

					<?php if ( $a['auto'] ) : ?>
						<ul class="cpc-ocorrencias">
							<?php foreach ( $a['ocorrencias'] as $o ) : ?>
								<li>
									<code><?php echo esc_html( $o['trecho'] ); ?></code>
									<span class="cpc-ctx"><?php echo esc_html( $o['contexto'] ); ?></span>
								</li>
							<?php endforeach; ?>
							<?php if ( $a['n'] > count( $a['ocorrencias'] ) ) : ?>
								<li class="cpc-mais">… e mais <?php echo (int) ( $a['n'] - count( $a['ocorrencias'] ) ); ?></li>
							<?php endif; ?>
						</ul>
					<?php else : ?>
						<?php foreach ( $a['ocorrencias'] as $o ) : ?>
							<?php $idx++; ?>
							<div class="cpc-edit" data-regra="<?php echo esc_attr( $a['regra'] ); ?>">
								<div class="cpc-edit-orig">
									<span class="cpc-edit-rot"><?php esc_html_e( 'como está', 'curadoria-conformidade' ); ?></span>
									<?php
									// Realça dentro da frase o que o detector marcou, para
									// o editor não ter que caçar o motivo do campo existir.
									$frase = esc_html( $o['trecho'] );
									foreach ( ( isset( $o['tokens'] ) ? $o['tokens'] : array() ) as $tk ) {
										$e = preg_quote( esc_html( $tk ), '/' );
										$frase = preg_replace( '/' . $e . '/u', '<mark class="cpc-hit">$0</mark>', $frase, 1 );
									}
									?>
									<code><?php echo wp_kses( $frase, array( 'mark' => array( 'class' => array() ) ) ); ?></code>
									<?php if ( ! empty( $o['tambem'] ) ) : ?>
										<?php
										$rot = CPC_Rules::rotulos();
										$nomes = array();
										foreach ( array_unique( $o['tambem'] ) as $r2 ) {
											$nomes[] = isset( $rot[ $r2 ] ) ? $rot[ $r2 ] : $r2;
										}
										?>
										<span class="cpc-tambem"><?php
											echo esc_html( sprintf(
												/* translators: %s: lista de regras */
												__( 'Esta frase também resolve: %s — corrija os dois pontos de uma vez.', 'curadoria-conformidade' ),
												implode( ', ', $nomes )
											) );
										?></span>
									<?php endif; ?>
									<span class="cpc-ctx"><?php echo esc_html( $o['contexto'] ); ?></span>
								</div>
								<div class="cpc-edit-novo">
									<span class="cpc-edit-rot"><?php esc_html_e( 'como deve ficar', 'curadoria-conformidade' ); ?></span>
									<input type="hidden" name="ed[<?php echo (int) $idx; ?>][original]" value="<?php echo esc_attr( $o['trecho'] ); ?>">
									<input type="hidden" name="ed[<?php echo (int) $idx; ?>][regra]" value="<?php echo esc_attr( $a['regra'] ); ?>">
									<textarea
										name="ed[<?php echo (int) $idx; ?>][novo]"
										rows="3"
										class="cpc-ta large-text"
										data-original="<?php echo esc_attr( $o['trecho'] ); ?>"
										data-contexto="<?php echo esc_attr( $o['contexto'] ); ?>"
										data-regra="<?php echo esc_attr( $a['regra'] ); ?>"
										data-titulo="<?php echo esc_attr( $res['titulo'] ); ?>"
										placeholder="<?php esc_attr_e( 'Deixe em branco para não mexer neste trecho.', 'curadoria-conformidade' ); ?>"></textarea>
									<p class="cpc-edit-acoes">
										<?php if ( CPC_IA::pronta() ) : ?>
											<button type="button" class="button button-small cpc-ia-btn"><?php esc_html_e( 'Sugerir com IA', 'curadoria-conformidade' ); ?></button>
										<?php endif; ?>
										<button type="button" class="button-link cpc-copiar"><?php esc_html_e( 'copiar original', 'curadoria-conformidade' ); ?></button>
										<span class="cpc-ia-status"></span>
									</p>
								</div>
							</div>
						<?php endforeach; ?>
						<?php if ( ! empty( $a['movidas'] ) ) : ?>
							<?php $rot = CPC_Rules::rotulos(); ?>
							<div class="cpc-movidas">
								<p><?php
									echo esc_html( sprintf(
										/* translators: %d: número de trechos */
										_n(
											'%d trecho desta regra está na mesma frase de outra e é editado lá — assim você não corrige o mesmo texto duas vezes:',
											'%d trechos desta regra estão na mesma frase de outras e são editados lá — assim você não corrige o mesmo texto duas vezes:',
											count( $a['movidas'] ),
											'curadoria-conformidade'
										),
										count( $a['movidas'] )
									) );
								?></p>
								<ul>
									<?php foreach ( $a['movidas'] as $mv ) : ?>
										<li>
											<code><?php echo esc_html( mb_strimwidth( $mv['trecho'], 0, 120, '…', 'UTF-8' ) ); ?></code>
											<em><?php
												echo esc_html( sprintf(
													/* translators: %s: nome da regra */
													__( '→ editar em "%s"', 'curadoria-conformidade' ),
													isset( $rot[ $mv['para'] ] ) ? $rot[ $mv['para'] ] : $mv['para']
												) );
											?></em>
										</li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endif; ?>
						<?php
						$restantes = (int) $a['n'] - count( $a['ocorrencias'] ) - count( $a['movidas'] );
						?>
						<?php if ( $restantes > 0 ) : ?>
							<p class="cpc-mais">… e mais <?php echo (int) $restantes; ?> <?php esc_html_e( 'ocorrência(s). Salve estas e varra de novo para ver as próximas.', 'curadoria-conformidade' ); ?></p>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>

			<?php if ( $manuais ) : ?>
				<?php if ( ! CPC_IA::pronta() ) : ?>
					<p class="cpc-hint">
						<?php
						printf(
							/* translators: %s: link para configurações */
							esc_html__( 'Quer sugestões automáticas de reescrita? Configure a IA em %s.', 'curadoria-conformidade' ),
							'<a href="' . esc_url( admin_url( 'admin.php?page=cpc-config' ) ) . '">' . esc_html__( 'Configurações', 'curadoria-conformidade' ) . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
				<?php if ( CPC_IA::pronta() ) : ?>
					<?php
					$n_campos = 0;
					foreach ( $manuais as $mm ) {
						$n_campos += count( $mm['ocorrencias'] );
					}
					$est = CPC_IA::estimativa( CPC_Plugin::setting( 'modelo_openrouter' ), $n_campos );
					?>
					<p class="cpc-lote">
						<button type="button" class="button button-secondary cpc-ia-lote" data-total="<?php echo (int) $n_campos; ?>">
							<?php
							echo esc_html( sprintf(
								/* translators: %d: número de trechos */
								__( 'Sugerir para todos os %d trechos', 'curadoria-conformidade' ),
								$n_campos
							) );
							?>
						</button>
						<span class="cpc-lote-status"></span>
						<span class="cpc-hint">
							<?php
							echo esc_html( sprintf(
								/* translators: %s: custo estimado */
								__( 'Preenche as caixas vazias de uma vez. Nada é gravado até você salvar. Custo estimado: R$ %s.', 'curadoria-conformidade' ),
								null === $est ? '?' : number_format_i18n( $est, 4 )
							) );
							?>
						</span>
					</p>
				<?php endif; ?>
				<p>
					<label>
						<input type="checkbox" name="confirmo" value="1" required>
						<?php esc_html_e( 'Revisei os textos que escrevi acima e autorizo a gravação.', 'curadoria-conformidade' ); ?>
					</label>
				</p>
				<p>
					<button type="submit" class="button button-primary">
						<?php esc_html_e( 'Salvar minhas reescritas', 'curadoria-conformidade' ); ?>
					</button>
					<span class="cpc-hint"><?php esc_html_e( 'Só os campos preenchidos são gravados. Uma revisão é criada antes.', 'curadoria-conformidade' ); ?></span>
				</p>
			<?php endif; ?>
			</form>

			<?php if ( $preview && $preview['log'] ) : ?>
				<h2><?php esc_html_e( 'Correção proposta', 'curadoria-conformidade' ); ?></h2>
				<ul class="cpc-log">
					<?php foreach ( $preview['log'] as $l ) : ?>
						<li>✓ <?php echo esc_html( $l ); ?></li>
					<?php endforeach; ?>
				</ul>

				<?php if ( $preview['erros'] ) : ?>
					<div class="notice notice-error"><p>
						<strong><?php esc_html_e( 'Gravação bloqueada pela trava de segurança:', 'curadoria-conformidade' ); ?></strong><br>
						<?php echo esc_html( implode( '; ', $preview['erros'] ) ); ?>
					</p></div>
				<?php endif; ?>

				<?php echo CPC_Diff::render( $post->post_content, $preview['novo'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<?php if ( ! $preview['erros'] ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cpc-form-aplicar">
					<input type="hidden" name="action" value="cpc_aplicar">
					<input type="hidden" name="post_id" value="<?php echo (int) $post_id; ?>">
					<?php foreach ( $auto as $r ) : ?>
						<input type="hidden" name="regras[]" value="<?php echo esc_attr( $r ); ?>">
					<?php endforeach; ?>
					<?php wp_nonce_field( 'cpc_aplicar_' . $post_id ); ?>
					<p>
						<label>
							<input type="checkbox" name="confirmo" value="1" required>
							<?php esc_html_e( 'Revisei o comparativo acima e autorizo a gravação.', 'curadoria-conformidade' ); ?>
						</label>
					</p>
					<p>
						<button type="submit" class="button button-primary button-hero">
							<?php esc_html_e( 'Aprovar e salvar', 'curadoria-conformidade' ); ?>
						</button>
						<span class="cpc-hint"><?php esc_html_e( 'Uma revisão é criada antes da gravação — dá para reverter pelo histórico do post.', 'curadoria-conformidade' ); ?></span>
					</p>
				</form>
				<?php endif; ?>
			<?php elseif ( $res['total'] ) : ?>
				<div class="notice notice-info"><p>
					<?php esc_html_e( 'Nenhum item deste artigo o plugin corrige sozinho: todos precisam de texto seu. Escreva nas caixas "como deve ficar" acima (ou use a IA) e clique em "Salvar minhas reescritas" — a gravação é feita aqui mesmo, no post. Não é preciso abrir o editor do WordPress nem copiar trecho por trecho.', 'curadoria-conformidade' ); ?>
				</p></div>
			<?php else : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Este artigo está em conformidade.', 'curadoria-conformidade' ); ?></p></div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ───────────────────────── metabox no editor ─────────────────────────

	public function metabox() {
		foreach ( CPC_Scanner::post_types() as $pt ) {
			add_meta_box( 'cpc_box', __( 'Conformidade editorial', 'curadoria-conformidade' ), array( $this, 'render_metabox' ), $pt, 'side', 'high' );
		}
	}

	public function render_metabox( $post ) {
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return;
		}
		$res = CPC_Scanner::analisar_post( $post->ID, true );
		$rot = CPC_Rules::rotulos();
		if ( ! $res || ! $res['total'] ) {
			echo '<p class="cpc-ok-txt">✓ ' . esc_html__( 'Sem problemas detectados.', 'curadoria-conformidade' ) . '</p>';
			return;
		}
		echo '<ul class="cpc-mini">';
		foreach ( $res['achados'] as $a ) {
			printf(
				'<li><span class="cpc-chip cpc-chip-%s">%s <b>%d</b></span></li>',
				esc_attr( $a['gravidade'] ),
				esc_html( isset( $rot[ $a['regra'] ] ) ? $rot[ $a['regra'] ] : $a['regra'] ),
				(int) $a['n']
			);
		}
		echo '</ul>';
		printf(
			'<p><a class="button" href="%s">%s</a></p>',
			esc_url( add_query_arg( array( 'page' => 'cpc-painel', 'post_id' => $post->ID ), admin_url( 'admin.php' ) ) ),
			esc_html__( 'Revisar e corrigir', 'curadoria-conformidade' )
		);
	}

	// ───────────────────────── handlers ─────────────────────────

	public function handler_aplicar() {
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		check_admin_referer( 'cpc_aplicar_' . $post_id );

		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( esc_html__( 'A confirmação é obrigatória.', 'curadoria-conformidade' ) );
		}

		$post = get_post( $post_id );
		$regras = isset( $_POST['regras'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['regras'] ) ) : array();
		$regras = array_values( array_intersect( $regras, CPC_Fixer::regras_automaticas() ) );
		if ( ! CPC_Plugin::pode_gravar_html() ) {
			$barradas = array_intersect( $regras, array( 'schema_agg', 'schema_autor' ) );
			if ( $barradas ) {
				CPC_Log::registrar(
					'schema_sem_permissao',
					$post_id,
					'Regras ignoradas por falta de unfiltered_html: ' . implode( ', ', $barradas ),
					implode( ',', $barradas )
				);
			}
			$regras = array_values( array_diff( $regras, array( 'schema_agg', 'schema_autor' ) ) );
		}
		if ( ! $regras ) {
			$this->voltar( $post_id, __( 'Nenhuma regra aplicável.', 'curadoria-conformidade' ) );
		}

		list( $novo, $log ) = CPC_Fixer::aplicar( $post->post_content, $regras );

		// Persiste o que a correção tentou e não conseguiu. Só aqui, no clique
		// real: a pré-visualização não deve poluir o relatório.
		//
		// "Regra sem efeito" só é sinal quando o analisador tinha acusado aquela
		// regra e mesmo assim nada mudou — aí há discrepância entre detector e
		// corretor, que é bug. Se a regra só foi marcada por atacado na tela e
		// não havia o problema, é silêncio esperado e não vira registro.
		$detectadas = array();
		$analise    = CPC_Scanner::analisar_post( $post_id );
		if ( is_array( $analise ) && ! empty( $analise['achados'] ) ) {
			$detectadas = wp_list_pluck( $analise['achados'], 'regra' );
		}
		foreach ( CPC_Fixer::incidentes() as $inc ) {
			if ( 'regra_sem_efeito' === $inc['tipo'] ) {
				$alvo = 'schema' === $inc['regra'] ? array( 'schema_agg', 'schema_autor' ) : array( $inc['regra'] );
				if ( ! array_intersect( $alvo, $detectadas ) ) {
					continue;
				}
				$inc['detalhe'] .= ' — mas a análise deste post acusava o problema. Divergência entre detector e corretor.';
			}
			CPC_Log::registrar( $inc['tipo'], $post_id, $inc['detalhe'], $inc['regra'] );
		}

		if ( $novo === $post->post_content ) {
			$this->voltar( $post_id, __( 'Nada mudou.', 'curadoria-conformidade' ) );
		}

		// Recalcula a trava no momento da gravação: o post pode ter sido
		// editado entre a pré-visualização e o clique.
		$erros = CPC_Diff::validar( $post->post_content, $novo );
		if ( $erros ) {
			CPC_Log::registrar(
				'trava_seguranca',
				$post_id,
				implode( '; ', $erros ) . ' | regras: ' . implode( ', ', $regras ),
				implode( ',', $regras )
			);
			$this->voltar(
				$post_id,
				__( 'Gravação recusada pela trava de segurança: ', 'curadoria-conformidade' ) . implode( '; ', $erros )
					. __( ' — registrado no relatório de falhas.', 'curadoria-conformidade' ),
				'erro'
			);
		}

		wp_save_post_revision( $post_id );
		$r = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_content' => wp_slash( $novo ),
			),
			true
		);
		if ( is_wp_error( $r ) ) {
			CPC_Log::registrar( 'erro_gravacao', $post_id, $r->get_error_message(), implode( ',', $regras ) );
			$this->voltar( $post_id, __( 'O WordPress recusou a gravação: ', 'curadoria-conformidade' ) . $r->get_error_message(), 'erro' );
		}

		update_post_meta( $post_id, '_cpc_ultima_correcao', array( 'em' => current_time( 'mysql' ), 'por' => get_current_user_id(), 'log' => $log ) );
		delete_post_meta( $post_id, CPC_Scanner::META );

		$this->voltar( 0, sprintf( __( 'Artigo #%1$d atualizado: %2$s', 'curadoria-conformidade' ), $post_id, implode( '; ', $log ) ) );
	}

	public function handler_varrer() {
		check_admin_referer( 'cpc_varrer' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		CPC_Scanner::varrer( true );
		$this->voltar( 0, __( 'Acervo reanalisado.', 'curadoria-conformidade' ) );
	}

	public function handler_csv() {
		check_admin_referer( 'cpc_csv' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		$csv = CPC_Scanner::csv( CPC_Scanner::varrer( false ) );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=conformidade-' . gmdate( 'Y-m-d' ) . '.csv' );
		echo "\xEF\xBB\xBF" . $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public function handler_config() {
		check_admin_referer( 'cpc_config' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		$s = CPC_Plugin::settings();
		$s['autor_canonico'] = isset( $_POST['autor_canonico'] ) ? sanitize_text_field( wp_unslash( $_POST['autor_canonico'] ) ) : $s['autor_canonico'];
		$s['dominios_extra'] = isset( $_POST['dominios_extra'] ) ? sanitize_textarea_field( wp_unslash( $_POST['dominios_extra'] ) ) : '';
		$s['post_types']     = isset( $_POST['post_types'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['post_types'] ) ) : array( 'post' );

		// ── IA ──
		$s['ia_ativa']          = empty( $_POST['ia_ativa'] ) ? 0 : 1;
		$s['fallback']          = empty( $_POST['fallback'] ) ? 0 : 1;
		$s['provedor_primario'] = ( isset( $_POST['provedor_primario'] ) && 'cline' === $_POST['provedor_primario'] ) ? 'cline' : 'openrouter';
		$s['modelo_openrouter'] = isset( $_POST['modelo_openrouter'] ) ? sanitize_text_field( wp_unslash( $_POST['modelo_openrouter'] ) ) : '';
		$s['modelo_cline']      = isset( $_POST['modelo_cline'] ) ? sanitize_text_field( wp_unslash( $_POST['modelo_cline'] ) ) : '';
		$s['temperatura']       = isset( $_POST['temperatura'] ) ? max( 0, min( 100, absint( $_POST['temperatura'] ) ) ) : 20;
		$s['teto_mensal_brl']   = isset( $_POST['teto_mensal_brl'] ) ? max( 0, absint( $_POST['teto_mensal_brl'] ) ) : 20;
		$s['cambio']            = isset( $_POST['cambio'] ) ? max( 1, absint( $_POST['cambio'] ) ) : 545;

		// Chave em branco = manter a que já existe. Só grava se veio texto novo.
		foreach ( array( 'chave_openrouter', 'chave_cline' ) as $campo ) {
			$v = isset( $_POST[ $campo ] ) ? trim( (string) wp_unslash( $_POST[ $campo ] ) ) : '';
			if ( '' !== $v && 0 !== strpos( $v, '••' ) ) {
				$s[ $campo ] = sanitize_text_field( $v );
			}
			if ( ! empty( $_POST[ $campo . '_limpar' ] ) ) {
				$s[ $campo ] = '';
			}
		}

		update_option( 'cpc_settings', $s );
		CPC_Scanner::limpar_cache();
		wp_safe_redirect( add_query_arg( 'ok', rawurlencode( __( 'Configurações salvas.', 'curadoria-conformidade' ) ), admin_url( 'admin.php?page=cpc-config' ) ) );
		exit;
	}

	public function tela_config() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		$s   = CPC_Plugin::settings();
		$pts = get_post_types( array( 'public' => true ), 'objects' );
		?>
		<div class="wrap cpc">
			<h1><?php esc_html_e( 'Conformidade — Configurações', 'curadoria-conformidade' ); ?></h1>
			<?php if ( isset( $_GET['ok'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['ok'] ) ) ); ?></p></div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cpc_salvar_config">
				<?php wp_nonce_field( 'cpc_config' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="autor_canonico"><?php esc_html_e( 'Autor canônico', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<input name="autor_canonico" id="autor_canonico" type="text" class="regular-text" value="<?php echo esc_attr( $s['autor_canonico'] ); ?>">
							<p class="description"><?php esc_html_e( 'Nome que deve constar em @type: Person no schema.', 'curadoria-conformidade' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Tipos de conteúdo', 'curadoria-conformidade' ); ?></th>
						<td>
							<?php foreach ( $pts as $pt ) : ?>
								<label style="margin-right:14px">
									<input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $pt->name ); ?>"
										<?php checked( in_array( $pt->name, (array) $s['post_types'], true ) ); ?>>
									<?php echo esc_html( $pt->labels->name ); ?>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dominios_extra"><?php esc_html_e( 'Domínios de afiliado extras', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<textarea name="dominios_extra" id="dominios_extra" rows="3" class="large-text code"><?php echo esc_textarea( $s['dominios_extra'] ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'Um por linha. Já inclusos: Amazon, Mercado Livre, Shopee, Magalu, AliExpress, Americanas, Casas Bahia, KaBuM.', 'curadoria-conformidade' ); ?>
							</p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Reescrita assistida por IA', 'curadoria-conformidade' ); ?></h2>
				<p class="description" style="max-width:640px">
					<?php esc_html_e( 'A IA sugere o texto substituto de um trecho por vez. Ela nunca grava sozinha: a sugestão cai na caixa de edição e você aprova. Os achados automáticos (schema, rel sponsored) continuam sendo corrigidos sem IA e sem custo.', 'curadoria-conformidade' ); ?>
				</p>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Ativar', 'curadoria-conformidade' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="ia_ativa" value="1" <?php checked( ! empty( $s['ia_ativa'] ) ); ?>>
								<?php esc_html_e( 'Mostrar o botão "Sugerir com IA" nas telas de revisão', 'curadoria-conformidade' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Provedor primário', 'curadoria-conformidade' ); ?></th>
						<td>
							<select name="provedor_primario">
								<option value="openrouter" <?php selected( 'openrouter', $s['provedor_primario'] ); ?>>OpenRouter</option>
								<option value="cline" <?php selected( 'cline', $s['provedor_primario'] ); ?>>Cline API</option>
							</select>
							<label style="margin-left:14px">
								<input type="checkbox" name="fallback" value="1" <?php checked( ! empty( $s['fallback'] ) ); ?>>
								<?php esc_html_e( 'Se falhar, tentar o outro provedor', 'curadoria-conformidade' ); ?>
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="chave_openrouter"><?php esc_html_e( 'Chave OpenRouter', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<input name="chave_openrouter" id="chave_openrouter" type="password" class="regular-text" autocomplete="new-password"
								value="" placeholder="<?php echo esc_attr( '' !== $s['chave_openrouter'] ? '•••••••• ' . __( '(salva — deixe em branco para manter)', 'curadoria-conformidade' ) : 'sk-or-v1-…' ); ?>">
							<?php if ( '' !== $s['chave_openrouter'] ) : ?>
								<label style="margin-left:10px"><input type="checkbox" name="chave_openrouter_limpar" value="1"> <?php esc_html_e( 'apagar', 'curadoria-conformidade' ); ?></label>
							<?php endif; ?>
							<p class="description"><?php esc_html_e( 'openrouter.ai/keys — cobra por token, sem mensalidade.', 'curadoria-conformidade' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="modelo_openrouter"><?php esc_html_e( 'Modelo OpenRouter', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<input name="modelo_openrouter" id="modelo_openrouter" type="text" class="regular-text code" value="<?php echo esc_attr( $s['modelo_openrouter'] ); ?>" placeholder="google/gemini-3.1-flash-lite">
							<p class="description"><?php esc_html_e( 'Sugeridos por custo/qualidade: google/gemini-3.1-flash-lite, openai/gpt-5-mini, deepseek/deepseek-v4-flash.', 'curadoria-conformidade' ); ?></p>
							<?php
							// 1.219 = campos manuais estimados nos 53 artigos do último scan.
							$precos = CPC_IA::tabela_precos();
							$atual  = $s['modelo_openrouter'];
							?>
							<table class="cpc-precos">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Modelo', 'curadoria-conformidade' ); ?></th>
										<th><?php esc_html_e( 'Um artigo (23 campos)', 'curadoria-conformidade' ); ?></th>
										<th><?php esc_html_e( 'Site inteiro (53 artigos)', 'curadoria-conformidade' ); ?></th>
									</tr>
								</thead>
								<tbody>
								<?php foreach ( $precos as $mod => $_ ) : ?>
									<tr<?php echo $mod === $atual ? ' class="cpc-preco-atual"' : ''; ?>>
										<td><code><?php echo esc_html( $mod ); ?></code><?php
											echo $mod === $atual ? ' <strong>' . esc_html__( '← em uso', 'curadoria-conformidade' ) . '</strong>' : '';
										?></td>
										<td>R$ <?php echo esc_html( number_format_i18n( CPC_IA::estimativa( $mod, 23 ), 2 ) ); ?></td>
										<td>R$ <?php echo esc_html( number_format_i18n( CPC_IA::estimativa( $mod, 1219 ), 2 ) ); ?></td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
							<p class="description"><?php esc_html_e( 'Estimativa a 556 tokens de entrada e 215 de saída por campo (média medida). O valor cobrado de fato vem do provedor e aparece no medidor.', 'curadoria-conformidade' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="chave_cline"><?php esc_html_e( 'Chave Cline', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<input name="chave_cline" id="chave_cline" type="password" class="regular-text" autocomplete="new-password"
								value="" placeholder="<?php echo esc_attr( '' !== $s['chave_cline'] ? '•••••••• ' . __( '(salva — deixe em branco para manter)', 'curadoria-conformidade' ) : '' ); ?>">
							<?php if ( '' !== $s['chave_cline'] ) : ?>
								<label style="margin-left:10px"><input type="checkbox" name="chave_cline_limpar" value="1"> <?php esc_html_e( 'apagar', 'curadoria-conformidade' ); ?></label>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="modelo_cline"><?php esc_html_e( 'Modelo Cline', 'curadoria-conformidade' ); ?></label></th>
						<td><input name="modelo_cline" id="modelo_cline" type="text" class="regular-text code" value="<?php echo esc_attr( $s['modelo_cline'] ); ?>"></td>
					</tr>

					<tr>
						<th scope="row"><label for="temperatura"><?php esc_html_e( 'Temperatura', 'curadoria-conformidade' ); ?></label></th>
						<td>
							<input name="temperatura" id="temperatura" type="number" min="0" max="100" step="5" value="<?php echo (int) $s['temperatura']; ?>" class="small-text"> / 100
							<p class="description"><?php esc_html_e( 'Baixo = mais literal e previsível. 20 é um bom padrão para texto editorial.', 'curadoria-conformidade' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="teto_mensal_brl"><?php esc_html_e( 'Teto de gasto mensal', 'curadoria-conformidade' ); ?></label></th>
						<td>
							R$ <input name="teto_mensal_brl" id="teto_mensal_brl" type="number" min="0" step="1" value="<?php echo (int) $s['teto_mensal_brl']; ?>" class="small-text">
							<span style="margin-left:14px"><?php esc_html_e( 'Câmbio: R$', 'curadoria-conformidade' ); ?>
								<input name="cambio" type="number" min="1" step="1" value="<?php echo (int) $s['cambio']; ?>" class="small-text"> <?php esc_html_e( 'centavos por US$ 1', 'curadoria-conformidade' ); ?>
							</span>
							<p class="description"><?php esc_html_e( 'Ao atingir o teto, o botão de IA para de funcionar até o mês virar. Zero = sem teto.', 'curadoria-conformidade' ); ?></p>
						</td>
					</tr>
				</table>

				<?php
				$mes    = CPC_IA::uso_do_mes();
				$hist   = CPC_IA::uso();
				$teto   = (float) $s['teto_mensal_brl'];
				$gasto  = CPC_IA::brl( $mes['usd'] );
				?>
				<h3><?php esc_html_e( 'Consumo deste mês', 'curadoria-conformidade' ); ?></h3>
				<p class="cpc-uso">
					<strong><?php echo esc_html( number_format_i18n( $mes['chamadas'] ) ); ?></strong> <?php esc_html_e( 'chamadas', 'curadoria-conformidade' ); ?> ·
					<strong><?php echo esc_html( number_format_i18n( $mes['tokens_in'] + $mes['tokens_out'] ) ); ?></strong> <?php esc_html_e( 'tokens', 'curadoria-conformidade' ); ?> ·
					<strong>R$ <?php echo esc_html( number_format_i18n( $gasto, 2 ) ); ?></strong>
					<?php if ( $teto > 0 ) : ?>
						<?php echo esc_html( sprintf( __( 'de R$ %s', 'curadoria-conformidade' ), number_format_i18n( $teto, 2 ) ) ); ?>
						<?php if ( $gasto >= $teto ) : ?>
							<span class="cpc-tag cpc-tag-manual"><?php esc_html_e( 'teto atingido', 'curadoria-conformidade' ); ?></span>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( $mes['chamadas'] > 0 ) : ?>
						· <?php echo esc_html( sprintf( __( 'média R$ %s por trecho', 'curadoria-conformidade' ), number_format_i18n( $gasto / max( 1, $mes['chamadas'] ), 4 ) ) ); ?>
					<?php endif; ?>
				</p>
				<?php if ( $hist ) : ?>
					<details>
						<summary><?php esc_html_e( 'ver últimas chamadas', 'curadoria-conformidade' ); ?></summary>
						<table class="widefat striped" style="max-width:900px;margin-top:8px">
							<thead><tr>
								<th><?php esc_html_e( 'quando', 'curadoria-conformidade' ); ?></th>
								<th><?php esc_html_e( 'post', 'curadoria-conformidade' ); ?></th>
								<th><?php esc_html_e( 'regra', 'curadoria-conformidade' ); ?></th>
								<th><?php esc_html_e( 'modelo', 'curadoria-conformidade' ); ?></th>
								<th><?php esc_html_e( 'tokens', 'curadoria-conformidade' ); ?></th>
								<th><?php esc_html_e( 'custo', 'curadoria-conformidade' ); ?></th>
							</tr></thead>
							<tbody>
							<?php foreach ( array_slice( $hist, 0, 25 ) as $u ) : ?>
								<tr>
									<td><?php echo esc_html( $u['em'] ); ?></td>
									<td><?php echo esc_html( get_the_title( $u['post_id'] ) ? mb_substr( get_the_title( $u['post_id'] ), 0, 40, 'UTF-8' ) : (int) $u['post_id'] ); ?></td>
									<td><code><?php echo esc_html( $u['regra'] ); ?></code></td>
									<td><small><?php echo esc_html( $u['modelo'] ); ?></small></td>
									<td><?php echo esc_html( number_format_i18n( (int) $u['tokens_in'] + (int) $u['tokens_out'] ) ); ?></td>
									<td>R$ <?php echo esc_html( number_format_i18n( CPC_IA::brl( (float) $u['usd'] ), 4 ) ); ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</details>
				<?php endif; ?>

				<?php submit_button(); ?>
			</form>

			<?php if ( CPC_IA::uso() ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cpc_uso_limpar">
					<?php wp_nonce_field( 'cpc_uso_limpar' ); ?>
					<button type="submit" class="button button-small"><?php esc_html_e( 'Zerar histórico de uso', 'curadoria-conformidade' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	// ───────────────────────── relatório de falhas ─────────────────────────

	/**
	 * Não é um dump de erros: é a lista de trabalho manual que sobrou. Cada
	 * tipo vem com o que aconteceu e o que fazer a respeito.
	 */
	public function tela_falhas() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		$itens  = CPC_Log::tudo();
		$tipos  = CPC_Log::tipos();
		$grupos = CPC_Log::por_tipo();
		?>
		<div class="wrap cpc">
			<h1><?php esc_html_e( 'Relatório de falhas', 'curadoria-conformidade' ); ?></h1>

			<?php if ( isset( $_GET['ok'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['ok'] ) ) ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $itens ) : ?>
				<div class="notice notice-success"><p>
					<?php esc_html_e( 'Nenhuma falha registrada. Tudo que foi aplicado até agora funcionou.', 'curadoria-conformidade' ); ?>
				</p></div>
			<?php else : ?>

				<p class="cpc-hint" style="margin-left:0">
					<?php esc_html_e( 'O que o plugin tentou corrigir e não conseguiu. Cada linha é um item que precisa de correção manual.', 'curadoria-conformidade' ); ?>
				</p>

				<h2><?php esc_html_e( 'O que mais está falhando', 'curadoria-conformidade' ); ?></h2>
				<?php foreach ( $grupos as $tipo => $g ) : ?>
					<?php $meta = isset( $tipos[ $tipo ] ) ? $tipos[ $tipo ] : null; ?>
					<div class="cpc-achado cpc-g-<?php echo esc_attr( CPC_Log::gravidade( $tipo ) ); ?>">
						<h3>
							<?php echo esc_html( CPC_Log::rotulo( $tipo ) ); ?>
							<span class="cpc-badge<?php echo 'alta' === CPC_Log::gravidade( $tipo ) ? ' cpc-badge-alta' : ''; ?>"><?php echo (int) $g['n']; ?></span>
						</h3>
						<?php if ( $meta ) : ?>
							<p class="cpc-nota"><?php echo esc_html( $meta['o_que_e'] ); ?></p>
							<p><strong><?php esc_html_e( 'O que fazer:', 'curadoria-conformidade' ); ?></strong> <?php echo esc_html( $meta['o_que_faz'] ); ?></p>
						<?php endif; ?>
						<?php if ( $g['posts'] ) : ?>
							<p class="cpc-nota">
								<?php esc_html_e( 'Artigos afetados:', 'curadoria-conformidade' ); ?>
								<?php foreach ( $g['posts'] as $pid ) : ?>
									<a class="cpc-chip" href="<?php echo esc_url( add_query_arg( array( 'page' => 'cpc-painel', 'post_id' => $pid ), admin_url( 'admin.php' ) ) ); ?>">#<?php echo (int) $pid; ?></a>
								<?php endforeach; ?>
							</p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>

				<h2><?php esc_html_e( 'Histórico', 'curadoria-conformidade' ); ?></h2>
				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Quando', 'curadoria-conformidade' ); ?></th>
							<th><?php esc_html_e( 'Tipo', 'curadoria-conformidade' ); ?></th>
							<th><?php esc_html_e( 'Artigo', 'curadoria-conformidade' ); ?></th>
							<th><?php esc_html_e( 'Detalhe', 'curadoria-conformidade' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $itens as $i ) : ?>
						<tr>
							<td style="white-space:nowrap"><?php echo esc_html( $i['em'] ); ?></td>
							<td>
								<span class="cpc-chip cpc-chip-<?php echo 'alta' === CPC_Log::gravidade( $i['tipo'] ) ? 'alta' : 'media'; ?>">
									<?php echo esc_html( CPC_Log::rotulo( $i['tipo'] ) ); ?>
								</span>
							</td>
							<td>
								<?php if ( $i['post_id'] ) : ?>
									<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'cpc-painel', 'post_id' => $i['post_id'] ), admin_url( 'admin.php' ) ) ); ?>">#<?php echo (int) $i['post_id']; ?></a>
									<div class="cpc-ctx"><?php echo esc_html( wp_trim_words( get_the_title( $i['post_id'] ), 8 ) ); ?></div>
								<?php else : ?>
									—
								<?php endif; ?>
							</td>
							<td><span class="cpc-ctx"><?php echo esc_html( $i['detalhe'] ); ?></span></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<p class="cpc-acoes" style="margin-top:16px">
					<?php $this->botao( 'cpc_falhas_csv', __( 'Baixar CSV das falhas', 'curadoria-conformidade' ), 'button' ); ?>
					<?php $this->botao( 'cpc_falhas_limpar', __( 'Limpar relatório', 'curadoria-conformidade' ), 'button' ); ?>
					<span class="cpc-hint"><?php esc_html_e( 'Limpar apaga só o histórico; não desfaz nem refaz correção nenhuma.', 'curadoria-conformidade' ); ?></span>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	public function handler_falhas_csv() {
		check_admin_referer( 'cpc_falhas_csv' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=conformidade-falhas-' . gmdate( 'Y-m-d' ) . '.csv' );
		echo CPC_Log::csv(); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	public function handler_falhas_limpar() {
		check_admin_referer( 'cpc_falhas_limpar' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		CPC_Log::limpar();
		wp_safe_redirect(
			add_query_arg(
				'ok',
				rawurlencode( __( 'Relatório limpo.', 'curadoria-conformidade' ) ),
				admin_url( 'admin.php?page=cpc-falhas' )
			)
		);
		exit;
	}

	// ───────────────────────── edição manual + IA ─────────────────────────

	/**
	 * Grava as reescritas digitadas na tela. Passa pelas mesmas travas do
	 * caminho automático: nonce, capability, confirmação, CPC_Diff::validar()
	 * e revisão do post antes de gravar.
	 */
	public function handler_editar() {
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		check_admin_referer( 'cpc_editar_' . $post_id );

		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( esc_html__( 'A confirmação é obrigatória.', 'curadoria-conformidade' ) );
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			$this->voltar( 0, __( 'Post não encontrado.', 'curadoria-conformidade' ), 'erro' );
		}

		$brutas  = isset( $_POST['ed'] ) ? (array) wp_unslash( $_POST['ed'] ) : array();
		$edicoes = array();
		foreach ( $brutas as $e ) {
			if ( ! is_array( $e ) || ! isset( $e['original'], $e['novo'] ) ) {
				continue;
			}
			if ( '' === trim( (string) $e['novo'] ) ) {
				continue;
			}
			$edicoes[] = array(
				'original' => (string) $e['original'],
				'novo'     => CPC_Plugin::pode_gravar_html()
					? wp_kses_post( (string) $e['novo'] )
					: sanitize_textarea_field( (string) $e['novo'] ),
				'regra'    => isset( $e['regra'] ) ? sanitize_key( $e['regra'] ) : '',
			);
		}

		if ( ! $edicoes ) {
			$this->voltar( $post_id, __( 'Nenhum campo foi preenchido.', 'curadoria-conformidade' ) );
		}

		list( $novo, $aplicadas, $recusadas ) = CPC_Editor::aplicar_lote( $post->post_content, $edicoes );

		foreach ( $recusadas as $r ) {
			CPC_Log::registrar( 'edicao_recusada', $post_id, $r['erro'] . ' — trecho: ' . mb_substr( $r['trecho'], 0, 120, 'UTF-8' ), $r['regra'] );
		}

		if ( ! $aplicadas ) {
			$this->voltar( $post_id, __( 'Nenhuma reescrita pôde ser aplicada. Veja o relatório de falhas.', 'curadoria-conformidade' ), 'erro' );
		}

		$erros = CPC_Diff::validar( $post->post_content, $novo );
		if ( $erros ) {
			CPC_Log::registrar( 'edicao_bloqueada', $post_id, implode( '; ', $erros ) );
			$this->voltar( $post_id, __( 'Gravação bloqueada pela trava de segurança: ', 'curadoria-conformidade' ) . implode( '; ', $erros ), 'erro' );
		}

		wp_update_post(
			array(
				'ID'           => $post_id,
				'post_content' => $novo,
			),
			true
		);
		CPC_Scanner::analisar_post( $post_id, true );

		$msg = sprintf(
			/* translators: 1: aplicadas, 2: recusadas */
			_n( '%1$d reescrita gravada.', '%1$d reescritas gravadas.', count( $aplicadas ), 'curadoria-conformidade' ),
			count( $aplicadas )
		);
		if ( $recusadas ) {
			$msg .= ' ' . sprintf(
				/* translators: %d: recusadas */
				_n( '%d trecho não pôde ser localizado — veja Falhas.', '%d trechos não puderam ser localizados — veja Falhas.', count( $recusadas ), 'curadoria-conformidade' ),
				count( $recusadas )
			);
		}
		$this->voltar( $post_id, $msg );
	}

	/**
	 * Devolve a sugestão da IA para um trecho. Não grava nada: o texto cai na
	 * caixa e o editor decide.
	 */
	public function ajax_sugerir() {
		check_ajax_referer( 'cpc_sugerir', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'msg' => __( 'Sem permissão.', 'curadoria-conformidade' ) ), 403 );
		}

		$regra    = isset( $_POST['regra'] ) ? sanitize_key( wp_unslash( $_POST['regra'] ) ) : '';
		$trecho   = isset( $_POST['trecho'] ) ? wp_kses_post( wp_unslash( $_POST['trecho'] ) ) : '';
		$contexto = isset( $_POST['contexto'] ) ? sanitize_textarea_field( wp_unslash( $_POST['contexto'] ) ) : '';
		$titulo   = isset( $_POST['titulo'] ) ? sanitize_text_field( wp_unslash( $_POST['titulo'] ) ) : '';

		$r = CPC_IA::sugerir( $regra, $trecho, $contexto, $titulo );
		if ( is_wp_error( $r ) ) {
			CPC_Log::registrar( 'ia_falhou', $post_id, $r->get_error_message(), $regra );
			wp_send_json_error( array( 'msg' => $r->get_error_message() ) );
		}

		CPC_IA::registrar_uso(
			array(
				'em'         => current_time( 'mysql' ),
				'post_id'    => $post_id,
				'regra'      => $regra,
				'provedor'   => $r['provedor'],
				'modelo'     => $r['modelo'],
				'tokens_in'  => $r['tokens_in'],
				'tokens_out' => $r['tokens_out'],
				'usd'        => $r['usd'],
			)
		);

		$mes = CPC_IA::uso_do_mes();
		wp_send_json_success(
			array(
				'texto'    => $r['texto'],
				'provedor' => CPC_IA::rotulo( $r['provedor'] ),
				'modelo'   => $r['modelo'],
				'fallback' => (bool) $r['fallback'],
				'custo'    => number_format_i18n( CPC_IA::brl( $r['usd'] ), 4 ),
				// Abaixo de R$ 0,10, duas casas escondem o avanço: R$ 0,0080 e
				// R$ 0,0097 viram os dois "R$ 0,01" e parece que o medidor travou.
				'mes'      => number_format_i18n( CPC_IA::brl( $mes['usd'] ), CPC_IA::brl( $mes['usd'] ) < 0.10 ? 4 : 2 ),
				'tokens'     => (int) $r['tokens_in'] + (int) $r['tokens_out'],
				'raciocinio' => (int) $r['tokens_raciocinio'],
			)
		);
	}

	public function handler_uso_limpar() {
		check_admin_referer( 'cpc_uso_limpar' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'curadoria-conformidade' ) );
		}
		CPC_IA::limpar_uso();
		wp_safe_redirect( add_query_arg( 'ok', rawurlencode( __( 'Histórico de uso zerado.', 'curadoria-conformidade' ) ), admin_url( 'admin.php?page=cpc-config' ) ) );
		exit;
	}

	private function botao( $action, $rotulo, $classe = 'button' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>">
			<?php wp_nonce_field( $action ); ?>
			<button type="submit" class="<?php echo esc_attr( $classe ); ?>"><?php echo esc_html( $rotulo ); ?></button>
		</form>
		<?php
	}

	private function voltar( $post_id, $msg, $tipo = 'ok' ) {
		$args = array( 'page' => 'cpc-painel', $tipo => rawurlencode( $msg ) );
		if ( $post_id ) {
			$args['post_id'] = $post_id;
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}
}
