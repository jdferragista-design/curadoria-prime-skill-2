<?php
/**
 * Diff linha a linha para a tela de aprovação.
 *
 * O editor precisa ver exatamente o que muda antes de autorizar. Usa o
 * Text_Diff que já vem com o WordPress.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CPC_Diff {

	public static function render( $antes, $depois ) {
		if ( $antes === $depois ) {
			return '<p class="cpc-vazio">Nada mudaria neste post.</p>';
		}

		if ( ! class_exists( 'WP_Text_Diff_Renderer_Table' ) ) {
			require_once ABSPATH . WPINC . '/wp-diff.php';
		}

		$tabela = wp_text_diff(
			self::quebrar( $antes ),
			self::quebrar( $depois ),
			array(
				'title_left'  => __( 'Como está', 'curadoria-conformidade' ),
				'title_right' => __( 'Como ficaria', 'curadoria-conformidade' ),
				'show_split_view' => true,
			)
		);

		if ( ! $tabela ) {
			return '<p class="cpc-vazio">As diferenças são apenas de formatação.</p>';
		}
		return '<div class="cpc-diff">' . $tabela . '</div>';
	}

	/**
	 * Uma tag por linha: sem isso o diff mostra o artigo inteiro como uma
	 * única linha alterada e não serve para revisar nada.
	 */
	private static function quebrar( $html ) {
		$h = preg_replace( '/(<\/(?:p|div|h[1-6]|li|tr|table|section|figure|script)>)/i', "$1\n", $html );
		$h = preg_replace( '/(<(?:p|div|h[1-6]|li|tr|table|section|figure|img|a|script)\b)/i', "\n$1", (string) $h );
		$h = preg_replace( '/(<!--\s*\/?wp:[^>]*-->)/', "\n$1\n", (string) $h );
		$h = preg_replace( "/\n{3,}/", "\n\n", (string) $h );
		return trim( (string) $h );
	}

	public static function resumo_numeros( $antes, $depois ) {
		return array(
			'bytes_antes'  => strlen( $antes ),
			'bytes_depois' => strlen( $depois ),
			'delta'        => strlen( $depois ) - strlen( $antes ),
			'div_antes'    => preg_match_all( '/<div\b/i', $antes ),
			'div_depois'   => preg_match_all( '/<div\b/i', $depois ),
			'img_antes'    => preg_match_all( '/<img\b/i', $antes ),
			'img_depois'   => preg_match_all( '/<img\b/i', $depois ),
			'a_antes'      => preg_match_all( '/<a\b/i', $antes ),
			'a_depois'     => preg_match_all( '/<a\b/i', $depois ),
		);
	}

	/**
	 * Trava de segurança: o corretor não pode perder conteúdo. Se sumiu imagem
	 * ou link, ou o texto encolheu de forma anormal, a gravação é recusada.
	 */
	public static function validar( $antes, $depois ) {
		$erros = array();
		$r     = self::resumo_numeros( $antes, $depois );

		if ( $r['img_depois'] < $r['img_antes'] ) {
			$erros[] = sprintf( 'perderia %d imagem(ns)', $r['img_antes'] - $r['img_depois'] );
		}
		if ( $r['a_depois'] < $r['a_antes'] ) {
			$erros[] = sprintf( 'perderia %d link(s)', $r['a_antes'] - $r['a_depois'] );
		}

		$t1 = mb_strlen( CPC_Rules::texto_visivel( $antes ), 'UTF-8' );
		$t2 = mb_strlen( CPC_Rules::texto_visivel( $depois ), 'UTF-8' );
		if ( $t1 > 0 && $t2 < $t1 * 0.9 ) {
			$erros[] = sprintf( 'o texto visível encolheria %d%%', (int) ( 100 - ( $t2 / $t1 * 100 ) ) );
		}

		// Todo bloco de schema que fazia parse antes precisa continuar fazendo.
		$ok_antes = 0;
		foreach ( CPC_Rules::blocos_jsonld( $antes ) as $b ) {
			if ( is_array( json_decode( CPC_Rules::limpar_jsonld( $b['bruto'] ), true ) ) ) {
				$ok_antes++;
			}
		}
		$ok_depois = 0;
		foreach ( CPC_Rules::blocos_jsonld( $depois ) as $b ) {
			if ( is_array( json_decode( CPC_Rules::limpar_jsonld( $b['bruto'] ), true ) ) ) {
				$ok_depois++;
			}
		}
		if ( $ok_depois < $ok_antes ) {
			$erros[] = 'quebraria um bloco de JSON-LD que hoje é válido';
		}

		return $erros;
	}
}
