<?php
/**
 * Plugin Name: Curadoria Prime — Conformidade Editorial
 * Description: Audita os artigos contra a política editorial (alegação de teste, urgência falsa, schema irregular, links sem sponsored, imagens quebradas) e aplica correções somente após pré-visualização e aprovação humana.
 * Version: 1.2.5
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author:      Curadoria Prime
 * License:     GPL-2.0-or-later
 * Text Domain: curadoria-conformidade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CPC_VERSION', '1.2.5' );
define( 'CPC_FILE', __FILE__ );
define( 'CPC_DIR', plugin_dir_path( __FILE__ ) );
define( 'CPC_URL', plugin_dir_url( __FILE__ ) );

require_once CPC_DIR . 'includes/class-cpc-log.php';
require_once CPC_DIR . 'includes/class-cpc-ia.php';
require_once CPC_DIR . 'includes/class-cpc-editor.php';
require_once CPC_DIR . 'includes/class-cpc-rules.php';
require_once CPC_DIR . 'includes/class-cpc-fixer.php';
require_once CPC_DIR . 'includes/class-cpc-diff.php';
require_once CPC_DIR . 'includes/class-cpc-scanner.php';
require_once CPC_DIR . 'includes/class-cpc-admin.php';
require_once CPC_DIR . 'includes/class-cpc-plugin.php';

register_activation_hook( __FILE__, array( 'CPC_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CPC_Plugin', 'deactivate' ) );

CPC_Plugin::instance();
