# Ai-skill vs. kit do workspace — avaliação e caminho recomendado

**Data:** 13/08/2026 · Branch avaliada: `arena/019ff772-ai-skill` (33 commits à frente da main)

---

## Veredito direto

**Fundir. E o repositório entra como camada de cima.**

Não é meio-termo diplomático. Os dois resolvem problemas **diferentes** e nenhum dos dois
funciona bem sozinho:

| | Ai-skill | Kit do workspace |
|---|---|---|
| **O que é** | Doutrina editorial + skills para Claude | Código executável |
| **Responde** | "O que pode ser escrito, e como" | "Isso que foi escrito está conforme? Publica." |
| **Roda sozinho?** | ❌ Precisa de um humano conversando com a IA | ✅ CLI, exit code, automatizável |
| **Verifica o que está no ar?** | ❌ Só lista a fila (P0–P3) | ✅ Auditou os 48 posts |
| **Pesquisa de mercado** | ✅ Skill dedicada + ledger | ❌ Inexistente |
| **Ponto cego** | Nada impede a IA de ignorar a regra | Não sabe *o que* escrever, só se está formalmente ok |

Um é **regra**, o outro é **fiscal**. Regra sem fiscal é intenção. Fiscal sem regra é
linter de formulário.

---

## Teste que fiz antes de opinar

Não avaliei por leitura. Apontei o `checar_conformidade.py` para os artigos do repositório:

| Artigo do repo | Resultado |
|---|---|
| `tablets-para-volta-as-aulas-2026.html` | **0 erros** · 7 alertas |
| `alternativas-galaxy-tab-s10-fe-ipad-estudar.html` | **0 erros** · 5 alertas |
| `volta-às-aulas-2026-versão-antiga.html` | **0 erros** · 1 alerta |
| `preview-tablets.html` | 1 erro (sem assinatura — é rascunho de preview) |

**Isso é validação cruzada real.** Duas implementações independentes das mesmas políticas do
Google, feitas em contextos separados, concordam. O conteúdo produzido sob as regras do repo
passa numa trava que não foi escrita para ele. Aumenta muito a confiança nos dois lados.

E o mais importante: **zero alegação falsa de teste físico** nos 4 artigos. Contra 37 trechos
em 19 artigos do site que está no ar. A doutrina do repo funciona.

---

## O que o Ai-skill tem de melhor (e eu não tenho)

### 1. `regras_editoriais_ia_curadoria_prime.md` — 28 KB, 16 seções

É a melhor peça do conjunto. Não é genérico, é jurisprudência da casa. Coisas que meu
`prompt-mestre.md` não cobre:

- **§2.2 — as 8 evidências** que autorizam dizer "testamos": responsável, data/duração, origem
  da unidade, variante exata, protocolo, medições, fotos originais, limitações. Isso transforma
  "não minta sobre teste" em um gate objetivo.
- **§2.4 — proibição de `AggregateRating` externo.** Nunca usar nota da Amazon/ML como dado
  estruturado. Eu não tinha essa regra. É violação de política do Google **e** dá rich snippet
  falso.
- **§2.6 — assinatura só do humano que aprovou.** Não assinar pessoa que não revisou.
- **§4.2 — "compradores verificados" só com selo explícito da plataforma.**
- **§6 — alegações sensíveis:** saúde/wearable não diagnostica; tecnologia automotiva não
  incentiva uso ao volante. Você tem 4 artigos de smartband na fila P2. Isso é exposição real.
- **§9.4 — não trocar o ano do título nem `dateModified` só para parecer novo.**

### 2. `curadoria-mercado` — a skill que resolve meu buraco nº 4

No meu diagnóstico apontei "preços hardcoded" como problema, sem solução. Esta skill é a
solução, e é melhor do que eu teria feito:

- **Gate de SKU** com 5 rótulos operacionais: `FICA` / `FICA COM RESSALVA` / `SÓ UMA LOJA` /
  `FORA` / `SEM DADO`. Sem relatório de mercado, o HTML de compra não é escrito.
- **`armadilhas-marketplace.md`** — conhecimento que não se deduz: catálogo `/p/MLB…` ≠ anúncio
  de vendedor; "Redmi Pad 7" vendido como "Xiaomi Pad 7"; internacional com preço de nacional;
  Wi-Fi no título e 5G no anúncio. Isso é experiência de campo destilada.
- **`LEDGER.csv`** — 30 capturas datadas com loja, variante, vendedor, Pix e 12x. É o único
  ativo de dados proprietário de todo o conjunto. E a regra de uso é honesta: 1 ponto = "nesta
  data"; 2 pontos = "subiu/caiu"; 3+ = "faixa observada". Nunca "menor preço da internet".

Esse ledger é, a médio prazo, **a coisa mais valiosa dos dois repositórios.** Em 6–8 meses vira
a seção "comprar agora ou esperar", que é conteúdo que nenhum concorrente copia.

### 3. `fila-atualizacao.md` — inventário P0–P3 dos 48 posts

Curado à mão, com o motivo de cada URL. Complementa a minha auditoria: eu tenho o **quê**
(37 alegações, 48 links), ele tem o **porquê editorial** e a ordem.

---

## O que meu kit tem de melhor (e o repo não tem)

1. **Execução.** O repo não tem uma linha de código. Toda regra depende de a IA ter lido o
   SKILL.md e resolvido obedecer. Meu `checar_conformidade.py` **retorna exit 1** e o
   `publicar_wp.py` **não publica**. Diferença entre pedir e impedir.
2. **Auditoria do que já está no ar.** O repo trata do conteúdo futuro. Meus 48 posts
   auditados, com CSV ordenado por risco, mostram o passivo — que é o problema mais urgente.
3. **Remediação em lote** (`corrigir_artigos.py`): 48 links e 10 divulgações corrigidos via
   REST API, com `--dry-run`.
4. **Escala.** O repo assume ~1 artigo/dia com humano no loop o tempo todo. Meu
   `gerar_artigo.py` + `publicar_wp.py` levam JSON→rascunho em minutos.
5. **Pauta de 90 dias** (36 pautas com sazonalidade BR). O repo não tem calendário.

---

## Conflitos reais entre os dois — precisam de decisão sua

Não são detalhes. São pontos onde os dois **discordam** e eu não posso decidir sozinho.

### 🔴 1. Meu schema viola a §2.4 e a §7.3 do repo

Meu `gerar_artigo.py` gera JSON-LD **sempre**, com `author` = `Organization` "Curadoria Prime".
O repo diz (§7.3): *"Não gerar schema por padrão. Só quando solicitado e após validação
técnica"*, e o `author` deve ser `Person` — o editor humano que aprovou (§2.6).

Pior: meu `reviewAspect` diz literalmente **"avaliações de compradores verificados"** — que é
exatamente a expressão proibida pela §4.2 sem selo da plataforma. **Meu gerador está errado
aqui e o repo está certo.**

### 🟠 2. `rel` — os dois erram, de formas diferentes

- Regra do repo (§8): `rel="sponsored nofollow"`
- **Artigos do repo na prática:** `rel="sponsored noopener noreferrer"` — **sem `nofollow`**,
  38 ocorrências. O repositório desobedece a própria regra.
- Meu gerador: `rel="sponsored noopener noreferrer nofollow"` — o mais completo.

Tecnicamente `sponsored` já basta para o Google, mas se a regra da casa diz `nofollow`, ou
cumpre ou muda a regra. Hoje está inconsistente.

### 🟠 3. "Fontes consultadas" — regra obrigatória, cumprimento zero

A §3.4 torna a seção obrigatória. **Nenhum dos 4 artigos do repo tem.** Meu gerador sempre
produz. Aqui meu kit está certo e o repo descumpre a si mesmo.

### 🟡 4. Nota editorial: obrigatória ou opcional?

Repo §7.1: opcional e criteriosa. Meu `gerar_artigo.py`: `nota` é campo obrigatório do JSON.

### 🟡 5. Volume: ~1 artigo/dia (repo) vs. 36 pautas/90 dias (meu CSV)

Compatíveis na matemática (36 em 90 dias < 1/dia), mas a filosofia difere: o repo prioriza
**atualizar** o que já tem impressão; minha pauta prioriza **publicar novo**. Dado que 27
artigos estão com problema, a prioridade do repo está mais certa agora.

---

## Arquitetura da fusão

Repositório único, com o Ai-skill como base e o kit entrando como camada de execução:

```
Ai-skill/
├── regras_editoriais_ia_curadoria_prime.md   ← FONTE CANÔNICA ÚNICA (do repo)
├── skills/
│   ├── curadoria-review/     ← do repo, intacta
│   └── curadoria-mercado/    ← do repo, intacta (+ ledger)
├── tools/                    ← NOVO: meu kit, alinhado às regras
│   ├── checar_conformidade.py    ← + checagens novas das §§2.4, 4.2, 6, 9.4
│   ├── gerar_artigo.py           ← corrigido: schema opt-in, author Person, sem "verificados"
│   ├── publicar_wp.py            ← gate já integrado
│   ├── corrigir_artigos.py       ← remediação dos 48
│   └── ledger.py                 ← NOVO: valida/consulta o LEDGER.csv
├── audit/
│   ├── auditoria-48-artigos.csv  ← meu
│   └── fila-atualizacao.md       ← do repo
└── pauta-90-dias.csv             ← meu, re-priorizado atrás da fila P0
```

**Princípio:** a doutrina mora em **um** arquivo (o do repo). Meu `prompt-mestre.md` deixa de
ser fonte de regra e vira só o gerador de JSON — senão você tem duas verdades divergindo.

### Checagens que o checker ganha ao absorver as regras do repo

| Nova checagem | Regra | Nível |
|---|---|---|
| `AggregateRating`/`ratingCount` externo no JSON-LD | §2.4 | 🔴 ERRO |
| "compradores verificados" sem selo | §4.2 | 🟠 ALERTA |
| Nota editorial sem escala/critério visível | §7.2 | 🟠 ALERTA |
| CTA apontando para catálogo `/p/MLB…` | mercado | 🔴 ERRO |
| R$ no botão sem captura no LEDGER.csv | mercado | 🔴 ERRO |
| Alegação de saúde em artigo de wearable | §6.2 | 🔴 ERRO |
| `[VERIFICAÇÃO HUMANA NECESSÁRIA]` no HTML final | §2.3 | 🔴 ERRO |
| Ano do título alterado sem mudança substancial | §9.4 | 🟠 ALERTA |
| `rel` sem `nofollow` | §8 | 🟠 ALERTA |

As 4 primeiras são as que mais protegem — nenhuma existe hoje em nenhum dos dois lados de
forma automatizada.

---

## Por que **não** escolher só um

**Só o Ai-skill:** você fica com a melhor doutrina do mercado e nenhuma garantia. Continua
dependendo de a IA obedecer e de o humano lembrar do checklist. Os 27 artigos com problema
continuam no ar — a fila lista as URLs, mas ninguém mede. E foi exatamente assim que as 37
alegações de "testamos" entraram: **não faltava regra, faltava trava.** O próprio README
admite: *"as regras de IA são mais rígidas do que alguns textos já no ar"*.

**Só o meu kit:** você tem trava, mas ela verifica um conjunto pobre de regras. Não sabe o que
é catálogo do ML, não sabe que iPad 10 de 64 GB perde para o iPad 11, não tem ledger, e meu
schema **viola** duas regras da casa. Passaria artigo ruim como bom.

---

## Ordem de execução

1. **Hoje:** `corrigir_artigos.py --aplicar` (48 links + 10 divulgações). Independe da fusão.
2. **Fusão passo 1:** corrigir meu `gerar_artigo.py` nos 3 pontos em que ele viola as regras do
   repo (schema opt-in, `author` Person, remover "compradores verificados").
3. **Fusão passo 2:** absorver as 9 checagens novas no `checar_conformidade.py`.
4. **Fusão passo 3:** rodar o checker turbinado contra os 48 posts de novo — a lista de
   problemas vai crescer, e é bom que cresça.
5. **Depois:** seguir a fila P0 do repo (par de tablets canibalizado + Apple TV 4K), usando o
   fluxo das duas skills, com meu gate no fim.
6. **Só então:** pauta nova.

---

## Uma observação sobre o repositório

A branch está **33 commits à frente e 1 atrás da main**, e os arquivos não existem na main.
Antes de investir, faça o merge para a `main` ou promova essa branch — trabalhar indefinidamente
numa branch `arena/019ff772-ai-skill` é frágil.

Também há dois arquivos sem extensão na raiz (`modelo-2-Power-Bank-no-Avião`,
`modelo-layout-da-Apple-TV-4K.`) com ~63 KB de HTML cada. São referências de layout valiosas,
mas deviam estar em `skills/curadoria-review/references/` com extensão `.html`.
